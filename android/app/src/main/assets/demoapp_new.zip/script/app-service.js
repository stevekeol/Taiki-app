define("config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * 小程序配置文件
 */

var host = '14592619.qcloud.la';

var config = {
  // 测试的请求地址，用于测试会话
  requestUrl: 'https://mp.weixin.qq.com',
  host: host,

  // 云开发环境 ID
  envId: 'release-b86096',
  // envId: 'test-f0b102',

  // 云开发-存储 示例文件的文件 ID
  demoImageFileId: 'cloud://release-b86096.7265-release-b86096-1258211818/demo.jpg',
  demoVideoFileId: 'cloud://release-b86096.7265-release-b86096/demo.mp4'
};

module.exports = config;
});
define("miniprogram_npm/@miniprogram-component-plus/col/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof2(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 12);
    /******/
}(
/************************************************************************/
/******/{

    /***/12:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        var _typeof = typeof Symbol === "function" && _typeof2(Symbol.iterator) === "symbol" ? function (obj) {
            return typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
        } : function (obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
        };

        Component({
            properties: {
                span: {
                    type: Number,
                    value: 24
                },
                offset: {
                    type: Number,
                    value: 0
                },
                push: {
                    type: Number,
                    value: -1
                },
                pull: {
                    type: Number,
                    value: -1
                },
                xs: {
                    type: Number,
                    optionalTypes: [Object],
                    value: -1
                },
                sm: {
                    type: Number,
                    optionalTypes: [Object],
                    value: -1
                },
                md: {
                    type: Number,
                    optionalTypes: [Object],
                    value: -1
                },
                lg: {
                    type: Number,
                    optionalTypes: [Object],
                    value: -1
                },
                xl: {
                    type: Number,
                    optionalTypes: [Object],
                    value: -1
                }
            },
            data: {
                classList: ['weui-col'],
                gutter: 0,
                paddingLeft: 0,
                paddingRight: 0
            },
            relations: {
                "../row/index": {
                    type: 'parent',
                    linked: function linked(target) {
                        this.data.gutter = Number(target.data.gutter);
                        this.updateGutter();
                    },
                    linkChanged: function linkChanged(target) {
                        this.data.gutter = Number(target.data.gutter);
                        this.updateGutter();
                    }
                }
            },
            attached: function attached() {
                this.updateCol();
            },

            methods: {
                updateCol: function updateCol() {
                    var classList = ['weui-col'];
                    var paddingLeft = void 0,
                        paddingRight = 0;
                    classList.push('weui-col-' + this.data.span);
                    classList.push('weui-col-offset-' + this.data.offset);
                    if (this.data.gutter) {
                        paddingLeft = this.data.gutter / 2 + 'px';
                        paddingRight = paddingLeft;
                    }
                    if (this.data.push !== -1) {
                        this.data.push && classList.push('weui-col-push-' + this.data.push);
                    }
                    if (this.data.pull !== -1) {
                        this.data.pull && classList.push('weui-col-pull-' + this.data.pull);
                    }
                    this.screenSizeSet('xs', classList);
                    this.screenSizeSet('sm', classList);
                    this.screenSizeSet('md', classList);
                    this.screenSizeSet('lg', classList);
                    this.screenSizeSet('xl', classList);
                    return this.setData({
                        classList: classList
                    });
                },
                updateGutter: function updateGutter() {
                    var paddingLeft = void 0,
                        paddingRight = 0;
                    if (this.data.gutter) {
                        paddingLeft = this.data.gutter / 2 + 'px';
                        paddingRight = paddingLeft;
                    }
                    this.setData({
                        paddingLeft: paddingLeft,
                        paddingRight: paddingRight
                    });
                },
                screenSizeSet: function screenSizeSet(screen, classList) {
                    if (typeof this.data[screen] === 'number' && this.data[screen] !== -1) {
                        classList.push('weui-col-' + screen + '-' + this.data[screen]);
                    } else if (_typeof(this.data[screen]) === 'object') {
                        typeof this.data[screen].offset === 'number' && classList.push('weui-col-' + screen + '-offset-' + this.data[screen].offset);
                        typeof this.data[screen].push === 'number' && classList.push('weui-col-' + screen + '-push-' + this.data[screen].push);
                        typeof this.data[screen].pull === 'number' && classList.push('weui-col-' + screen + '-pull-' + this.data[screen].pull);
                        typeof this.data[screen].span === 'number' && classList.push('weui-col-' + screen + '-' + this.data[screen].span);
                    }
                }
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/emoji/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 2);
    /******/
}(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, exports, __webpack_require__) {

    "use strict";

    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = [{ 'id': 0, 'cn': '[微笑]', 'hk': '[微笑]', 'us': '[Smile]', 'code': '/::)', 'web_code': '/微笑', 'style': 'smiley_0' }, { 'id': 1, 'cn': '[撇嘴]', 'hk': '[撇嘴]', 'us': '[Grimace]', 'code': '/::~', 'web_code': '/撇嘴', 'style': 'smiley_1' }, { 'id': 2, 'cn': '[色]', 'hk': '[色]', 'us': '[Drool]', 'code': '/::B', 'web_code': '/色', 'style': 'smiley_2' }, { 'id': 3, 'cn': '[发呆]', 'hk': '[發呆]', 'us': '[Scowl]', 'code': '/::|', 'web_code': '/发呆', 'style': 'smiley_3' }, { 'id': 4, 'cn': '[得意]', 'hk': '[得意]', 'us': '[CoolGuy]', 'code': '/:8-)', 'web_code': '/得意', 'style': 'smiley_4' }, { 'id': 5, 'cn': '[流泪]', 'hk': '[流淚]', 'us': '[Sob]', 'code': '/::<', 'web_code': '/流泪', 'style': 'smiley_5' }, { 'id': 6, 'cn': '[害羞]', 'hk': '[害羞]', 'us': '[Shy]', 'code': '/::$', 'web_code': '/害羞', 'style': 'smiley_6' }, { 'id': 7, 'cn': '[闭嘴]', 'hk': '[閉嘴]', 'us': '[Silent]', 'code': '/::X', 'web_code': '/闭嘴', 'style': 'smiley_7' }, { 'id': 8, 'cn': '[睡]', 'hk': '[睡]', 'us': '[Sleep]', 'code': '/::Z', 'web_code': '/睡', 'style': 'smiley_8' }, { 'id': 9, 'cn': '[大哭]', 'hk': '[大哭]', 'us': '[Cry]', 'code': '/::"(', 'web_code': '/大哭', 'style': 'smiley_9' }, { 'id': 10, 'cn': '[尴尬]', 'hk': '[尷尬]', 'us': '[Awkward]', 'code': '/::-|', 'web_code': '/尴尬', 'style': 'smiley_10' }, { 'id': 11, 'cn': '[发怒]', 'hk': '[發怒]', 'us': '[Angry]', 'code': '/::@', 'web_code': '/发怒', 'style': 'smiley_11' }, { 'id': 12, 'cn': '[调皮]', 'hk': '[調皮]', 'us': '[Tongue]', 'code': '/::P', 'web_code': '/调皮', 'style': 'smiley_12' }, { 'id': 13, 'cn': '[呲牙]', 'hk': '[呲牙]', 'us': '[Grin]', 'code': '/::D', 'web_code': '/呲牙', 'style': 'smiley_13' }, { 'id': 14, 'cn': '[惊讶]', 'hk': '[驚訝]', 'us': '[Surprise]', 'code': '/::O', 'web_code': '/惊讶', 'style': 'smiley_14' }, { 'id': 15, 'cn': '[难过]', 'hk': '[難過]', 'us': '[Frown]', 'code': '/::(', 'web_code': '/难过', 'style': 'smiley_15' }, { 'id': 16, 'cn': '[酷]', 'hk': '[酷]', 'us': '[Ruthless]', 'code': '/::+', 'web_code': '/酷', 'style': 'smiley_16' }, { 'id': 17, 'cn': '[冷汗]', 'hk': '[冷汗]', 'us': '[Blush]', 'code': '/:--b', 'web_code': '/冷汗', 'style': 'smiley_17' }, { 'id': 18, 'cn': '[抓狂]', 'hk': '[抓狂]', 'us': '[Scream]', 'code': '/::Q', 'web_code': '/抓狂', 'style': 'smiley_18' }, { 'id': 19, 'cn': '[吐]', 'hk': '[吐]', 'us': '[Puke]', 'code': '/::T', 'web_code': '/吐', 'style': 'smiley_19' }, { 'id': 20, 'cn': '[偷笑]', 'hk': '[偷笑]', 'us': '[Chuckle]', 'code': '/:,@P', 'web_code': '/偷笑', 'style': 'smiley_20' }, { 'id': 21, 'cn': '[愉快]', 'hk': '[愉快]', 'us': '[Joyful]', 'code': '/:,@-D', 'web_code': '/可爱', 'style': 'smiley_21' }, { 'id': 22, 'cn': '[白眼]', 'hk': '[白眼]', 'us': '[Slight]', 'code': '/::d', 'web_code': '/白眼', 'style': 'smiley_22' }, { 'id': 23, 'cn': '[傲慢]', 'hk': '[傲慢]', 'us': '[Smug]', 'code': '/:,@o', 'web_code': '/傲慢', 'style': 'smiley_23' }, { 'id': 24, 'cn': '[饥饿]', 'hk': '[饑餓]', 'us': '[Hungry]', 'code': '/::g', 'web_code': '/饥饿', 'style': 'smiley_24' }, { 'id': 25, 'cn': '[困]', 'hk': '[累]', 'us': '[Drowsy]', 'code': '/:|-)', 'web_code': '/困', 'style': 'smiley_25' }, { 'id': 26, 'cn': '[惊恐]', 'hk': '[驚恐]', 'us': '[Panic]', 'code': '/::!', 'web_code': '/惊恐', 'style': 'smiley_26' }, { 'id': 27, 'cn': '[流汗]', 'hk': '[流汗]', 'us': '[Sweat]', 'code': '/::L', 'web_code': '/流汗', 'style': 'smiley_27' }, { 'id': 28, 'cn': '[憨笑]', 'hk': '[大笑]', 'us': '[Laugh]', 'code': '/::>', 'web_code': '/憨笑', 'style': 'smiley_28' }, { 'id': 29, 'cn': '[悠闲]', 'hk': '[悠閑]', 'us': '[Commando]', 'code': '/::,@', 'web_code': '/大兵', 'style': 'smiley_29' }, { 'id': 30, 'cn': '[奋斗]', 'hk': '[奮鬥]', 'us': '[Determined]', 'code': '/:,@f', 'web_code': '/奋斗', 'style': 'smiley_30' }, { 'id': 31, 'cn': '[咒骂]', 'hk': '[咒罵]', 'us': '[Scold]', 'code': '/::-S', 'web_code': '/咒骂', 'style': 'smiley_31' }, { 'id': 32, 'cn': '[疑问]', 'hk': '[疑問]', 'us': '[Shocked]', 'code': '/:?', 'web_code': '/疑问', 'style': 'smiley_32' }, { 'id': 33, 'cn': '[嘘]', 'hk': '[噓]', 'us': '[Shhh]', 'code': '/:,@x', 'web_code': '/嘘', 'style': 'smiley_33' }, { 'id': 34, 'cn': '[晕]', 'hk': '[暈]', 'us': '[Dizzy]', 'code': '/:,@@', 'web_code': '/晕', 'style': 'smiley_34' }, { 'id': 35, 'cn': '[疯了]', 'hk': '[瘋了]', 'us': '[Tormented]', 'code': '/::8', 'web_code': '/折磨', 'style': 'smiley_35' }, { 'id': 36, 'cn': '[衰]', 'hk': '[衰]', 'us': '[Toasted]', 'code': '/:,@!', 'web_code': '/衰', 'style': 'smiley_36' }, { 'id': 37, 'cn': '[骷髅]', 'hk': '[骷髏頭]', 'us': '[Skull]', 'code': '/:!!!', 'web_code': '/骷髅', 'style': 'smiley_37' }, { 'id': 38, 'cn': '[敲打]', 'hk': '[敲打]', 'us': '[Hammer]', 'code': '/:xx', 'web_code': '/敲打', 'style': 'smiley_38' }, { 'id': 39, 'cn': '[再见]', 'hk': '[再見]', 'us': '[Wave]', 'code': '/:bye', 'web_code': '/再见', 'style': 'smiley_39' }, { 'id': 40, 'cn': '[擦汗]', 'hk': '[擦汗]', 'us': '[Speechless]', 'code': '/:wipe', 'web_code': '/擦汗', 'style': 'smiley_40' }, { 'id': 41, 'cn': '[抠鼻]', 'hk': '[摳鼻]', 'us': '[NosePick]', 'code': '/:dig', 'web_code': '/抠鼻', 'style': 'smiley_41' }, { 'id': 42, 'cn': '[鼓掌]', 'hk': '[鼓掌]', 'us': '[Clap]', 'code': '/:handclap', 'web_code': '/鼓掌', 'style': 'smiley_42' }, { 'id': 43, 'cn': '[糗大了]', 'hk': '[羞辱]', 'us': '[Shame]', 'code': '/:&-(', 'web_code': '/糗大了', 'style': 'smiley_43' }, { 'id': 44, 'cn': '[坏笑]', 'hk': '[壞笑]', 'us': '[Trick]', 'code': '/:B-)', 'web_code': '/坏笑', 'style': 'smiley_44' }, { 'id': 45, 'cn': '[左哼哼]', 'hk': '[左哼哼]', 'us': '[Bah！L]', 'code': '/:<@', 'web_code': '/左哼哼', 'style': 'smiley_45' }, { 'id': 46, 'cn': '[右哼哼]', 'hk': '[右哼哼]', 'us': '[Bah！R]', 'code': '/:@>', 'web_code': '/右哼哼', 'style': 'smiley_46' }, { 'id': 47, 'cn': '[哈欠]', 'hk': '[哈欠]', 'us': '[Yawn]', 'code': '/::-O', 'web_code': '/哈欠', 'style': 'smiley_47' }, { 'id': 48, 'cn': '[鄙视]', 'hk': '[鄙視]', 'us': '[Pooh-pooh]', 'code': '/:>-|', 'web_code': '/鄙视', 'style': 'smiley_48' }, { 'id': 49, 'cn': '[委屈]', 'hk': '[委屈]', 'us': '[Shrunken]', 'code': '/:P-(', 'web_code': '/委屈', 'style': 'smiley_49' }, { 'id': 50, 'cn': '[快哭了]', 'hk': '[快哭了]', 'us': '[TearingUp]', 'code': '/::"|', 'web_code': '/快哭了', 'style': 'smiley_50' }, { 'id': 51, 'cn': '[阴险]', 'hk': '[陰險]', 'us': '[Sly]', 'code': '/:X-)', 'web_code': '/阴险', 'style': 'smiley_51' }, { 'id': 52, 'cn': '[亲亲]', 'hk': '[親親]', 'us': '[Kiss]', 'code': '/::*', 'web_code': '/亲亲', 'style': 'smiley_52' }, { 'id': 53, 'cn': '[吓]', 'hk': '[嚇]', 'us': '[Wrath]', 'code': '/:@x', 'web_code': '/吓', 'style': 'smiley_53' }, { 'id': 54, 'cn': '[可怜]', 'hk': '[可憐]', 'us': '[Whimper]', 'code': '/:8*', 'web_code': '/可怜', 'style': 'smiley_54' }, { 'id': 55, 'cn': '[菜刀]', 'hk': '[菜刀]', 'us': '[Cleaver]', 'code': '/:pd', 'web_code': '/菜刀', 'style': 'smiley_55' }, { 'id': 56, 'cn': '[西瓜]', 'hk': '[西瓜]', 'us': '[Watermelon]', 'code': '/:<W>', 'web_code': '/西瓜', 'style': 'smiley_56' }, { 'id': 57, 'cn': '[啤酒]', 'hk': '[啤酒]', 'us': '[Beer]', 'code': '/:beer', 'web_code': '/啤酒', 'style': 'smiley_57' }, { 'id': 58, 'cn': '[篮球]', 'hk': '[籃球]', 'us': '[Basketball]', 'code': '/:basketb', 'web_code': '/篮球', 'style': 'smiley_58' }, { 'id': 59, 'cn': '[乒乓]', 'hk': '[乒乓]', 'us': '[PingPong]', 'code': '/:oo', 'web_code': '/乒乓', 'style': 'smiley_59' }, { 'id': 60, 'cn': '[咖啡]', 'hk': '[咖啡]', 'us': '[Coffee]', 'code': '/:coffee', 'web_code': '/咖啡', 'style': 'smiley_60' }, { 'id': 61, 'cn': '[饭]', 'hk': '[飯]', 'us': '[Rice]', 'code': '/:eat', 'web_code': '/饭', 'style': 'smiley_61' }, { 'id': 62, 'cn': '[猪头]', 'hk': '[豬頭]', 'us': '[Pig]', 'code': '/:pig', 'web_code': '/猪头', 'style': 'smiley_62' }, { 'id': 63, 'cn': '[玫瑰]', 'hk': '[玫瑰]', 'us': '[Rose]', 'code': '/:rose', 'web_code': '/玫瑰', 'style': 'smiley_63' }, { 'id': 64, 'cn': '[凋谢]', 'hk': '[枯萎]', 'us': '[Wilt]', 'code': '/:fade', 'web_code': '/凋谢', 'style': 'smiley_64' }, { 'id': 65, 'cn': '[嘴唇]', 'hk': '[嘴唇]', 'us': '[Lips]', 'code': '/:showlove', 'web_code': '/示爱', 'style': 'smiley_65' }, { 'id': 66, 'cn': '[爱心]', 'hk': '[愛心]', 'us': '[Heart]', 'code': '/:heart', 'web_code': '/爱心', 'style': 'smiley_66' }, { 'id': 67, 'cn': '[心碎]', 'hk': '[心碎]', 'us': '[BrokenHeart]', 'code': '/:break', 'web_code': '/心碎', 'style': 'smiley_67' }, { 'id': 68, 'cn': '[蛋糕]', 'hk': '[蛋糕]', 'us': '[Cake]', 'code': '/:cake', 'web_code': '/蛋糕', 'style': 'smiley_68' }, { 'id': 69, 'cn': '[闪电]', 'hk': '[閃電]', 'us': '[Lightning]', 'code': '/:li', 'web_code': '/闪电', 'style': 'smiley_69' }, { 'id': 70, 'cn': '[炸弹]', 'hk': '[炸彈]', 'us': '[Bomb]', 'code': '/:bome', 'web_code': '/炸弹', 'style': 'smiley_70' }, { 'id': 71, 'cn': '[刀]', 'hk': '[刀]', 'us': '[Dagger]', 'code': '/:kn', 'web_code': '/刀', 'style': 'smiley_71' }, { 'id': 72, 'cn': '[足球]', 'hk': '[足球]', 'us': '[Soccer]', 'code': '/:footb', 'web_code': '/足球', 'style': 'smiley_72' }, { 'id': 73, 'cn': '[瓢虫]', 'hk': '[甲蟲]', 'us': '[Ladybug]', 'code': '/:ladybug', 'web_code': '/瓢虫', 'style': 'smiley_73' }, { 'id': 74, 'cn': '[便便]', 'hk': '[便便]', 'us': '[Poop]', 'code': '/:shit', 'web_code': '/便便', 'style': 'smiley_74' }, { 'id': 75, 'cn': '[月亮]', 'hk': '[月亮]', 'us': '[Moon]', 'code': '/:moon', 'web_code': '/月亮', 'style': 'smiley_75' }, { 'id': 76, 'cn': '[太阳]', 'hk': '[太陽]', 'us': '[Sun]', 'code': '/:sun', 'web_code': '/太阳', 'style': 'smiley_76' }, { 'id': 77, 'cn': '[礼物]', 'hk': '[禮物]', 'us': '[Gift]', 'code': '/:gift', 'web_code': '/礼物', 'style': 'smiley_77' }, { 'id': 78, 'cn': '[拥抱]', 'hk': '[擁抱]', 'us': '[Hug]', 'code': '/:hug', 'web_code': '/拥抱', 'style': 'smiley_78' }, { 'id': 79, 'cn': '[强]', 'hk': '[強]', 'us': '[ThumbsUp]', 'code': '/:strong', 'web_code': '/强', 'style': 'smiley_79' }, { 'id': 80, 'cn': '[弱]', 'hk': '[弱]', 'us': '[ThumbsDown]', 'code': '/:weak', 'web_code': '/弱', 'style': 'smiley_80' }, { 'id': 81, 'cn': '[握手]', 'hk': '[握手]', 'us': '[Shake]', 'code': '/:share', 'web_code': '/握手', 'style': 'smiley_81' }, { 'id': 82, 'cn': '[胜利]', 'hk': '[勝利]', 'us': '[Peace]', 'code': '/:v', 'web_code': '/胜利', 'style': 'smiley_82' }, { 'id': 83, 'cn': '[抱拳]', 'hk': '[抱拳]', 'us': '[Fight]', 'code': '/:@)', 'web_code': '/抱拳', 'style': 'smiley_83' }, { 'id': 84, 'cn': '[勾引]', 'hk': '[勾引]', 'us': '[Beckon]', 'code': '/:jj', 'web_code': '/勾引', 'style': 'smiley_84' }, { 'id': 85, 'cn': '[拳头]', 'hk': '[拳頭]', 'us': '[Fist]', 'code': '/:@@', 'web_code': '/拳头', 'style': 'smiley_85' }, { 'id': 86, 'cn': '[差劲]', 'hk': '[差勁]', 'us': '[Pinky]', 'code': '/:bad', 'web_code': '/差劲', 'style': 'smiley_86' }, { 'id': 87, 'cn': '[爱你]', 'hk': '[愛你]', 'us': '[RockOn]', 'code': '/:lvu', 'web_code': '/爱你', 'style': 'smiley_87' }, { 'id': 88, 'cn': '[NO]', 'hk': '[NO]', 'us': '[Nuh-uh]', 'code': '/:no', 'web_code': '/NO', 'style': 'smiley_88' }, { 'id': 89, 'cn': '[OK]', 'hk': '[OK]', 'us': '[OK]', 'code': '/:ok', 'web_code': '/OK', 'style': 'smiley_89' }, { 'id': 90, 'cn': '[爱情]', 'hk': '[愛情]', 'us': '[InLove]', 'code': '/:love', 'web_code': '/爱情', 'style': 'smiley_90' }, { 'id': 91, 'cn': '[飞吻]', 'hk': '[飛吻]', 'us': '[Blowkiss]', 'code': '/:<L>', 'web_code': '/飞吻', 'style': 'smiley_91' }, { 'id': 92, 'cn': '[跳跳]', 'hk': '[跳跳]', 'us': '[Waddle]', 'code': '/:jump', 'web_code': '/跳跳', 'style': 'smiley_92' }, { 'id': 93, 'cn': '[发抖]', 'hk': '[發抖]', 'us': '[Tremble]', 'code': '/:shake', 'web_code': '/发抖', 'style': 'smiley_93' }, { 'id': 94, 'cn': '[怄火]', 'hk': '[噴火]', 'us': '[Aaagh!]', 'code': '/:<O>', 'web_code': '/怄火', 'style': 'smiley_94' }, { 'id': 95, 'cn': '[转圈]', 'hk': '[轉圈]', 'us': '[Twirl]', 'code': '/:circle', 'web_code': '/转圈', 'style': 'smiley_95' }, { 'id': 96, 'cn': '[磕头]', 'hk': '[磕頭]', 'us': '[Kotow]', 'code': '/:kotow', 'web_code': '/磕头', 'style': 'smiley_96' }, { 'id': 97, 'cn': '[回头]', 'hk': '[回頭]', 'us': '[Dramatic]', 'code': '/:turn', 'web_code': '/回头', 'style': 'smiley_97' }, { 'id': 98, 'cn': '[跳绳]', 'hk': '[跳繩]', 'us': '[JumpRope]', 'code': '/:skip', 'web_code': '/跳绳', 'style': 'smiley_98' }, { 'id': 99, 'cn': '[投降]', 'hk': '[投降]', 'us': '[Surrender]', 'code': '/:oY', 'web_code': '/挥手', 'style': 'smiley_99' }, { 'id': 100, 'cn': '[激动]', 'hk': '[激動]', 'us': '[Hooray]', 'code': '/:#-0', 'web_code': '/激动', 'style': 'smiley_100' }, { 'id': 101, 'cn': '[乱舞]', 'hk': '[亂舞]', 'us': '[Meditate]', 'code': '/:hiphot', 'web_code': '/街舞', 'style': 'smiley_101' }, { 'id': 102, 'cn': '[献吻]', 'hk': '[獻吻]', 'us': '[Smooch]', 'code': '/:kiss', 'web_code': '/献吻', 'style': 'smiley_102' }, { 'id': 103, 'cn': '[左太极]', 'hk': '[左太極]', 'us': '[TaiChi L]', 'code': '/:<&', 'web_code': '/左太极', 'style': 'smiley_103' }, { 'id': 104, 'cn': '[右太极]', 'hk': '[右太極]', 'us': '[TaiChi R]', 'code': '/:&>', 'web_code': '/右太极', 'style': 'smiley_104' }, { 'id': 204, 'cn': '[嘿哈]', 'hk': '[吼嘿]', 'us': '[Hey]', 'code': '', 'web_code': '', 'style': 'e2_04' }, { 'id': 205, 'cn': '[捂脸]', 'hk': '[掩面]', 'us': '[Facepalm]', 'code': '', 'web_code': '', 'style': 'e2_05' }, { 'id': 202, 'cn': '[奸笑]', 'hk': '[奸笑]', 'us': '[Smirk]', 'code': '', 'web_code': '', 'style': 'e2_02' }, { 'id': 206, 'cn': '[机智]', 'hk': '[機智]', 'us': '[Smart]', 'code': '', 'web_code': '', 'style': 'e2_06' }, { 'id': 212, 'cn': '[皱眉]', 'hk': '[皺眉]', 'us': '[Moue]', 'code': '', 'web_code': '', 'style': 'e2_12' }, { 'id': 211, 'cn': '[耶]', 'hk': '[歐耶]', 'us': '[Yeah!]', 'code': '', 'web_code': '', 'style': 'e2_11' }, { 'id': 207, 'cn': '[茶]', 'hk': '[茶]', 'us': '[Tea]', 'code': '', 'web_code': '', 'style': 'e2_07' }, { 'id': 209, 'cn': '[红包]', 'hk': '[Packet]', 'us': '[Packet]', 'code': '', 'web_code': '', 'style': 'e2_09' }, { 'id': 210, 'cn': '[蜡烛]', 'hk': '[蠟燭]', 'us': '[Candle]', 'code': '', 'web_code': '', 'style': 'e2_10' }, { 'id': 215, 'cn': '[福]', 'hk': '[福]', 'us': '[Blessing]', 'code': '', 'web_code': '', 'style': 'e2_15' }, { 'id': 214, 'cn': '[鸡]', 'hk': '[小雞]', 'us': '[Chick]', 'code': '', 'web_code': '', 'style': 'e2_14' }, { 'id': 300, 'cn': '[笑脸]', 'emoji': '😄', 'hk': '', 'us': '', 'code': '\\ue415', 'web_code': '', 'style': 'u1F604' }, { 'id': 301, 'cn': '[生病]', 'emoji': '😷', 'hk': '', 'us': '', 'code': '\\ue40c', 'web_code': '', 'style': 'u1F637' }, { 'id': 302, 'cn': '[破涕为笑]', 'emoji': '😂', 'hk': '', 'us': '', 'code': '\\ue412', 'web_code': '', 'style': 'u1F602' }, { 'id': 303, 'cn': '[吐舌]', 'emoji': '😝', 'hk': '', 'us': '', 'code': '\\ue409', 'web_code': '', 'style': 'u1F61D' }, { 'id': 304, 'cn': '[脸红]', 'emoji': '😳', 'hk': '', 'us': '', 'code': '\\ue40d', 'web_code': '', 'style': 'u1F633' }, { 'id': 305, 'cn': '[恐惧]', 'emoji': '😱', 'hk': '', 'us': '', 'code': '\\ue107', 'web_code': '', 'style': 'u1F631' }, { 'id': 306, 'cn': '[失望]', 'emoji': '😔', 'hk': '', 'us': '', 'code': '\\ue403', 'web_code': '', 'style': 'u1F614' }, { 'id': 307, 'cn': '[无语]', 'emoji': '😒', 'hk': '', 'us': '', 'code': '\\ue40e', 'web_code': '', 'style': 'u1F612' }, { 'id': 308, 'cn': '[鬼魂]', 'emoji': '👻', 'hk': '', 'us': '', 'code': '\\ue11b', 'web_code': '', 'style': 'u1F47B' }, { 'id': 309, 'cn': '[合十]', 'emoji': '🙏', 'hk': '', 'us': '', 'code': '\\ue41d', 'web_code': '', 'style': 'u1F64F' }, { 'id': 310, 'cn': '[强壮]', 'emoji': '💪', 'hk': '', 'us': '', 'code': '\\ue14c', 'web_code': '', 'style': 'u1F4AA' }, { 'id': 311, 'cn': '[庆祝]', 'emoji': '🎉', 'hk': '', 'us': '', 'code': '\\ue312', 'web_code': '', 'style': 'u1F389' }, { 'id': 312, 'cn': '[礼物]', 'hk': '', 'us': '', 'code': '\\ue112', 'web_code': '', 'style': 'u1F381' }, { 'id': 313, 'cn': '[吃瓜]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_313' }, { 'id': 314, 'cn': '[加油]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_314' }, { 'id': 315, 'cn': '[汗]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_315' }, { 'id': 316, 'cn': '[天啊]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_316' }, { 'id': 317, 'cn': '[Emm]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_317' }, { 'id': 318, 'cn': '[社会社会]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_318' }, { 'id': 319, 'cn': '[旺柴]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_319' }, { 'id': 320, 'cn': '[好的]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_320' }, { 'id': 321, 'cn': '[打脸]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_321' }, { 'id': 322, 'cn': '[哇]', 'hk': '[]', 'us': '[]', 'code': '', 'web_code': '', 'style': 'smiley_322' }];

    /***/
},,
/* 1 */
/* 2 */
/***/function (module, exports, __webpack_require__) {

    "use strict";

    Object.defineProperty(exports, "__esModule", { value: true });
    var emoji_data_1 = __webpack_require__(0);
    var emoji_panel_data_1 = __webpack_require__(3);
    var parser_1 = __webpack_require__(4);
    var EMOTION_SIZE = 40;
    var emotionMap = {};
    var emotionNames = [];
    emoji_data_1.default.forEach(function (item) {
        emotionMap[item.id] = item;
        emotionNames.push(item.cn);
    });
    var emotions = [];
    emoji_panel_data_1.default.forEach(function (id) {
        return emotions.push(emotionMap[id]);
    });
    Component({
        options: {
            styleIsolation: 'page-shared',
            addGlobalClass: true,
            pureDataPattern: /^_/
        },
        properties: {
            padding: {
                type: Number,
                value: 15
            },
            backgroundColor: {
                type: String,
                value: '#EDEDED'
            },
            showSend: {
                type: Boolean,
                value: true
            },
            showDel: {
                type: Boolean,
                value: true
            },
            showHistory: {
                type: Boolean,
                value: true
            },
            height: {
                type: Number,
                value: 300
            },
            source: {
                type: String,
                value: ''
            }
        },
        data: {
            history: [],
            emotions: emotions,
            extraPadding: 0,
            perLine: 0
        },
        lifetimes: {
            attached: function attached() {
                var padding = this.data.padding;
                var systemInfo = wx.getSystemInfoSync();
                var areaWidth = systemInfo.windowWidth;
                var perLine = Math.floor((areaWidth - padding * 2) / 45);
                var extraPadding = Math.floor((areaWidth - padding * 2 - perLine * EMOTION_SIZE) / (perLine - 1));
                this.setData({
                    perLine: perLine,
                    extraPadding: extraPadding,
                    hasSafeBottom: systemInfo.model.indexOf('iPhone X') >= 0
                });
            }
        },
        methods: {
            getEmojiNames: function getEmojiNames() {
                return emotionNames;
            },

            parseEmoji: parser_1.parseEmoji,
            insertEmoji: function insertEmoji(evt) {
                var data = this.data;
                var idx = evt.currentTarget.dataset.idx;
                var emotionName = data.emotions[idx].cn;
                this.LRUCache(data.history, data.perLine, idx);
                this.setData({ history: data.history });
                this.triggerEvent('insertemoji', { emotionName: emotionName });
            },
            deleteEmoji: function deleteEmoji() {
                this.triggerEvent('delemoji');
            },
            send: function send() {
                this.triggerEvent('send');
            },
            LRUCache: function LRUCache(arr, limit, data) {
                var idx = arr.indexOf(data);
                if (idx >= 0) {
                    arr.splice(idx, 1);
                    arr.unshift(data);
                } else if (arr.length < limit) {
                    arr.push(data);
                } else if (arr.length === limit) {
                    arr[limit - 1] = data;
                }
            }
        }
    });

    /***/
},
/* 3 */
/***/function (module, exports, __webpack_require__) {

    "use strict";

    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 50, 51, 52, 54, 55, 56, 57, 60, 62, 63, 64, 65, 66, 67, 68, 70, 74, 75, 76, 78, 79, 80, 81, 82, 83, 84, 85, 89, 92, 93, 94, 95, 300, 301, 302, 303, 304, 305, 306, 307, 204, 205, 202, 206, 212, 211, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 308, 309, 310, 311, 312, 209];

    /***/
},
/* 4 */
/***/function (module, exports, __webpack_require__) {

    "use strict";

    Object.defineProperty(exports, "__esModule", { value: true });
    var emoji_data_1 = __webpack_require__(0);
    var emotionMap = {};
    emoji_data_1.default.forEach(function (item, index) {
        if (item.cn) {
            emotionMap[item.cn] = item;
        }
        if (item.code) emotionMap[item.code] = item;
        if (item.us) emotionMap[item.us] = item;
    });
    var parseEmoji = function parseEmoji(content) {
        var emojiIndexList = [];
        for (var k in emotionMap) {
            var idx = content.indexOf(k);
            while (idx >= 0) {
                emojiIndexList.push({ idx: idx, code: k, type: 2 });
                idx = content.indexOf(k, idx + k.length);
            }
        }
        emojiIndexList = emojiIndexList.sort(function (a, b) {
            return a.idx - b.idx;
        });
        var newContentList = [];
        var lastTextIndex = 0;
        emojiIndexList.forEach(function (item) {
            if (lastTextIndex !== item.idx) {
                newContentList.push({
                    type: 1,
                    content: content.substring(lastTextIndex, item.idx)
                });
            }
            if (item.type === 2) {
                newContentList.push({
                    type: item.type,
                    content: content.substr(item.idx, item.code.length),
                    imageClass: emotionMap[item.code].style
                });
            } else {
                newContentList.push({
                    type: item.type,
                    content: item.code,
                    imageClass: item.value
                });
            }
            lastTextIndex = item.idx + item.code.length;
        });
        var lastText = content.substring(lastTextIndex);
        if (lastText) {
            newContentList.push({
                type: 1,
                content: lastText
            });
        }
        return newContentList;
    };
    exports.parseEmoji = parseEmoji;

    /***/
}]
/******/);
});
define("miniprogram_npm/@miniprogram-component-plus/index-list/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 4);
    /******/
}(
/************************************************************************/
/******/{

    /***/4:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        var throttle = function throttle(func, wait, options) {
            var context = void 0;
            var args = void 0;
            var result = void 0;
            var timeout = null;
            var previous = 0;
            if (!options) options = {};
            var later = function later() {
                previous = options.leading === false ? 0 : Date.now();
                timeout = null;
                result = func.apply(context, args);
                if (!timeout) context = args = null;
            };
            return function () {
                var now = Date.now();
                if (!previous && options.leading === false) previous = now;
                var remaining = wait - (now - previous);
                context = this;
                args = arguments;
                if (remaining <= 0 || remaining > wait) {
                    clearTimeout(timeout);
                    timeout = null;
                    previous = now;
                    result = func.apply(context, args);
                    if (!timeout) context = args = null;
                } else if (!timeout && options.trailing !== false) {
                    timeout = setTimeout(later, remaining);
                }
                return result;
            };
        };
        Component({
            options: {
                addGlobalClass: true,
                pureDataPattern: /^_/
            },
            properties: {
                list: {
                    type: Array,
                    value: [],
                    observer: function observer(newVal) {
                        var _this = this;

                        if (newVal.length === 0) return;
                        var data = this.data;
                        var alphabet = data.list.map(function (item) {
                            return item.alpha;
                        });
                        this.setData({
                            alphabet: alphabet,
                            current: alphabet[0]
                        }, function () {
                            _this.computedSize();
                        });
                    }
                },
                vibrated: {
                    type: Boolean,
                    value: true
                }
            },
            data: {
                windowHeight: 612,
                current: 'A',
                intoView: '',
                touching: false,
                alphabet: [],
                _tops: [],
                _anchorItemH: 0,
                _anchorItemW: 0,
                _anchorTop: 0,
                _listUpperBound: 0
            },
            lifetimes: {
                created: function created() {},
                attached: function attached() {
                    this.__scrollTo = throttle(this._scrollTo, 100, {});
                    this.__onScroll = throttle(this._onScroll, 100, {});

                    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
                        windowHeight = _wx$getSystemInfoSync.windowHeight;

                    this.setData({ windowHeight: windowHeight });
                }
            },
            methods: {
                choose: function choose(e) {
                    var item = e.target.dataset.item;
                    this.triggerEvent('choose', { item: item });
                },
                scrollTo: function scrollTo(e) {
                    this.__scrollTo(e);
                },
                _scrollTo: function _scrollTo(e) {
                    var data = this.data;
                    var clientY = e.changedTouches[0].clientY;
                    var index = Math.floor((clientY - data._anchorTop) / data._anchorItemH);
                    var current = data.alphabet[index];
                    this.setData({ current: current, intoView: current, touching: true });
                    if (data.vibrated) wx.vibrateShort();
                },
                computedSize: function computedSize() {
                    var data = this.data;
                    var query = this.createSelectorQuery();
                    query.selectAll('.index_list_item').boundingClientRect(function (rects) {
                        var result = rects;
                        data._tops = result.map(function (item) {
                            return item.top;
                        });
                    }).exec();
                    query.select('.anchor-list').boundingClientRect(function (rect) {
                        data._anchorItemH = rect.height / data.alphabet.length;
                        data._anchorItemW = rect.width;
                        data._anchorTop = rect.top;
                    }).exec();
                    query.select('.page-select-index').boundingClientRect(function (rect) {
                        data._listUpperBound = rect.top;
                    });
                },
                removeTouching: function removeTouching() {
                    var _this2 = this;

                    setTimeout(function () {
                        _this2.setData({ touching: false });
                    }, 150);
                },
                onScroll: function onScroll(e) {
                    this.__onScroll(e);
                },
                _onScroll: function _onScroll(e) {
                    var data = this.data;
                    var _tops = data._tops,
                        alphabet = data.alphabet;

                    var scrollTop = e.detail.scrollTop;
                    var current = '';
                    if (scrollTop < _tops[0]) {
                        current = alphabet[0];
                    } else {
                        for (var i = 0, len = _tops.length; i < len - 1; i++) {
                            if (scrollTop >= _tops[i] && scrollTop < _tops[i + 1]) {
                                current = alphabet[i];
                            }
                        }
                    }
                    if (!current) current = alphabet[alphabet.length - 1];
                    this.setData({ current: current });
                }
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/row/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 13);
    /******/
}(
/************************************************************************/
/******/{

    /***/13:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        Component({
            properties: {},
            relations: {
                "../col/index": {
                    type: 'child'
                }
            },
            data: {
                classStyle: ""
            },
            attached: function attached() {},

            methods: {}
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/select-text/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 10);
    /******/
}(
/************************************************************************/
/******/{

    /***/10:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        Component({
            options: {
                addGlobalClass: true
            },
            properties: {
                space: {
                    type: String,
                    value: ''
                },
                decode: {
                    type: Boolean,
                    value: false
                },
                placement: {
                    type: String,
                    value: 'top'
                },
                showCopyBtn: {
                    type: Boolean,
                    value: false
                },
                value: {
                    type: String,
                    value: ''
                },
                zIndex: {
                    type: Number,
                    value: 99
                },
                activeBgColor: {
                    type: String,
                    value: '#DEDEDE'
                },
                onDocumentTap: {
                    type: Object,
                    value: {}
                }
            },
            observers: {
                onDocumentTap: function onDocumentTap() {
                    this.setData({
                        showToolTip: false
                    });
                }
            },
            data: {
                showToolTip: false
            },
            methods: {
                handleLongPress: function handleLongPress() {
                    if (!this.data.showCopyBtn) return;
                    this.setData({
                        showToolTip: true
                    });
                },
                handleCopy: function handleCopy() {
                    this.setData({
                        showToolTip: false
                    });
                    wx.setClipboardData({
                        data: this.data.value
                    });
                    this.triggerEvent('copy', {});
                },
                stopPropagation: function stopPropagation(e) {}
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/sticky/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 8);
    /******/
}(
/************************************************************************/
/******/{

    /***/8:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        var selectQuery = __webpack_require__(9);
        var target = '.weui-sticky';
        Component({
            options: {
                addGlobalClass: true,
                pureDataPattern: /^_/,
                multipleSlots: true
            },
            behaviors: [selectQuery],
            properties: {
                offsetTop: {
                    type: Number,
                    value: 0
                },
                zIndex: {
                    type: Number,
                    value: 99
                },
                disabled: {
                    type: Boolean,
                    value: false
                },
                container: {
                    type: null
                }
            },
            data: {
                fixed: false,
                height: 0,
                _attached: false,
                _containerHeight: 0
            },
            observers: {
                disabled: function disabled(newVal) {
                    if (!this._attached) return;
                    newVal ? this.disconnectObserver() : this.initObserver();
                },
                container: function container(newVal) {
                    if (typeof newVal !== 'function' || !this.data.height) return;
                    this.observerContainer();
                }
            },
            lifetimes: {
                attached: function attached() {
                    this.data._attached = true;
                    if (!this.data.disabled) this.initObserver();
                },
                detached: function detached() {
                    this.data._attached = false;
                    this.disconnectObserver();
                }
            },
            methods: {
                getContainerRect: function getContainerRect() {
                    var nodesRef = this.data.container();
                    return new Promise(function (resolve) {
                        return nodesRef.boundingClientRect(resolve).exec();
                    });
                },
                initObserver: function initObserver() {
                    var _this = this;

                    this.disconnectObserver();
                    this.getRect(target).then(function (rect) {
                        _this.setData({
                            height: rect.height
                        });
                        _this.observerContent();
                        _this.observerContainer();
                    });
                },
                disconnectObserver: function disconnectObserver(observerName) {
                    if (observerName) {
                        var observer = this[observerName];
                        observer && observer.disconnect();
                    } else {
                        this.contentObserver && this.contentObserver.disconnect();
                        this.containerObserver && this.containerObserver.disconnect();
                    }
                },
                observerContent: function observerContent() {
                    var _this2 = this;

                    var offsetTop = this.data.offsetTop;

                    this.disconnectObserver('contentObserver');
                    var contentObserver = this.createIntersectionObserver({
                        thresholds: [1],
                        initialRatio: 1
                    });
                    contentObserver.relativeToViewport({
                        top: -offsetTop
                    });
                    contentObserver.observe(target, function (res) {
                        if (_this2.data.disabled) return;
                        _this2.setFixed(res.boundingClientRect.top);
                    });
                    this.contentObserver = contentObserver;
                },
                observerContainer: function observerContainer() {
                    var _this3 = this;

                    var _data = this.data,
                        container = _data.container,
                        height = _data.height,
                        offsetTop = _data.offsetTop;

                    if (typeof container !== 'function') return;
                    this.disconnectObserver('containerObserver');
                    this.getContainerRect().then(function (rect) {
                        _this3.getRect(target).then(function (contentRect) {
                            var _contentTop = contentRect.top;
                            var _containerTop = rect.top;
                            var _containerHeight = rect.height;
                            var _relativeTop = _contentTop - _containerTop;
                            var containerObserver = _this3.createIntersectionObserver({
                                thresholds: [1],
                                initialRatio: 1
                            });
                            containerObserver.relativeToViewport({
                                top: _containerHeight - height - offsetTop - _relativeTop
                            });
                            containerObserver.observe(target, function (res) {
                                if (_this3.data.disabled) return;
                                _this3.setFixed(res.boundingClientRect.top);
                            });
                            _this3.data._relativeTop = _relativeTop;
                            _this3.data._containerHeight = _containerHeight;
                            _this3.containerObserver = containerObserver;
                        });
                    });
                },
                setFixed: function setFixed(top) {
                    var _data2 = this.data,
                        height = _data2.height,
                        _containerHeight = _data2._containerHeight,
                        _relativeTop = _data2._relativeTop,
                        offsetTop = _data2.offsetTop;

                    var fixed = _containerHeight && height ? top >= height + offsetTop + _relativeTop - _containerHeight && top < offsetTop : top < offsetTop;
                    this.triggerEvent('scroll', {
                        scrollTop: top,
                        isFixed: fixed
                    });
                    this.setData({ fixed: fixed });
                }
            }
        });

        /***/
    },

    /***/9:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        module.exports = Behavior({
            methods: {
                getRect: function getRect(selector) {
                    var _this = this;

                    return new Promise(function (resolve, reject) {
                        _this.createSelectorQuery().select(selector).boundingClientRect(function (rect) {
                            if (rect) {
                                resolve(rect);
                            } else {
                                reject(new Error("can not find selector: " + selector));
                            }
                        }).exec();
                    });
                },
                getAllRects: function getAllRects(selector) {
                    var _this2 = this;

                    return new Promise(function (resolve, reject) {
                        _this2.createSelectorQuery().selectAll(selector).boundingClientRect(function (rects) {
                            if (rects && rects.lenght > 0) {
                                resolve(rects);
                            } else {
                                reject(new Error("can not find selector: " + selector));
                            }
                        }).exec();
                    });
                }
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/tabs/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 5);
    /******/
}(
/************************************************************************/
/******/{

    /***/5:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        Component({
            options: {
                addGlobalClass: true,
                pureDataPattern: /^_/,
                multipleSlots: true
            },
            properties: {
                tabs: { type: Array, value: [] },
                tabClass: { type: String, value: '' },
                swiperClass: { type: String, value: '' },
                activeClass: { type: String, value: '' },
                tabUnderlineColor: { type: String, value: '#07c160' },
                tabActiveTextColor: { type: String, value: '#000000' },
                tabInactiveTextColor: { type: String, value: '#000000' },
                tabBackgroundColor: { type: String, value: '#ffffff' },
                activeTab: { type: Number, value: 0 },
                swipeable: { type: Boolean, value: true },
                animation: { type: Boolean, value: true },
                duration: { type: Number, value: 500 }
            },
            data: {
                currentView: 0
            },
            observers: {
                activeTab: function activeTab(_activeTab) {
                    var len = this.data.tabs.length;
                    if (len === 0) return;
                    var currentView = _activeTab - 1;
                    if (currentView < 0) currentView = 0;
                    if (currentView > len - 1) currentView = len - 1;
                    this.setData({ currentView: currentView });
                }
            },
            lifetimes: {
                created: function created() {}
            },
            methods: {
                handleTabClick: function handleTabClick(e) {
                    var index = e.currentTarget.dataset.index;
                    this.setData({ activeTab: index });
                    this.triggerEvent('tabclick', { index: index });
                },
                handleSwiperChange: function handleSwiperChange(e) {
                    var index = e.detail.current;
                    this.setData({ activeTab: index });
                    this.triggerEvent('change', { index: index });
                }
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/video-swiper/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 0);
    /******/
}(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, exports, __webpack_require__) {

    "use strict";

    Component({
        options: {
            addGlobalClass: true,
            pureDataPattern: /^_/
        },
        properties: {
            duration: {
                type: Number,
                value: 500
            },
            easingFunction: {
                type: String,
                value: 'default'
            },
            loop: {
                type: Boolean,
                value: true
            },
            videoList: {
                type: Array,
                value: [],
                observer: function observer() {
                    var newVal = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

                    this._videoListChanged(newVal);
                }
            }
        },
        data: {
            nextQueue: [],
            prevQueue: [],
            curQueue: [],
            circular: false,
            _last: 1,
            _change: -1,
            _invalidUp: 0,
            _invalidDown: 0,
            _videoContexts: []
        },
        lifetimes: {
            attached: function attached() {
                this.data._videoContexts = [wx.createVideoContext('video_0', this), wx.createVideoContext('video_1', this), wx.createVideoContext('video_2', this)];
            }
        },
        methods: {
            _videoListChanged: function _videoListChanged(newVal) {
                var _this = this;

                var data = this.data;
                newVal.forEach(function (item) {
                    data.nextQueue.push(item);
                });
                if (data.curQueue.length === 0) {
                    this.setData({
                        curQueue: data.nextQueue.splice(0, 3)
                    }, function () {
                        _this.playCurrent(1);
                    });
                }
            },
            animationfinish: function animationfinish(e) {
                var _data = this.data,
                    _last = _data._last,
                    _change = _data._change,
                    curQueue = _data.curQueue,
                    prevQueue = _data.prevQueue,
                    nextQueue = _data.nextQueue;

                var current = e.detail.current;
                var diff = current - _last;
                if (diff === 0) return;
                this.data._last = current;
                this.playCurrent(current);
                this.triggerEvent('change', { activeId: curQueue[current].id });
                var direction = diff === 1 || diff === -2 ? 'up' : 'down';
                if (direction === 'up') {
                    if (this.data._invalidDown === 0) {
                        var change = (_change + 1) % 3;
                        var add = nextQueue.shift();
                        var remove = curQueue[change];
                        if (add) {
                            prevQueue.push(remove);
                            curQueue[change] = add;
                            this.data._change = change;
                        } else {
                            this.data._invalidUp += 1;
                        }
                    } else {
                        this.data._invalidDown -= 1;
                    }
                }
                if (direction === 'down') {
                    if (this.data._invalidUp === 0) {
                        var _change2 = _change;
                        var _remove = curQueue[_change2];
                        var _add = prevQueue.pop();
                        if (_add) {
                            curQueue[_change2] = _add;
                            nextQueue.unshift(_remove);
                            this.data._change = (_change2 - 1 + 3) % 3;
                        } else {
                            this.data._invalidDown += 1;
                        }
                    } else {
                        this.data._invalidUp -= 1;
                    }
                }
                var circular = true;
                if (nextQueue.length === 0 && current !== 0) {
                    circular = false;
                }
                if (prevQueue.length === 0 && current !== 2) {
                    circular = false;
                }
                this.setData({
                    curQueue: curQueue,
                    circular: circular
                });
            },
            playCurrent: function playCurrent(current) {
                this.data._videoContexts.forEach(function (ctx, index) {
                    index !== current ? ctx.pause() : ctx.play();
                });
            },
            onPlay: function onPlay(e) {
                this.trigger(e, 'play');
            },
            onPause: function onPause(e) {
                this.trigger(e, 'pause');
            },
            onEnded: function onEnded(e) {
                this.trigger(e, 'ended');
            },
            onError: function onError(e) {
                this.trigger(e, 'error');
            },
            onTimeUpdate: function onTimeUpdate(e) {
                this.trigger(e, 'timeupdate');
            },
            onWaiting: function onWaiting(e) {
                this.trigger(e, 'wait');
            },
            onProgress: function onProgress(e) {
                this.trigger(e, 'progress');
            },
            onLoadedMetaData: function onLoadedMetaData(e) {
                this.trigger(e, 'loadedmetadata');
            },
            trigger: function trigger(e, type) {
                var ext = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

                var detail = e.detail;
                var activeId = e.target.dataset.id;
                this.triggerEvent(type, Object.assign(Object.assign(Object.assign({}, detail), { activeId: activeId }), ext));
            }
        }
    });

    /***/
}]
/******/);
});
define("miniprogram_npm/@miniprogram-component-plus/vtabs-content/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 7);
    /******/
}(
/************************************************************************/
/******/{

    /***/7:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        Component({
            options: {
                addGlobalClass: true,
                multipleSlots: true
            },
            properties: {
                tabIndex: {
                    type: Number,
                    value: 0
                }
            },
            relations: {
                '../vtabs/index': {
                    type: 'parent'
                }
            },
            lifetimes: {
                attached: function attached() {}
            },
            methods: {
                calcHeight: function calcHeight(callback) {
                    var query = this.createSelectorQuery();
                    query.select('.weui-vtabs-content__item').boundingClientRect(function (rect) {
                        callback && callback(rect);
                    }).exec();
                }
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/@miniprogram-component-plus/vtabs/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/var installedModules = {};
    /******/
    /******/ // The require function
    /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/__webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/__webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
            __webpack_require__.d(ns, key, function (key) {
                return value[key];
            }.bind(null, key));
        } /******/return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
            return module['default'];
        } :
        /******/function getModuleExports() {
            return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/__webpack_require__.p = "";
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/return __webpack_require__(__webpack_require__.s = 6);
    /******/
}(
/************************************************************************/
/******/{

    /***/6:
    /***/function _(module, exports, __webpack_require__) {

        "use strict";

        Component({
            options: {
                addGlobalClass: true,
                pureDataPattern: /^_/,
                multipleSlots: true
            },
            properties: {
                vtabs: { type: Array, value: [] },
                tabBarClass: { type: String, value: '' },
                activeClass: { type: String, value: '' },
                tabLineColor: { type: String, value: '#ff0000' },
                tabInactiveTextColor: { type: String, value: '#000000' },
                tabActiveTextColor: { type: String, value: '#ff0000' },
                tabInactiveBgColor: { type: String, value: '#eeeeee' },
                tabActiveBgColor: { type: String, value: '#ffffff' },
                activeTab: { type: Number, value: 0 },
                animation: { type: Boolean, value: true }
            },
            data: {
                currentView: 0,
                contentScrollTop: 0,
                _heightRecords: [],
                _contentHeight: {}
            },
            observers: {
                activeTab: function activeTab(_activeTab) {
                    this.scrollTabBar(_activeTab);
                }
            },
            relations: {
                '../vtabs-content/index': {
                    type: 'child',
                    linked: function linked(target) {
                        var _this = this;

                        target.calcHeight(function (rect) {
                            _this.data._contentHeight[target.data.tabIndex] = rect.height;
                            if (_this._calcHeightTimer) {
                                clearTimeout(_this._calcHeightTimer);
                            }
                            _this._calcHeightTimer = setTimeout(function () {
                                _this.calcHeight();
                            }, 100);
                        });
                    },
                    unlinked: function unlinked(target) {
                        delete this.data._contentHeight[target.data.tabIndex];
                    }
                }
            },
            lifetimes: {
                attached: function attached() {}
            },
            methods: {
                calcHeight: function calcHeight() {
                    var length = this.data.vtabs.length;
                    var _contentHeight = this.data._contentHeight;
                    var _heightRecords = [];
                    var temp = 0;
                    for (var i = 0; i < length; i++) {
                        _heightRecords[i] = temp + (_contentHeight[i] || 0);
                        temp = _heightRecords[i];
                    }
                    this.data._heightRecords = _heightRecords;
                },
                scrollTabBar: function scrollTabBar(index) {
                    var len = this.data.vtabs.length;
                    if (len === 0) return;
                    var currentView = index < 6 ? 0 : index - 5;
                    if (currentView >= len) currentView = len - 1;
                    this.setData({ currentView: currentView });
                },
                handleTabClick: function handleTabClick(e) {
                    var _heightRecords = this.data._heightRecords;
                    var index = e.currentTarget.dataset.index;
                    var contentScrollTop = _heightRecords[index - 1] || 0;
                    this.triggerEvent('tabclick', { index: index });
                    this.setData({
                        activeTab: index,
                        contentScrollTop: contentScrollTop
                    });
                },
                handleContentScroll: function handleContentScroll(e) {
                    var _heightRecords = this.data._heightRecords;
                    if (_heightRecords.length === 0) return;
                    var length = this.data.vtabs.length;
                    var scrollTop = e.detail.scrollTop;
                    var index = 0;
                    if (scrollTop >= _heightRecords[0]) {
                        for (var i = 1; i < length; i++) {
                            if (scrollTop >= _heightRecords[i - 1] && scrollTop < _heightRecords[i]) {
                                index = i;
                                break;
                            }
                        }
                    }
                    if (index !== this.data.activeTab) {
                        this.triggerEvent('change', { index: index });
                        this.setData({ activeTab: index });
                    }
                }
            }
        });

        /***/
    }

    /******/ });
});
define("miniprogram_npm/eventemitter3/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports = function () {
  var __MODS__ = {};
  var __DEFINE__ = function __DEFINE__(modId, func, req) {
    var m = { exports: {}, _tempexports: {} };__MODS__[modId] = { status: 0, func: func, req: req, m: m };
  };
  var __REQUIRE__ = function __REQUIRE__(modId, source) {
    if (!__MODS__[modId]) return require(source);if (!__MODS__[modId].status) {
      var m = __MODS__[modId].m;m._exports = m._tempexports;var desp = Object.getOwnPropertyDescriptor(m, "exports");if (desp && desp.configurable) Object.defineProperty(m, "exports", { set: function set(val) {
          if ((typeof val === "undefined" ? "undefined" : _typeof(val)) === "object" && val !== m._exports) {
            m._exports.__proto__ = val.__proto__;Object.keys(val).forEach(function (k) {
              m._exports[k] = val[k];
            });
          }m._tempexports = val;
        }, get: function get() {
          return m._tempexports;
        } });__MODS__[modId].status = 1;__MODS__[modId].func(__MODS__[modId].req, m, m.exports);
    }return __MODS__[modId].m.exports;
  };
  var __REQUIRE_WILDCARD__ = function __REQUIRE_WILDCARD__(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var k in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, k)) newObj[k] = obj[k];
        }
      }newObj.default = obj;return newObj;
    }
  };
  var __REQUIRE_DEFAULT__ = function __REQUIRE_DEFAULT__(obj) {
    return obj && obj.__esModule ? obj.default : obj;
  };
  __DEFINE__(1603952260665, function (require, module, exports) {

    var has = Object.prototype.hasOwnProperty,
        prefix = '~';

    /**
     * Constructor to create a storage for our `EE` objects.
     * An `Events` instance is a plain object whose properties are event names.
     *
     * @constructor
     * @private
     */
    function Events() {}

    //
    // We try to not inherit from `Object.prototype`. In some engines creating an
    // instance in this way is faster than calling `Object.create(null)` directly.
    // If `Object.create(null)` is not supported we prefix the event names with a
    // character to make sure that the built-in object properties are not
    // overridden or used as an attack vector.
    //
    if (Object.create) {
      Events.prototype = Object.create(null);

      //
      // This hack is needed because the `__proto__` property is still inherited in
      // some old browsers like Android 4, iPhone 5.1, Opera 11 and Safari 5.
      //
      if (!new Events().__proto__) prefix = false;
    }

    /**
     * Representation of a single event listener.
     *
     * @param {Function} fn The listener function.
     * @param {*} context The context to invoke the listener with.
     * @param {Boolean} [once=false] Specify if the listener is a one-time listener.
     * @constructor
     * @private
     */
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }

    /**
     * Add a listener for a given event.
     *
     * @param {EventEmitter} emitter Reference to the `EventEmitter` instance.
     * @param {(String|Symbol)} event The event name.
     * @param {Function} fn The listener function.
     * @param {*} context The context to invoke the listener with.
     * @param {Boolean} once Specify if the listener is a one-time listener.
     * @returns {EventEmitter}
     * @private
     */
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== 'function') {
        throw new TypeError('The listener must be a function');
      }

      var listener = new EE(fn, context || emitter, once),
          evt = prefix ? prefix + event : event;

      if (!emitter._events[evt]) emitter._events[evt] = listener, emitter._eventsCount++;else if (!emitter._events[evt].fn) emitter._events[evt].push(listener);else emitter._events[evt] = [emitter._events[evt], listener];

      return emitter;
    }

    /**
     * Clear event by name.
     *
     * @param {EventEmitter} emitter Reference to the `EventEmitter` instance.
     * @param {(String|Symbol)} evt The Event name.
     * @private
     */
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0) emitter._events = new Events();else delete emitter._events[evt];
    }

    /**
     * Minimal `EventEmitter` interface that is molded against the Node.js
     * `EventEmitter` interface.
     *
     * @constructor
     * @public
     */
    function EventEmitter() {
      this._events = new Events();
      this._eventsCount = 0;
    }

    /**
     * Return an array listing the events for which the emitter has registered
     * listeners.
     *
     * @returns {Array}
     * @public
     */
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [],
          events,
          name;

      if (this._eventsCount === 0) return names;

      for (name in events = this._events) {
        if (has.call(events, name)) names.push(prefix ? name.slice(1) : name);
      }

      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }

      return names;
    };

    /**
     * Return the listeners registered for a given event.
     *
     * @param {(String|Symbol)} event The event name.
     * @returns {Array} The registered listeners.
     * @public
     */
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event,
          handlers = this._events[evt];

      if (!handlers) return [];
      if (handlers.fn) return [handlers.fn];

      for (var i = 0, l = handlers.length, ee = new Array(l); i < l; i++) {
        ee[i] = handlers[i].fn;
      }

      return ee;
    };

    /**
     * Return the number of listeners listening to a given event.
     *
     * @param {(String|Symbol)} event The event name.
     * @returns {Number} The number of listeners.
     * @public
     */
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event,
          listeners = this._events[evt];

      if (!listeners) return 0;
      if (listeners.fn) return 1;
      return listeners.length;
    };

    /**
     * Calls each of the listeners registered for a given event.
     *
     * @param {(String|Symbol)} event The event name.
     * @returns {Boolean} `true` if the event had listeners, else `false`.
     * @public
     */
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;

      if (!this._events[evt]) return false;

      var listeners = this._events[evt],
          len = arguments.length,
          args,
          i;

      if (listeners.fn) {
        if (listeners.once) this.removeListener(event, listeners.fn, undefined, true);

        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }

        for (i = 1, args = new Array(len - 1); i < len; i++) {
          args[i - 1] = arguments[i];
        }

        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length,
            j;

        for (i = 0; i < length; i++) {
          if (listeners[i].once) this.removeListener(event, listeners[i].fn, undefined, true);

          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);break;
            default:
              if (!args) for (j = 1, args = new Array(len - 1); j < len; j++) {
                args[j - 1] = arguments[j];
              }

              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }

      return true;
    };

    /**
     * Add a listener for a given event.
     *
     * @param {(String|Symbol)} event The event name.
     * @param {Function} fn The listener function.
     * @param {*} [context=this] The context to invoke the listener with.
     * @returns {EventEmitter} `this`.
     * @public
     */
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };

    /**
     * Add a one-time listener for a given event.
     *
     * @param {(String|Symbol)} event The event name.
     * @param {Function} fn The listener function.
     * @param {*} [context=this] The context to invoke the listener with.
     * @returns {EventEmitter} `this`.
     * @public
     */
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };

    /**
     * Remove the listeners of a given event.
     *
     * @param {(String|Symbol)} event The event name.
     * @param {Function} fn Only remove the listeners that match this function.
     * @param {*} context Only remove the listeners that have this context.
     * @param {Boolean} once Only remove one-time listeners.
     * @returns {EventEmitter} `this`.
     * @public
     */
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;

      if (!this._events[evt]) return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }

      var listeners = this._events[evt];

      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length; i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }

        //
        // Reset the array, or remove it completely if we have no more listeners.
        //
        if (events.length) this._events[evt] = events.length === 1 ? events[0] : events;else clearEvent(this, evt);
      }

      return this;
    };

    /**
     * Remove all listeners, or those of the specified event.
     *
     * @param {(String|Symbol)} [event] The event name.
     * @returns {EventEmitter} `this`.
     * @public
     */
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;

      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt]) clearEvent(this, evt);
      } else {
        this._events = new Events();
        this._eventsCount = 0;
      }

      return this;
    };

    //
    // Alias methods names because people roll like that.
    //
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;

    //
    // Expose the prefix.
    //
    EventEmitter.prefixed = prefix;

    //
    // Allow `EventEmitter` to be imported as module namespace.
    //
    EventEmitter.EventEmitter = EventEmitter;

    //
    // Expose the module.
    //
    if ('undefined' !== typeof module) {
      module.exports = EventEmitter;
    }
  }, function (modId) {
    var map = {};return __REQUIRE__(map[modId], modId);
  });
  return __REQUIRE__(1603952260665);
}();
//# sourceMappingURL=index.js.map
});
define("miniprogram_npm/miniprogram-barrage/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
      /******/
    }
    /******/
  };
  /******/
  /******/ // define __esModule on exports
  /******/__webpack_require__.r = function (exports) {
    /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
      /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
      /******/
    }
    /******/Object.defineProperty(exports, '__esModule', { value: true });
    /******/
  };
  /******/
  /******/ // create a fake namespace object
  /******/ // mode & 1: value is a module id, require it
  /******/ // mode & 2: merge all properties of value into the ns
  /******/ // mode & 4: return value when already ns object
  /******/ // mode & 8|1: behave like require
  /******/__webpack_require__.t = function (value, mode) {
    /******/if (mode & 1) value = __webpack_require__(value);
    /******/if (mode & 8) return value;
    /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
    /******/var ns = Object.create(null);
    /******/__webpack_require__.r(ns);
    /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
    /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
      __webpack_require__.d(ns, key, function (key) {
        return value[key];
      }.bind(null, key));
    } /******/return ns;
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 1);
  /******/
}(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  // 获取字节长度，中文算2个字节

  function getStrLen(str) {
    // eslint-disable-next-line no-control-regex
    return str.replace(/[^\x00-\xff]/g, 'aa').length;
  }

  // 截取指定字节长度的子串
  function substring(str, n) {
    if (!str) return '';

    var len = getStrLen(str);
    if (n >= len) return str;

    var l = 0;
    var result = '';
    for (var i = 0; i < str.length; i++) {
      var ch = str.charAt(i);
      // eslint-disable-next-line no-control-regex
      l = /[^\x00-\xff]/i.test(ch) ? l + 2 : l + 1;
      result += ch;
      if (l >= n) break;
    }
    return result;
  }

  function getRandom() {
    var max = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 10;
    var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    return Math.floor(Math.random() * (max - min) + min);
  }

  function getFontSize(font) {
    var reg = /(\d+)(px)/i;
    var match = font.match(reg);
    return match && match[1] || 10;
  }

  function compareVersion(v1, v2) {
    v1 = v1.split('.');
    v2 = v2.split('.');
    var len = Math.max(v1.length, v2.length);

    while (v1.length < len) {
      v1.push('0');
    }
    while (v2.length < len) {
      v2.push('0');
    }

    for (var i = 0; i < len; i++) {
      var num1 = parseInt(v1[i], 10);
      var num2 = parseInt(v2[i], 10);

      if (num1 > num2) {
        return 1;
      } else if (num1 < num2) {
        return -1;
      }
    }
    return 0;
  }

  module.exports = {
    getStrLen: getStrLen,
    substring: substring,
    getRandom: getRandom,
    getFontSize: getFontSize,
    compareVersion: compareVersion
  };

  /***/
},
/* 1 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var _barrageDom = __webpack_require__(2);

  var _barrageDom2 = _interopRequireDefault(_barrageDom);

  var _barrageCanvas = __webpack_require__(3);

  var _barrageCanvas2 = _interopRequireDefault(_barrageCanvas);

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
  }

  Component({
    options: {
      addGlobalClass: true
    },

    properties: {
      zIndex: {
        type: Number,
        value: 10
      },

      renderingMode: {
        type: String,
        value: 'canvas'
      }
    },

    methods: {
      getBarrageInstance: function getBarrageInstance() {
        var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        opt.comp = this;
        this.barrageInstance = this.data.renderingMode === 'dom' ? new _barrageDom2.default(opt) : new _barrageCanvas2.default(opt);
        return this.barrageInstance;
      },
      onAnimationend: function onAnimationend(e) {
        var _e$currentTarget$data = e.currentTarget.dataset,
            tunnelid = _e$currentTarget$data.tunnelid,
            bulletid = _e$currentTarget$data.bulletid;

        this.barrageInstance.animationend({
          tunnelId: tunnelid,
          bulletId: bulletid
        });
      },
      onTapBullet: function onTapBullet(e) {
        var _e$currentTarget$data2 = e.currentTarget.dataset,
            tunnelid = _e$currentTarget$data2.tunnelid,
            bulletid = _e$currentTarget$data2.bulletid;

        this.barrageInstance.tapBullet({
          tunnelId: tunnelid,
          bulletId: bulletid
        });
      }
    }
  });

  /***/
},
/* 2 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  exports.__esModule = true;

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var _require = __webpack_require__(0),
      substring = _require.substring,
      getRandom = _require.getRandom,
      getFontSize = _require.getFontSize;

  var Bullet = function () {
    function Bullet() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _classCallCheck(this, Bullet);

      this.bulletId = opt.bulletId;
      this.addContent(opt);
    }

    /**
     * image 结构
     * {
     *   head: {src, width, height},
     *   tail: {src, width, height},
     *   gap: 4 // 图片与文本间隔
     * }
     */

    Bullet.prototype.addContent = function addContent() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var defaultBulletOpt = {
        duration: 0, // 动画时长
        passtime: 0, // 弹幕穿越右边界耗时
        content: '', // 文本
        color: '#000000', // 默认黑色
        width: 0, // 弹幕宽度
        height: 0, // 弹幕高度
        image: {}, // 图片
        paused: false // 是否暂停
      };
      Object.assign(this, defaultBulletOpt, opt);
    };

    Bullet.prototype.removeContent = function removeContent() {
      this.addContent({});
    };

    return Bullet;
  }();

  // tunnel（轨道）


  var Tunnel = function () {
    function Tunnel() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _classCallCheck(this, Tunnel);

      var defaultTunnelOpt = {
        tunnelId: 0,
        height: 0, // 轨道高度
        width: 0, // 轨道宽度
        safeGap: 4, // 相邻弹幕安全间隔
        maxNum: 10, // 缓冲队列长度
        bullets: [], // 弹幕
        last: -1, // 上一条发送的弹幕序号
        bulletStatus: [], // 0 空闲，1 占用中
        disabled: false, // 禁用中
        sending: false, // 弹幕正在发送
        timer: null // 定时器
      };
      Object.assign(this, defaultTunnelOpt, opt);
      this.bulletStatus = new Array(this.maxNum).fill(0);
      for (var i = 0; i < this.maxNum; i++) {
        this.bullets.push(new Bullet({
          bulletId: i
        }));
      }
    }

    Tunnel.prototype.disable = function disable() {
      this.disabled = true;
      this.last = -1;
      this.sending = false;
      this.bulletStatus = new Array(this.maxNum).fill(1);
      this.bullets.forEach(function (bullet) {
        return bullet.removeContent();
      });
    };

    Tunnel.prototype.enable = function enable() {
      if (this.disabled) {
        this.bulletStatus = new Array(this.maxNum).fill(0);
      }
      this.disabled = false;
    };

    Tunnel.prototype.clear = function clear() {
      this.last = -1;
      this.sending = false;
      this.bulletStatus = new Array(this.maxNum).fill(0);
      this.bullets.forEach(function (bullet) {
        return bullet.removeContent();
      });
      if (this.timer) {
        clearTimeout(this.timer);
      }
    };

    Tunnel.prototype.getIdleBulletIdx = function getIdleBulletIdx() {
      var idle = this.bulletStatus.indexOf(0, this.last + 1);
      if (idle === -1) {
        idle = this.bulletStatus.indexOf(0);
      }

      return idle;
    };

    Tunnel.prototype.getIdleBulletNum = function getIdleBulletNum() {
      var count = 0;
      this.bulletStatus.forEach(function (status) {
        if (status === 0) count++;
      });
      return count;
    };

    Tunnel.prototype.addBullet = function addBullet(opt) {
      if (this.disabled) return;
      var idx = this.getIdleBulletIdx();
      if (idx >= 0) {
        this.bulletStatus[idx] = 1;
        this.bullets[idx].addContent(opt);
      }
    };

    Tunnel.prototype.removeBullet = function removeBullet(bulletId) {
      if (this.disabled) return;
      this.bulletStatus[bulletId] = 0;
      var bullet = this.bullets[bulletId];
      bullet.removeContent();
    };

    return Tunnel;
  }();

  // Barrage(控制中心)


  var Barrage = function () {
    function Barrage() {
      var _this = this;

      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _classCallCheck(this, Barrage);

      var defaultBarrageOpt = {
        duration: 10, // 弹幕动画时长
        lineHeight: 1.2, // 弹幕行高
        padding: [0, 0, 0, 0], // 弹幕区四周留白
        alpha: 1, // 全局透明度
        font: '10px sans-serif', // 全局字体
        mode: 'separate', // 弹幕重叠 overlap  不重叠 separate
        range: [0, 1], // 弹幕显示的垂直范围，支持两个值。[0,1]表示弹幕整个随机分布，
        tunnelShow: false, // 显示轨道线
        tunnelMaxNum: 30, // 隧道最大缓冲长度
        maxLength: 30, // 弹幕最大字节长度，汉字算双字节
        safeGap: 4, // 发送时的安全间隔
        enableTap: false, // 点击弹幕停止动画高亮显示
        tunnelHeight: 0,
        tunnelNum: 0,
        tunnels: [],
        idleTunnels: null,
        enableTunnels: null,
        distance: 2000,
        comp: null // 组件实例
      };
      Object.assign(this, defaultBarrageOpt, opt);
      this._ready = false;
      this._deferred = [];

      var query = this.comp.createSelectorQuery();
      query.select('.barrage-area').boundingClientRect(function (res) {
        _this.init(res);
        _this.ready();
      }).exec();
    }

    Barrage.prototype.ready = function ready() {
      var _this2 = this;

      this._ready = true;
      this._deferred.forEach(function (item) {
        // eslint-disable-next-line prefer-spread
        _this2[item.callback].apply(_this2, item.args);
      });

      this._deferred = [];
    };

    Barrage.prototype._delay = function _delay(method, args) {
      this._deferred.push({
        callback: method,
        args: args
      });
    };

    Barrage.prototype.init = function init(opt) {
      this.width = opt.width;
      this.height = opt.height;
      this.fontSize = getFontSize(this.font);
      this.idleTunnels = new Set();
      this.enableTunnels = new Set();
      this.tunnels = [];
      this.availableHeight = this.height - this.padding[0] - this.padding[2];
      this.tunnelHeight = this.fontSize * this.lineHeight;
      this.tunnelNum = Math.floor(this.availableHeight / this.tunnelHeight);
      for (var i = 0; i < this.tunnelNum; i++) {
        this.idleTunnels.add(i); // 空闲的隧道id集合
        this.enableTunnels.add(i); // 可用的隧道id集合

        this.tunnels.push(new Tunnel({ // 隧道集合
          width: this.width,
          height: this.tunnelHeight,
          safeGap: this.safeGap,
          maxNum: this.tunnelMaxNum,
          tunnelId: i
        }));
      }
      this.comp.setData({
        fontSize: this.fontSize,
        tunnelShow: this.tunnelShow,
        tunnels: this.tunnels,
        font: this.font,
        alpha: this.alpha,
        padding: this.padding.map(function (item) {
          return item + 'px';
        }).join(' ')
      });
      // 筛选符合范围的隧道
      this.setRange();
    };

    // 设置显示范围 range: [0,1]


    Barrage.prototype.setRange = function setRange(range) {
      var _this3 = this;

      if (!this._ready) {
        this._delay('setRange', range);
        return;
      }

      range = range || this.range;
      var top = range[0] * this.tunnelNum;
      var bottom = range[1] * this.tunnelNum;
      // 释放符合要求的隧道
      // 找到目前空闲的隧道
      var idleTunnels = new Set();
      var enableTunnels = new Set();
      this.tunnels.forEach(function (tunnel, tunnelId) {
        if (tunnelId >= top && tunnelId < bottom) {
          var disabled = tunnel.disabled;
          tunnel.enable();
          enableTunnels.add(tunnelId);

          if (disabled || _this3.idleTunnels.has(tunnelId)) {
            idleTunnels.add(tunnelId);
          }
        } else {
          tunnel.disable();
        }
      });
      this.idleTunnels = idleTunnels;
      this.enableTunnels = enableTunnels;
      this.range = range;
      this.comp.setData({ tunnels: this.tunnels });
    };

    Barrage.prototype.setFont = function setFont(font) {
      if (!this._ready) {
        this._delay('setFont', font);
        return;
      }

      if (typeof font !== 'string') return;
      this.font = font;
      this.comp.setData({ font: font });
    };

    Barrage.prototype.setAlpha = function setAlpha(alpha) {
      if (!this._ready) {
        this._delay('setAlpha', alpha);
        return;
      }

      if (typeof alpha !== 'number') return;
      this.alpha = alpha;
      this.comp.setData({ alpha: alpha });
    };

    Barrage.prototype.setDuration = function setDuration(duration) {
      if (!this._ready) {
        this._delay('setDuration', duration);
        return;
      }

      if (typeof duration !== 'number') return;
      this.duration = duration;
      this.clear();
    };

    // 开启弹幕


    Barrage.prototype.open = function open() {
      if (!this._ready) {
        this._delay('open');
        return;
      }

      this._isActive = true;
    };

    // 关闭弹幕，清除所有数据


    Barrage.prototype.close = function close() {
      if (!this._ready) {
        this._delay('close');
        return;
      }

      this._isActive = false;
      this.clear();
    };

    Barrage.prototype.clear = function clear() {
      this.tunnels.forEach(function (tunnel) {
        return tunnel.clear();
      });
      this.idleTunnels = new Set(this.enableTunnels);
      this.comp.setData({ tunnels: this.tunnels });
    };

    // 添加一批弹幕，轨道满时会被丢弃


    Barrage.prototype.addData = function addData() {
      var _this4 = this;

      var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

      if (!this._ready) {
        this._delay('addData', data);
        return;
      }

      if (!this._isActive) return;

      data.forEach(function (item) {
        item.content = substring(item.content, _this4.maxLength);
        _this4.addBullet2Tunnel(item);
      });
      this.comp.setData({
        tunnels: this.tunnels
      }, function () {
        _this4.updateBullets();
      });
    };

    // 发送一条弹幕


    Barrage.prototype.send = function send() {
      var _this5 = this;

      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      if (!this._ready) {
        this._delay('send', opt);
        return;
      }
      var tunnel = this.getEnableTunnel();
      if (tunnel === null) return;

      var timer = setInterval(function () {
        var tunnel = _this5.getIdleTunnel();
        if (tunnel) {
          _this5.addData([opt]);
          clearInterval(timer);
        }
      }, 16);
    };

    // 添加至轨道


    Barrage.prototype.addBullet2Tunnel = function addBullet2Tunnel() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var tunnel = this.getIdleTunnel();
      if (tunnel === null) return;

      var tunnelId = tunnel.tunnelId;
      tunnel.addBullet(opt);
      if (tunnel.getIdleBulletNum() === 0) this.removeIdleTunnel(tunnelId);
    };

    Barrage.prototype.updateBullets = function updateBullets() {
      var _this6 = this;

      var self = this;
      var query = this.comp.createSelectorQuery();
      query.selectAll('.bullet-item').boundingClientRect(function (res) {
        if (!_this6._isActive) return;

        for (var i = 0; i < res.length; i++) {
          var _res$i$dataset = res[i].dataset,
              tunnelid = _res$i$dataset.tunnelid,
              bulletid = _res$i$dataset.bulletid;

          var tunnel = self.tunnels[tunnelid];
          var bullet = tunnel.bullets[bulletid];
          bullet.width = res[i].width;
          bullet.height = res[i].height;
        }
        self.animate();
      }).exec();
    };

    Barrage.prototype.animate = function animate() {
      var _this7 = this;

      this.tunnels.forEach(function (tunnel) {
        _this7.tunnelAnimate(tunnel);
      });
    };

    Barrage.prototype.tunnelAnimate = function tunnelAnimate(tunnel) {
      var _this8 = this;

      if (tunnel.disabled || tunnel.sending || !this._isActive) return;

      var next = (tunnel.last + 1) % tunnel.maxNum;
      var bullet = tunnel.bullets[next];

      if (!bullet) return;

      if (bullet.content || bullet.image.head || bullet.image.tail) {
        var _comp$setData;

        tunnel.sending = true;
        tunnel.last = next;
        var duration = this.duration;
        if (this.mode === 'overlap') {
          duration = this.distance * this.duration / (this.distance + bullet.width);
        }
        var passDistance = bullet.width + tunnel.safeGap;
        bullet.duration = duration;
        // 等上一条通过右边界
        bullet.passtime = Math.ceil(passDistance * bullet.duration * 1000 / this.distance);
        this.comp.setData((_comp$setData = {}, _comp$setData['tunnels[' + tunnel.tunnelId + '].bullets[' + bullet.bulletId + ']'] = bullet, _comp$setData), function () {
          tunnel.timer = setTimeout(function () {
            tunnel.sending = false;
            _this8.tunnelAnimate(tunnel);
          }, bullet.passtime);
        });
      }
    };

    Barrage.prototype.showTunnel = function showTunnel() {
      this.comp.setData({
        tunnelShow: true
      });
    };

    Barrage.prototype.hideTunnel = function hideTunnel() {
      this.comp.setData({
        tunnelShow: false
      });
    };

    Barrage.prototype.removeIdleTunnel = function removeIdleTunnel(tunnelId) {
      this.idleTunnels.delete(tunnelId);
    };

    Barrage.prototype.addIdleTunnel = function addIdleTunnel(tunnelId) {
      this.idleTunnels.add(tunnelId);
    };

    // 从可用的隧道中随机挑选一个


    Barrage.prototype.getEnableTunnel = function getEnableTunnel() {
      if (this.enableTunnels.size === 0) return null;
      var enableTunnels = Array.from(this.enableTunnels);
      var index = getRandom(enableTunnels.length);
      return this.tunnels[enableTunnels[index]];
    };

    // 从还有余量的隧道中随机挑选一个


    Barrage.prototype.getIdleTunnel = function getIdleTunnel() {
      if (this.idleTunnels.size === 0) return null;
      var idleTunnels = Array.from(this.idleTunnels);
      var index = getRandom(idleTunnels.length);
      return this.tunnels[idleTunnels[index]];
    };

    Barrage.prototype.animationend = function animationend(opt) {
      var _comp$setData2;

      var tunnelId = opt.tunnelId,
          bulletId = opt.bulletId;

      var tunnel = this.tunnels[tunnelId];
      var bullet = tunnel.bullets[bulletId];

      if (!tunnel || !bullet) return;

      tunnel.removeBullet(bulletId);
      this.addIdleTunnel(tunnelId);
      this.comp.setData((_comp$setData2 = {}, _comp$setData2['tunnels[' + tunnelId + '].bullets[' + bulletId + ']'] = bullet, _comp$setData2));
    };

    Barrage.prototype.tapBullet = function tapBullet(opt) {
      var _comp$setData3;

      if (!this.enableTap) return;

      var tunnelId = opt.tunnelId,
          bulletId = opt.bulletId;

      var tunnel = this.tunnels[tunnelId];
      var bullet = tunnel.bullets[bulletId];
      bullet.paused = !bullet.paused;
      this.comp.setData((_comp$setData3 = {}, _comp$setData3['tunnels[' + tunnelId + '].bullets[' + bulletId + ']'] = bullet, _comp$setData3));
    };

    return Barrage;
  }();

  exports.default = Barrage;

  /***/
},
/* 3 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  exports.__esModule = true;

  var _utils = __webpack_require__(0);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var Bullet = function () {
    function Bullet(barrage) {
      var opt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      _classCallCheck(this, Bullet);

      var defaultBulletOpt = {
        color: '#000000', // 默认黑色
        font: '10px sans-serif',
        fontSize: 10, // 全局字体大小
        content: '',
        textWidth: 0,
        speed: 0, // 根据屏幕停留时长计算
        x: 0,
        y: 0,
        tunnelId: 0,
        // image: {
        //   head: {src, width, height}, // 弹幕头部添加图片
        //   tail: {src, width, height}, // 弹幕尾部添加图片
        //   gap: 4 // 图片与文本间隔
        // }
        image: {},
        imageHead: null, // Image 对象
        imageTail: null
        // status: 0 //0:待播放 1: 未完全进入屏幕 2: 完全进入屏幕 3: 完全退出屏幕
      };
      Object.assign(this, defaultBulletOpt, opt);

      this.barrage = barrage;
      this.ctx = barrage.ctx;
      this.canvas = barrage.canvas;
    }

    Bullet.prototype.move = function move() {
      var _this = this;

      if (this.image.head && !this.imageHead) {
        var Image = this.canvas.createImage();
        Image.src = this.image.head.src;
        Image.onload = function () {
          _this.imageHead = Image;
        };
        Image.onerror = function () {
          // eslint-disable-next-line no-console
          console.log('Fail to load image: ' + _this.image.head.src);
        };
      }

      if (this.image.tail && !this.imageTail) {
        var _Image = this.canvas.createImage();
        _Image.src = this.image.tail.src;
        _Image.onload = function () {
          _this.imageTail = _Image;
        };
        _Image.onerror = function () {
          // eslint-disable-next-line no-console
          console.log('Fail to load image: ' + _this.image.tail.src);
        };
      }

      if (this.imageHead) {
        var _image$head = this.image.head,
            _image$head$width = _image$head.width,
            width = _image$head$width === undefined ? this.fontSize : _image$head$width,
            _image$head$height = _image$head.height,
            height = _image$head$height === undefined ? this.fontSize : _image$head$height,
            _image$head$gap = _image$head.gap,
            gap = _image$head$gap === undefined ? 4 : _image$head$gap;

        var x = this.x - gap - width;
        var y = this.y - 0.5 * height;
        this.ctx.drawImage(this.imageHead, x, y, width, height);
      }

      if (this.imageTail) {
        var _image$tail = this.image.tail,
            _image$tail$width = _image$tail.width,
            _width = _image$tail$width === undefined ? this.fontSize : _image$tail$width,
            _image$tail$height = _image$tail.height,
            _height = _image$tail$height === undefined ? this.fontSize : _image$tail$height,
            _image$tail$gap = _image$tail.gap,
            _gap = _image$tail$gap === undefined ? 4 : _image$tail$gap;

        var _x2 = this.x + this.textWidth + _gap;
        var _y = this.y - 0.5 * _height;
        this.ctx.drawImage(this.imageTail, _x2, _y, _width, _height);
      }

      this.x = this.x - this.speed;
      this.ctx.fillStyle = this.color;
      this.ctx.fillText(this.content, this.x, this.y);
    };

    return Bullet;
  }();

  // tunnel（轨道）


  var Tunnel = function () {
    function Tunnel(barrage) {
      var opt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      _classCallCheck(this, Tunnel);

      var defaultTunnelOpt = {
        activeQueue: [], // 正在屏幕中列表
        nextQueue: [], // 待播放列表
        maxNum: 30,
        freeNum: 30, // 剩余可添加量
        height: 0,
        width: 0,
        disabled: false,
        tunnelId: 0,
        safeArea: 4,
        sending: false // 弹幕正在发送
      };
      Object.assign(this, defaultTunnelOpt, opt);

      this.freeNum = this.maxNum;
      this.barrage = barrage; // 控制中心
      this.ctx = barrage.ctx;
    }

    Tunnel.prototype.disable = function disable() {
      this.disabled = true;
    };

    Tunnel.prototype.enable = function enable() {
      this.disabled = false;
    };

    Tunnel.prototype.clear = function clear() {
      this.activeQueue = [];
      this.nextQueue = [];
      this.sending = false;
      this.freeNum = this.maxNum;
      this.barrage.addIdleTunnel(this.tunnelId);
    };

    Tunnel.prototype.addBullet = function addBullet(bullet) {
      if (this.disabled) return;
      if (this.freeNum === 0) return;
      this.nextQueue.push(bullet);
      this.freeNum--;
      if (this.freeNum === 0) {
        this.barrage.removeIdleTunnel(this.tunnelId);
      }
    };

    Tunnel.prototype.animate = function animate() {
      if (this.disabled) return;
      // 无正在发送弹幕，添加一条
      var nextQueue = this.nextQueue;
      var activeQueue = this.activeQueue;
      if (!this.sending && nextQueue.length > 0) {
        var bullet = nextQueue.shift();
        activeQueue.push(bullet);
        this.freeNum++;
        this.sending = true;
        this.barrage.addIdleTunnel(this.tunnelId);
      }

      if (activeQueue.length > 0) {
        activeQueue.forEach(function (bullet) {
          return bullet.move();
        });
        var head = activeQueue[0];
        var tail = activeQueue[activeQueue.length - 1];
        // 队首移出屏幕
        if (head.x + head.textWidth < 0) {
          activeQueue.shift();
        }
        // 队尾离开超过安全区
        if (tail.x + tail.textWidth + this.safeArea < this.width) {
          this.sending = false;
        }
      }
    };

    return Tunnel;
  }();

  var Barrage = function () {
    function Barrage() {
      var _this2 = this;

      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _classCallCheck(this, Barrage);

      var defaultBarrageOpt = {
        font: '10px sans-serif',
        duration: 15, // 弹幕屏幕停留时长
        lineHeight: 1.2,
        padding: [0, 0, 0, 0],
        tunnelHeight: 0,
        tunnelNum: 0,
        tunnelMaxNum: 30, // 隧道最大缓冲长度
        maxLength: 30, // 最大字节长度，汉字算双字节
        safeArea: 4, // 发送时的安全间隔
        tunnels: [],
        idleTunnels: [],
        enableTunnels: [],
        alpha: 1, // 全局透明度
        mode: 'separate', // 弹幕重叠 overlap  不重叠 separate
        range: [0, 1], // 弹幕显示的垂直范围，支持两个值。[0,1]表示弹幕整个随机分布，
        fps: 60, // 刷新率
        tunnelShow: false, // 显示轨道线
        comp: null // 组件实例
      };
      Object.assign(this, defaultBarrageOpt, opt);
      var systemInfo = wx.getSystemInfoSync();
      this.ratio = systemInfo.pixelRatio;
      this.selector = '#weui-canvas';
      this._ready = false;
      this._deferred = [];

      var query = this.comp.createSelectorQuery();
      query.select(this.selector).boundingClientRect();
      query.select(this.selector).node();
      query.exec(function (res) {
        _this2.canvas = res[1].node;
        _this2.init(res[0]);
        _this2.ready();
      });
    }

    Barrage.prototype.ready = function ready() {
      var _this3 = this;

      this._ready = true;
      this._deferred.forEach(function (item) {
        // eslint-disable-next-line prefer-spread
        _this3[item.callback].apply(_this3, item.args);
      });

      this._deferred = [];
    };

    Barrage.prototype._delay = function _delay(method, args) {
      this._deferred.push({
        callback: method,
        args: args
      });
    };

    Barrage.prototype.init = function init() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      this.width = opt.width;
      this.height = opt.height;
      this.fontSize = (0, _utils.getFontSize)(this.font);
      this.innerDuration = this.transfromDuration2Canvas(this.duration);

      var ratio = this.ratio; // 设备像素比
      this.canvas.width = this.width * ratio;
      this.canvas.height = this.height * ratio;
      this.ctx = this.canvas.getContext('2d');
      this.ctx.scale(ratio, ratio);

      this.ctx.textBaseline = 'middle';
      this.ctx.globalAlpha = this.alpha;
      this.ctx.font = this.font;

      this.idleTunnels = [];
      this.enableTunnels = [];
      this.tunnels = [];

      this.availableHeight = this.height - this.padding[0] - this.padding[2];
      this.tunnelHeight = this.fontSize * this.lineHeight;
      this.tunnelNum = Math.floor(this.availableHeight / this.tunnelHeight);
      for (var i = 0; i < this.tunnelNum; i++) {
        this.idleTunnels.push(i); // 空闲的隧道id集合
        this.enableTunnels.push(i); // 可用的隧道id集合
        this.tunnels.push(new Tunnel(this, { // 隧道集合
          width: this.width,
          height: this.tunnelHeight,
          safeArea: this.safeArea,
          maxNum: this.tunnelMaxNum,
          tunnelId: i
        }));
      }
      // 筛选符合范围的隧道
      this.setRange();
      this._isActive = false;
    };

    Barrage.prototype.transfromDuration2Canvas = function transfromDuration2Canvas(duration) {
      // 2000 是 dom 中移动的距离
      return duration * this.width / 2000;
    };

    // 设置显示范围 range: [0,1]


    Barrage.prototype.setRange = function setRange(range) {
      var _this4 = this;

      if (!this._ready) {
        this._delay('setRange', range);
        return;
      }

      range = range || this.range;
      var top = range[0] * this.tunnelNum;
      var bottom = range[1] * this.tunnelNum;

      // 释放符合要求的隧道
      // 找到目前空闲的隧道
      var idleTunnels = [];
      var enableTunnels = [];
      this.tunnels.forEach(function (tunnel, tunnelId) {
        if (tunnelId >= top && tunnelId < bottom) {
          tunnel.enable();
          enableTunnels.push(tunnelId);
          if (_this4.idleTunnels.indexOf(tunnelId) >= 0) {
            idleTunnels.push(tunnelId);
          }
        } else {
          tunnel.disable();
        }
      });
      this.idleTunnels = idleTunnels;
      this.enableTunnels = enableTunnels;
      this.range = range;
    };

    Barrage.prototype.setFont = function setFont(font) {
      if (!this._ready) {
        this._delay('setFont', font);
        return;
      }

      this.font = font;
      this.fontSize = (0, _utils.getFontSize)(this.font);
      this.ctx.font = font;
    };

    Barrage.prototype.setAlpha = function setAlpha(alpha) {
      if (!this._ready) {
        this._delay('setAlpha', alpha);
        return;
      }

      this.alpha = alpha;
      this.ctx.globalAlpha = alpha;
    };

    Barrage.prototype.setDuration = function setDuration(duration) {
      if (!this._ready) {
        this._delay('setDuration', duration);
        return;
      }

      this.clear();
      this.duration = duration;
      this.innerDuration = this.transfromDuration2Canvas(duration);
    };

    // 开启弹幕


    Barrage.prototype.open = function open() {
      if (!this._ready) {
        this._delay('open');
        return;
      }

      if (this._isActive) return;
      this._isActive = true;
      this.play();
    };

    // 关闭弹幕，清除所有数据


    Barrage.prototype.close = function close() {
      if (!this._ready) {
        this._delay('close');
        return;
      }

      if (!this._isActive) return;
      this._isActive = false;
      this.pause();
      this.clear();
    };

    // 开启弹幕滚动


    Barrage.prototype.play = function play() {
      var _this5 = this;

      this._rAFId = this.canvas.requestAnimationFrame(function () {
        _this5.animate();
        _this5.play();
      });
    };

    // 停止弹幕滚动


    Barrage.prototype.pause = function pause() {
      if (typeof this._rAFId === 'number') {
        this.canvas.cancelAnimationFrame(this._rAFId);
      }
    };

    // 清空屏幕和缓冲的数据


    Barrage.prototype.clear = function clear() {
      this.ctx.clearRect(0, 0, this.width, this.height);
      this.tunnels.forEach(function (tunnel) {
        return tunnel.clear();
      });
    };

    // 添加一批弹幕，轨道满时会被丢弃


    Barrage.prototype.addData = function addData() {
      var _this6 = this;

      var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

      if (!this._ready) {
        this._delay('addData', data);
        return;
      }

      if (!this._isActive) return;
      data.forEach(function (item) {
        return _this6.addBullet2Tunnel(item);
      });
    };

    // 发送一条弹幕
    // 为保证发送成功，选取一条可用隧道，替换待发送队列队头元素


    Barrage.prototype.send = function send() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      if (!this._ready) {
        this._delay('send', opt);
        return;
      }

      var tunnel = this.getEnableTunnel();
      if (tunnel === null) return;

      opt.tunnelId = tunnel.tunnelId;
      var bullet = this.registerBullet(opt);
      tunnel.nextQueue[0] = bullet;
    };

    // 添加至轨道 {content, color}


    Barrage.prototype.addBullet2Tunnel = function addBullet2Tunnel() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var tunnel = this.getIdleTunnel();
      if (tunnel === null) return;

      opt.tunnelId = tunnel.tunnelId;
      var bullet = this.registerBullet(opt);
      tunnel.addBullet(bullet);
    };

    Barrage.prototype.registerBullet = function registerBullet() {
      var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      opt.tunnelId = opt.tunnelId || 0;
      opt.content = (0, _utils.substring)(opt.content, this.maxLength);
      var textWidth = this.getTextWidth(opt.content);
      var distance = this.mode === 'overlap' ? this.width + textWidth : this.width;
      opt.textWidth = textWidth;
      opt.speed = distance / (this.innerDuration * this.fps);
      opt.fontSize = this.fontSize;
      opt.x = this.width;
      opt.y = this.tunnelHeight * (opt.tunnelId + 0.5) + this.padding[0];
      return new Bullet(this, opt);
    };

    // 每帧执行的操作


    Barrage.prototype.animate = function animate() {
      // 清空画面后重绘
      this.ctx.clearRect(0, 0, this.width, this.height);
      if (this.tunnelShow) {
        this.drawTunnel();
      }
      this.tunnels.forEach(function (tunnel) {
        return tunnel.animate();
      });
    };

    Barrage.prototype.showTunnel = function showTunnel() {
      this.tunnelShow = true;
    };

    Barrage.prototype.hideTunnel = function hideTunnel() {
      this.tunnelShow = false;
    };

    Barrage.prototype.removeIdleTunnel = function removeIdleTunnel(tunnelId) {
      var idx = this.idleTunnels.indexOf(tunnelId);
      if (idx >= 0) this.idleTunnels.splice(idx, 1);
    };

    Barrage.prototype.addIdleTunnel = function addIdleTunnel(tunnelId) {
      var idx = this.idleTunnels.indexOf(tunnelId);
      if (idx < 0) this.idleTunnels.push(tunnelId);
    };

    // 从可用的隧道中随机挑选一个


    Barrage.prototype.getEnableTunnel = function getEnableTunnel() {
      if (this.enableTunnels.length === 0) return null;
      var index = (0, _utils.getRandom)(this.enableTunnels.length);
      return this.tunnels[this.enableTunnels[index]];
    };

    // 从还有余量的隧道中随机挑选一个


    Barrage.prototype.getIdleTunnel = function getIdleTunnel() {
      if (this.idleTunnels.length === 0) return null;
      var index = (0, _utils.getRandom)(this.idleTunnels.length);
      return this.tunnels[this.idleTunnels[index]];
    };

    Barrage.prototype.getTextWidth = function getTextWidth(content) {
      this.ctx.font = this.font;
      return Math.ceil(this.ctx.measureText(content).width);
    };

    Barrage.prototype.drawTunnel = function drawTunnel() {
      var ctx = this.ctx;
      var tunnelColor = '#CCB24D';
      for (var i = 0; i <= this.tunnelNum; i++) {
        var y = this.padding[0] + i * this.tunnelHeight;
        ctx.beginPath();
        ctx.strokeStyle = tunnelColor;
        ctx.setLineDash([5, 10]);
        ctx.moveTo(0, y);
        ctx.lineTo(this.width, y);
        ctx.stroke();
        if (i < this.tunnelNum) {
          ctx.fillStyle = tunnelColor;
          ctx.fillText('\u5F39\u9053' + (i + 1), 10, this.tunnelHeight / 2 + y);
        }
      }
    };

    return Barrage;
  }();

  exports.default = Barrage;

  /***/
}]
/******/);
});
define("miniprogram_npm/miniprogram-barrage/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 获取字节长度，中文算2个字节
function getStrLen(str) {
  // eslint-disable-next-line no-control-regex
  return str.replace(/[^\x00-\xff]/g, 'aa').length;
}

// 截取指定字节长度的子串
function substring(str, n) {
  if (!str) return '';

  var len = getStrLen(str);
  if (n >= len) return str;

  var l = 0;
  var result = '';
  for (var i = 0; i < str.length; i++) {
    var ch = str.charAt(i);
    // eslint-disable-next-line no-control-regex
    l = /[^\x00-\xff]/i.test(ch) ? l + 2 : l + 1;
    result += ch;
    if (l >= n) break;
  }
  return result;
}

function getRandom() {
  var max = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 10;
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

  return Math.floor(Math.random() * (max - min) + min);
}

function getFontSize(font) {
  var reg = /(\d+)(px)/i;
  var match = font.match(reg);
  return match && match[1] || 10;
}

function compareVersion(v1, v2) {
  v1 = v1.split('.');
  v2 = v2.split('.');
  var len = Math.max(v1.length, v2.length);

  while (v1.length < len) {
    v1.push('0');
  }
  while (v2.length < len) {
    v2.push('0');
  }

  for (var i = 0; i < len; i++) {
    var num1 = parseInt(v1[i], 10);
    var num2 = parseInt(v2[i], 10);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }
  return 0;
}

module.exports = {
  getStrLen: getStrLen,
  substring: substring,
  getRandom: getRandom,
  getFontSize: getFontSize,
  compareVersion: compareVersion
};
});
define("miniprogram_npm/miniprogram-recycle-view/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
      /******/
    }
    /******/
  };
  /******/
  /******/ // define __esModule on exports
  /******/__webpack_require__.r = function (exports) {
    /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
      /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
      /******/
    }
    /******/Object.defineProperty(exports, '__esModule', { value: true });
    /******/
  };
  /******/
  /******/ // create a fake namespace object
  /******/ // mode & 1: value is a module id, require it
  /******/ // mode & 2: merge all properties of value into the ns
  /******/ // mode & 4: return value when already ns object
  /******/ // mode & 8|1: behave like require
  /******/__webpack_require__.t = function (value, mode) {
    /******/if (mode & 1) value = __webpack_require__(value);
    /******/if (mode & 8) return value;
    /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof2(value)) === 'object' && value && value.__esModule) return value;
    /******/var ns = Object.create(null);
    /******/__webpack_require__.r(ns);
    /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
    /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
      __webpack_require__.d(ns, key, function (key) {
        return value[key];
      }.bind(null, key));
    } /******/return ns;
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 2);
  /******/
}(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var isIPhone = false;
  var deviceWidth = void 0;
  var deviceDPR = void 0;
  var BASE_DEVICE_WIDTH = 750;
  var checkDeviceWidth = function checkDeviceWidth() {
    var info = wx.getSystemInfoSync();
    // console.log('info', info)
    isIPhone = info.platform === 'ios';
    var newDeviceWidth = info.screenWidth || 375;
    var newDeviceDPR = info.pixelRatio || 2;

    if (!isIPhone) {
      // HACK switch width and height when landscape
      // const newDeviceHeight = info.screenHeight || 375
      // 暂时不处理转屏的情况
    }

    if (newDeviceWidth !== deviceWidth || newDeviceDPR !== deviceDPR) {
      deviceWidth = newDeviceWidth;
      deviceDPR = newDeviceDPR;
      // console.info('Updated device width: ' + newDeviceWidth + 'px DPR ' + newDeviceDPR)
    }
  };
  checkDeviceWidth();

  var eps = 1e-4;
  var transformByDPR = function transformByDPR(number) {
    if (number === 0) {
      return 0;
    }
    number = number / BASE_DEVICE_WIDTH * deviceWidth;
    number = Math.floor(number + eps);
    if (number === 0) {
      if (deviceDPR === 1 || !isIPhone) {
        return 1;
      }
      return 0.5;
    }
    return number;
  };

  var rpxRE = /([+-]?\d+(?:\.\d+)?)rpx/gi;
  // const inlineRpxRE = /(?::|\s|\(|\/)([+-]?\d+(?:\.\d+)?)rpx/g

  var transformRpx = function transformRpx(style, inline) {
    if (typeof style !== 'string') {
      return style;
    }
    var re = rpxRE;
    return style.replace(re, function (match, num) {
      return transformByDPR(Number(num)) + (inline ? 'px' : '');
    });
  };

  module.exports = {
    transformRpx: transformRpx
  };

  /***/
},
/* 1 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  module.exports = {};

  /***/
},
/* 2 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  /**
   * recycle-view组件的api使用
   * 提供wx.createRecycleContext进行管理功能
   */

  var RecycleContext = __webpack_require__(3);

  /**
   * @params options参数是object对象，展开的结构如下
        id: recycle-view的id
        dataKey: recycle-item的wx:for绑定的数据变量
        page: recycle-view所在的页面或组件的实例
        itemSize: 函数或者是Object对象，生成每个recycle-item的宽和高
   * @return RecycleContext对象
   */
  module.exports = function (options) {
    return new RecycleContext(options);
  };

  /***/
},
/* 3 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var _typeof = typeof Symbol === "function" && _typeof2(Symbol.iterator) === "symbol" ? function (obj) {
    return typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
  } : function (obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
  };

  /* eslint complexity: ["error", {"max": 50}] */
  var recycleData = __webpack_require__(1);
  var recycleViewportChangeFunc = __webpack_require__(4);
  var transformRpx = __webpack_require__(0);

  var RECT_SIZE = 200;

  // eslint-disable-next-line no-complexity
  function RecycleContext(_ref) {
    var _this = this;

    var id = _ref.id,
        dataKey = _ref.dataKey,
        page = _ref.page,
        itemSize = _ref.itemSize,
        useInPage = _ref.useInPage,
        placeholderClass = _ref.placeholderClass,
        root = _ref.root;

    if (!id || !dataKey || !page || !itemSize) {
      throw new Error('parameter id, dataKey, page, itemSize is required');
    }
    if (typeof itemSize !== 'function' && (typeof itemSize === 'undefined' ? 'undefined' : _typeof(itemSize)) !== 'object') {
      throw new Error('parameter itemSize must be function or object with key width and height');
    }
    if ((typeof itemSize === 'undefined' ? 'undefined' : _typeof(itemSize)) === 'object' && (!itemSize.width || !itemSize.height) && (!itemSize.props || !itemSize.queryClass || !itemSize.dataKey)) {
      throw new Error('parameter itemSize must be function or object with key width and height');
    }
    this.id = id;
    this.dataKey = dataKey;
    this.page = page;
    // 加root参数给useInPage单独使用
    this.root = root;
    this.placeholderClass = placeholderClass;
    page._recycleViewportChange = recycleViewportChangeFunc;
    this.comp = page.selectComponent('#' + id);
    this.itemSize = itemSize;
    this.itemSizeOpt = itemSize;
    // if (!this.comp) {
    // throw `<recycle-view> with id ${id} not found`
    // }
    this.useInPage = useInPage || false;
    if (this.comp) {
      this.comp.context = this;
      this.comp.setPage(page);
      this.comp.setUseInPage(this.useInPage);
    }
    if (this.useInPage && !this.root) {
      throw new Error('parameter root is required when useInPage is true');
    }
    if (this.useInPage) {
      this.oldPageScroll = this.root.onPageScroll;
      // 重写onPageScroll事件
      this.root.onPageScroll = function (e) {
        // this.checkComp();
        if (_this.comp) {
          _this.comp._scrollViewDidScroll({
            detail: {
              scrollLeft: 0,
              scrollTop: e.scrollTop
            }
          });
        }
        _this.oldPageScroll.apply(_this.root, [e]);
      };
      this.oldReachBottom = this.root.onReachBottom;
      this.root.onReachBottom = function (e) {
        if (_this.comp) {
          _this.comp.triggerEvent('scrolltolower', {});
        }
        _this.oldReachBottom.apply(_this.root, [e]);
      };
      this.oldPullDownRefresh = this.root.onPullDownRefresh;
      this.root.onPullDownRefresh = function (e) {
        if (_this.comp) {
          _this.comp.triggerEvent('scrolltoupper', {});
        }
        _this.oldPullDownRefresh.apply(_this.root, [e]);
      };
    }
  }
  RecycleContext.prototype.checkComp = function () {
    if (!this.comp) {
      this.comp = this.page.selectComponent('#' + this.id);
      if (this.comp) {
        this.comp.setUseInPage(this.useInPage);
        this.comp.context = this;
        this.comp.setPage(this.page);
      } else {
        throw new Error('the recycle-view correspond to this context is detached, pls create another RecycleContext');
      }
    }
  };
  RecycleContext.prototype.appendList = function (list, cb) {
    this.checkComp();
    var id = this.id;
    var dataKey = this.dataKey;
    if (!recycleData[id]) {
      recycleData[id] = {
        key: dataKey,
        id: id,
        list: list,
        sizeMap: {},
        sizeArray: []
      };
    } else {
      recycleData[id].dataKey = dataKey;
      recycleData[id].list = recycleData[id].list.concat(list);
    }
    this._forceRerender(id, cb);
    return this;
  };
  RecycleContext.prototype._forceRerender = function (id, cb) {
    this.isDataReady = true; // 首次调用说明数据已经ready了
    // 动态计算高度并缓存
    var that = this;
    var allrect = null;
    var parentRect = null;
    var count = 0;

    function setPlaceholderImage() {
      if (!allrect || !parentRect) return;
      var svgRects = [];
      for (var i = 0; i < count; i++) {
        svgRects.push({
          left: allrect[i].left - parentRect.left,
          top: allrect[i].top - parentRect.top,
          width: allrect[i].width,
          height: allrect[i].height
        });
      }
      that.comp.setPlaceholderImage(svgRects, {
        width: parentRect.width,
        height: parentRect.height
      });
    }
    function newcb() {
      if (cb) {
        cb();
      }
      // 计算placeholder, 只有在动态计算高度的时候才支持
      if (that.autoCalculateSize && that.placeholderClass) {
        var newQueryClass = [];
        that.placeholderClass.forEach(function (item) {
          newQueryClass.push('.' + that.itemSizeOpt.queryClass + ' .' + item);
        });
        // newQueryClass.push(`.` + that.itemSizeOpt.queryClass)
        count = newQueryClass.length;
        wx.createSelectorQuery().selectAll(newQueryClass.join(',')).boundingClientRect(function (rect) {
          if (rect.length < count) return;
          allrect = rect;
          setPlaceholderImage();
        }).exec();
        wx.createSelectorQuery().select('.' + that.itemSizeOpt.queryClass).boundingClientRect(function (rect) {
          parentRect = rect;
          setPlaceholderImage();
        }).exec();
      }
    }
    if (Object.prototype.toString.call(this.itemSizeOpt) === '[object Object]' && this.itemSizeOpt && !this.itemSizeOpt.width) {
      this._recalculateSizeByProp(recycleData[id].list, function (sizeData) {
        recycleData[id].sizeMap = sizeData.map;
        recycleData[id].sizeArray = sizeData.array;
        // 触发强制渲染
        that.comp.forceUpdate(newcb);
      });
      return;
    }
    var sizeData = this._recalculateSize(recycleData[id].list);
    recycleData[id].sizeMap = sizeData.map;
    // console.log('size is', sizeData.array, sizeData.map, 'totalHeight', sizeData.totalHeight)
    // console.log('sizeArray', sizeData.array)
    recycleData[id].sizeArray = sizeData.array;
    // 触发强制渲染
    this.comp.forceUpdate(cb);
  };
  function getValue(item, key) {
    if (!key) return item;
    if (typeof item[key] !== 'undefined') return item[key];
    var keyItems = key.split('.');
    for (var i = 0; i < keyItems.length; i++) {
      item = item[keyItems[i]];
      if (typeof item === 'undefined' || (typeof item === 'undefined' ? 'undefined' : _typeof(item)) === 'object' && !item) {
        return undefined;
      }
    }
    return item;
  }
  function getValues(item, keys) {
    if (Object.prototype.toString.call(keys) !== '[object Array]') {
      keys = [keys];
    }
    var vals = {};
    for (var i = 0; i < keys.length; i++) {
      vals[keys[i]] = getValue(item, keys[i]);
    }
    return vals;
  }
  function isArray(arr) {
    return Object.prototype.toString.call(arr) === '[object Array]';
  }
  function isSamePureValue(item1, item2) {
    if ((typeof item1 === 'undefined' ? 'undefined' : _typeof(item1)) !== (typeof item2 === 'undefined' ? 'undefined' : _typeof(item2))) return false;
    if (isArray(item1) && isArray(item2)) {
      if (item1.length !== item2.length) return false;
      for (var i = 0; i < item1.length; i++) {
        if (item1[i] !== item2[i]) return false;
      }
      return true;
    }
    return item1 === item2;
  }
  function isSameValue(item1, item2, keys) {
    if (!isArray(keys)) {
      keys = [keys];
    }
    for (var i = 0; i < keys.length; i++) {
      if (!isSamePureValue(getValue(item1, keys[i]), getValue(item2, keys[i]))) return false;
    }
    return true;
  }
  RecycleContext.prototype._recalculateSizeByProp = function (list, cb) {
    var itemSize = this.itemSizeOpt;
    var propValueMap = this.propValueMap || [];
    var calcNewItems = [];
    var needCalcPropIndex = [];
    if (itemSize.cacheKey) {
      propValueMap = wx.getStorageSync(itemSize.cacheKey) || [];
      // eslint-disable-next-line no-console
      // console.log('[recycle-view] get itemSize from cache', propValueMap)
    }
    this.autoCalculateSize = true;
    var item2PropValueMap = [];
    for (var i = 0; i < list.length; i++) {
      var item2PropValueIndex = propValueMap.length;
      if (!propValueMap.length) {
        var val = getValues(list[i], itemSize.props);
        val.__index__ = i;
        propValueMap.push(val);
        calcNewItems.push(list[i]);
        needCalcPropIndex.push(item2PropValueIndex);
        item2PropValueMap.push({
          index: i,
          sizeIndex: item2PropValueIndex
        });
        continue;
      }
      var found = false;
      for (var j = 0; j < propValueMap.length; j++) {
        if (isSameValue(propValueMap[j], list[i], itemSize.props)) {
          item2PropValueIndex = j;
          found = true;
          break;
        }
      }
      if (!found) {
        var _val = getValues(list[i], itemSize.props);
        _val.__index__ = i;
        propValueMap.push(_val);
        calcNewItems.push(list[i]);
        needCalcPropIndex.push(item2PropValueIndex);
      }
      item2PropValueMap.push({
        index: i,
        sizeIndex: item2PropValueIndex
      });
    }
    // this.item2PropValueMap = item2PropValueMap
    this.propValueMap = propValueMap;
    if (propValueMap.length > 10) {
      // eslint-disable-next-line no-console
      console.warn('[recycle-view] get itemSize count exceed maximum of 10, now got', propValueMap);
    }
    // console.log('itemsize', propValueMap, item2PropValueMap)
    // 预先渲染
    var that = this;
    function newItemSize(item, index) {
      var sizeIndex = item2PropValueMap[index];
      if (!sizeIndex) {
        // eslint-disable-next-line no-console
        console.error('[recycle-view] auto calculate size array error, no map size found', item, index, item2PropValueMap);
        throw new Error('[recycle-view] auto calculate size array error, no map size found');
      }
      var size = propValueMap[sizeIndex.sizeIndex];
      if (!size) {
        // eslint-disable-next-line no-console
        console.log('[recycle-view] auto calculate size array error, no size found', item, index, sizeIndex, propValueMap);
        throw new Error('[recycle-view] auto calculate size array error, no size found');
      }
      return {
        width: size.width,
        height: size.height
      };
    }
    function sizeReady(rects) {
      rects.forEach(function (rect, index) {
        var propValueIndex = needCalcPropIndex[index];
        propValueMap[propValueIndex].width = rect.width;
        propValueMap[propValueIndex].height = rect.height;
      });
      that.itemSize = newItemSize;
      var sizeData = that._recalculateSize(list);
      if (itemSize.cacheKey) {
        wx.setStorageSync(itemSize.cacheKey, propValueMap); // 把数据缓存起来
      }
      if (cb) {
        cb(sizeData);
      }
    }
    if (calcNewItems.length) {
      var obj = {};
      obj[itemSize.dataKey] = calcNewItems;
      this.page.setData(obj, function () {
        // wx.createSelectorQuery().select(itemSize.componentClass).boundingClientRect(rects => {
        //   compSize = rects;
        //   if (compSize && allItemSize) {
        //     sizeReady();
        //   }
        // }).exec();
        wx.createSelectorQuery().selectAll('.' + itemSize.queryClass).boundingClientRect(function (rects) {
          sizeReady(rects);
        }).exec();
      });
    } else {
      that.itemSize = newItemSize;
      var sizeData = that._recalculateSize(list);
      if (cb) {
        cb(sizeData);
      }
    }
  };
  // 当before和after这2个slot发生变化的时候调用一下此接口
  RecycleContext.prototype._recalculateSize = function (list) {
    // 遍历所有的数据
    // 应该最多就千量级的, 遍历没有问题
    var sizeMap = {};
    var func = this.itemSize;
    var funcExist = typeof func === 'function';
    var comp = this.comp;
    var compData = comp.data;
    var offsetLeft = 0;
    var offsetTop = 0;
    var line = 0;
    var column = 0;
    var sizeArray = [];
    var listLen = list.length;
    // 把整个页面拆分成200*200的很多个方格, 判断每个数据落在哪个方格上
    for (var i = 0; i < listLen; i++) {
      list[i].__index__ = i;
      var itemSize = {};
      // 获取到每一项的宽和高
      if (funcExist) {
        // 必须保证返回的每一行的高度一样
        itemSize = func && func.call(this, list[i], i);
      } else {
        itemSize = {
          width: func.width,
          height: func.height
        };
      }
      itemSize = Object.assign({}, itemSize);
      sizeArray.push(itemSize);
      // 判断数据落到哪个方格上
      // 超过了宽度, 移动到下一行, 再根据高度判断是否需要移动到下一个方格
      if (offsetLeft + itemSize.width > compData.width) {
        column = 0;
        offsetLeft = itemSize.width;
        // Fixed issue #22
        if (sizeArray.length >= 2) {
          offsetTop += sizeArray[sizeArray.length - 2].height || 0; // 加上最后一个数据的高度
        } else {
          offsetTop += itemSize.height;
        }
        // offsetTop += sizeArray[sizeArray.length - 2].height // 加上最后一个数据的高度
        // 根据高度判断是否需要移动到下一个方格
        if (offsetTop >= RECT_SIZE * (line + 1)) {
          // fix: 当区块比较大时，会缺失块区域信息
          var lastIdx = i - 1;
          var lastLine = line;

          line += parseInt((offsetTop - RECT_SIZE * line) / RECT_SIZE, 10);

          for (var idx = lastLine; idx < line; idx++) {
            var _key = idx + '.' + column;
            if (!sizeMap[_key]) {
              sizeMap[_key] = [];
            }
            sizeMap[_key].push(lastIdx);
          }
        }

        // 新起一行的元素, beforeHeight是前一个元素的beforeHeight和height相加
        if (i === 0) {
          itemSize.beforeHeight = 0;
        } else {
          var prevItemSize = sizeArray[sizeArray.length - 2];
          itemSize.beforeHeight = prevItemSize.beforeHeight + prevItemSize.height;
        }
      } else {
        if (offsetLeft >= RECT_SIZE * (column + 1)) {
          column++;
        }
        offsetLeft += itemSize.width;
        if (i === 0) {
          itemSize.beforeHeight = 0;
        } else {
          // 同一行的元素, beforeHeight和前面一个元素的beforeHeight一样
          itemSize.beforeHeight = sizeArray[sizeArray.length - 2].beforeHeight;
        }
      }
      var key = line + '.' + column;
      if (!sizeMap[key]) {
        sizeMap[key] = [];
      }
      sizeMap[key].push(i);

      // fix: 当区块比较大时，会缺失块区域信息
      if (listLen - 1 === i && itemSize.height > RECT_SIZE) {
        var _lastIdx = line;
        offsetTop += itemSize.height;
        line += parseInt((offsetTop - RECT_SIZE * line) / RECT_SIZE, 10);
        for (var _idx = _lastIdx; _idx <= line; _idx++) {
          var _key2 = _idx + '.' + column;
          if (!sizeMap[_key2]) {
            sizeMap[_key2] = [];
          }
          sizeMap[_key2].push(i);
        }
      }
    }
    // console.log('sizeMap', sizeMap)
    var obj = {
      array: sizeArray,
      map: sizeMap,
      totalHeight: sizeArray.length ? sizeArray[sizeArray.length - 1].beforeHeight + sizeArray[sizeArray.length - 1].height : 0
    };
    comp.setItemSize(obj);
    return obj;
  };
  RecycleContext.prototype.deleteList = function (beginIndex, count, cb) {
    this.checkComp();
    var id = this.id;
    if (!recycleData[id]) {
      return this;
    }
    recycleData[id].list.splice(beginIndex, count);
    this._forceRerender(id, cb);
    return this;
  };
  RecycleContext.prototype.updateList = function (beginIndex, list, cb) {
    this.checkComp();
    var id = this.id;
    if (!recycleData[id]) {
      return this;
    }
    var len = recycleData[id].list.length;
    for (var i = 0; i < list.length && beginIndex < len; i++) {
      recycleData[id].list[beginIndex++] = list[i];
    }
    this._forceRerender(id, cb);
    return this;
  };
  RecycleContext.prototype.update = RecycleContext.prototype.updateList;
  RecycleContext.prototype.splice = function (begin, deleteCount, appendList, cb) {
    this.checkComp();
    var id = this.id;
    var dataKey = this.dataKey;
    // begin是数组
    if ((typeof begin === 'undefined' ? 'undefined' : _typeof(begin)) === 'object' && begin.length) {
      cb = deleteCount;
      appendList = begin;
    }
    if (typeof appendList === 'function') {
      cb = appendList;
      appendList = [];
    }
    if (!recycleData[id]) {
      recycleData[id] = {
        key: dataKey,
        id: id,
        list: appendList || [],
        sizeMap: {},
        sizeArray: []
      };
    } else {
      recycleData[id].dataKey = dataKey;
      var list = recycleData[id].list;
      if (appendList && appendList.length) {
        list.splice.apply(list, [begin, deleteCount].concat(appendList));
      } else {
        list.splice(begin, deleteCount);
      }
    }
    this._forceRerender(id, cb);
    return this;
  };

  RecycleContext.prototype.append = RecycleContext.prototype.appendList;

  RecycleContext.prototype.destroy = function () {
    if (this.useInPage) {
      this.page.onPullDownRefresh = this.oldPullDownRefresh;
      this.page.onReachBottom = this.oldReachBottom;
      this.page.onPageScroll = this.oldPageScroll;
      this.oldPageScroll = this.oldReachBottom = this.oldPullDownRefresh = null;
    }
    this.page = null;
    this.comp = null;
    if (recycleData[this.id]) {
      delete recycleData[this.id];
    }
    return this;
  };
  // 重新更新下页面的数据
  RecycleContext.prototype.forceUpdate = function (cb, reinitSlot) {
    var _this2 = this;

    this.checkComp();
    if (reinitSlot) {
      this.comp.reRender(function () {
        _this2._forceRerender(_this2.id, cb);
      });
    } else {
      this._forceRerender(this.id, cb);
    }
    return this;
  };
  RecycleContext.prototype.getBoundingClientRect = function (index) {
    this.checkComp();
    if (!recycleData[this.id]) {
      return null;
    }
    var sizeArray = recycleData[this.id].sizeArray;
    if (!sizeArray || !sizeArray.length) {
      return null;
    }
    if (typeof index === 'undefined') {
      var list = [];
      for (var i = 0; i < sizeArray.length; i++) {
        list.push({
          left: 0,
          top: sizeArray[i].beforeHeight,
          width: sizeArray[i].width,
          height: sizeArray[i].height
        });
      }
      return list;
    }
    index = parseInt(index, 10);
    if (index >= sizeArray.length || index < 0) return null;
    return {
      left: 0,
      top: sizeArray[index].beforeHeight,
      width: sizeArray[index].width,
      height: sizeArray[index].height
    };
  };
  RecycleContext.prototype.getScrollTop = function () {
    this.checkComp();
    return this.comp.currentScrollTop || 0;
  };
  // 将px转化为rpx
  RecycleContext.prototype.transformRpx = RecycleContext.transformRpx = function (str, addPxSuffix) {
    if (typeof str === 'number') str += 'rpx';
    return parseFloat(transformRpx.transformRpx(str, addPxSuffix));
  };
  RecycleContext.prototype.getViewportItems = function (inViewportPx) {
    this.checkComp();
    var indexes = this.comp.getIndexesInViewport(inViewportPx);
    if (indexes.length <= 0) return [];
    var viewportItems = [];
    var list = recycleData[this.id].list;
    for (var i = 0; i < indexes.length; i++) {
      viewportItems.push(list[indexes[i]]);
    }
    return viewportItems;
  };
  RecycleContext.prototype.getTotalHeight = function () {
    this.checkComp();
    return this.comp.getTotalHeight();
  };
  // 返回完整的列表数据
  RecycleContext.prototype.getList = function () {
    if (!recycleData[this.id]) {
      return [];
    }
    return recycleData[this.id].list;
  };
  module.exports = RecycleContext;

  /***/
},
/* 4 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  /* eslint complexity: ["error", {"max": 50}] */

  var recycleData = __webpack_require__(1);

  module.exports = function (e, cb) {
    var detail = e.detail;
    // console.log('data change transfer use time', Date.now() - e.detail.timeStamp)
    var newList = [];
    var item = recycleData[detail.id];
    // 边界值判断, 避免造成异常, 假设先调用了createRecycleContext, 然后再延迟2s调用append插入数据的情况
    if (!item || !item.list) return;
    var dataList = item.list;
    var pos = detail.data;
    var beginIndex = pos.beginIndex;
    var endIndex = pos.endIndex;
    item.pos = pos;
    // 加ignoreBeginIndex和ignoreEndIndex
    if (typeof beginIndex === 'undefined' || beginIndex === -1 || typeof endIndex === 'undefined' || endIndex === -1) {
      newList = [];
    } else {
      var i = -1;
      for (i = beginIndex; i < dataList.length && i <= endIndex; i++) {
        if (i >= pos.ignoreBeginIndex && i <= pos.ignoreEndIndex) continue;
        newList.push(dataList[i]);
      }
    }
    var obj = {
      // batchSetRecycleData: !this.data.batchSetRecycleData
    };
    obj[item.key] = newList;
    var comp = this.selectComponent('#' + detail.id);
    obj[comp.data.batchKey] = !this.data.batchSetRecycleData;
    comp._setInnerBeforeAndAfterHeight({
      beforeHeight: pos.minTop,
      afterHeight: pos.afterHeight
    });
    this.setData(obj, function () {
      if (typeof cb === 'function') {
        cb();
      }
    });
    // Fix #1
    // 去掉了batchSetDataKey，支持一个页面内显示2个recycle-view
    // const groupSetData = () => {
    //   this.setData(obj)
    //   comp._recycleInnerBatchDataChanged(() => {
    //     if (typeof cb === 'function') {
    //       cb()
    //     }
    //   })
    // }
    // if (typeof this.groupSetData === 'function') {
    //   this.groupSetData(groupSetData)
    // } else {
    //   groupSetData()
    // }
  };

  /***/
}]
/******/);
});
define("miniprogram_npm/miniprogram-recycle-view/recycle-item.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
      /******/
    }
    /******/
  };
  /******/
  /******/ // define __esModule on exports
  /******/__webpack_require__.r = function (exports) {
    /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
      /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
      /******/
    }
    /******/Object.defineProperty(exports, '__esModule', { value: true });
    /******/
  };
  /******/
  /******/ // create a fake namespace object
  /******/ // mode & 1: value is a module id, require it
  /******/ // mode & 2: merge all properties of value into the ns
  /******/ // mode & 4: return value when already ns object
  /******/ // mode & 8|1: behave like require
  /******/__webpack_require__.t = function (value, mode) {
    /******/if (mode & 1) value = __webpack_require__(value);
    /******/if (mode & 8) return value;
    /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
    /******/var ns = Object.create(null);
    /******/__webpack_require__.r(ns);
    /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
    /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
      __webpack_require__.d(ns, key, function (key) {
        return value[key];
      }.bind(null, key));
    } /******/return ns;
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 5);
  /******/
}(
/************************************************************************/
/******/{

  /***/5:
  /***/function _(module, exports, __webpack_require__) {

    "use strict";

    // components/recycle-item/recycle-item.js

    Component({
      relations: {
        './recycle-view': {
          type: 'parent', // 关联的目标节点应为子节点
          linked: function linked() {}
        }
      },
      /**
       * 组件的属性列表
       */
      properties: {},

      /**
       * 组件的初始数据
       */
      data: {
        // height: 100
      },

      /**
       * 组件的方法列表
       */
      methods: {
        heightChange: function heightChange() {}
      }
    });

    /***/
  }

  /******/ });
});
define("miniprogram_npm/miniprogram-recycle-view/recycle-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports =
/******/function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
      /******/
    }
    /******/
  };
  /******/
  /******/ // define __esModule on exports
  /******/__webpack_require__.r = function (exports) {
    /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
      /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
      /******/
    }
    /******/Object.defineProperty(exports, '__esModule', { value: true });
    /******/
  };
  /******/
  /******/ // create a fake namespace object
  /******/ // mode & 1: value is a module id, require it
  /******/ // mode & 2: merge all properties of value into the ns
  /******/ // mode & 4: return value when already ns object
  /******/ // mode & 8|1: behave like require
  /******/__webpack_require__.t = function (value, mode) {
    /******/if (mode & 1) value = __webpack_require__(value);
    /******/if (mode & 8) return value;
    /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
    /******/var ns = Object.create(null);
    /******/__webpack_require__.r(ns);
    /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
    /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
      __webpack_require__.d(ns, key, function (key) {
        return value[key];
      }.bind(null, key));
    } /******/return ns;
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 6);
  /******/
}(
/************************************************************************/
/******/{

  /***/0:
  /***/function _(module, exports, __webpack_require__) {

    "use strict";

    var isIPhone = false;
    var deviceWidth = void 0;
    var deviceDPR = void 0;
    var BASE_DEVICE_WIDTH = 750;
    var checkDeviceWidth = function checkDeviceWidth() {
      var info = wx.getSystemInfoSync();
      // console.log('info', info)
      isIPhone = info.platform === 'ios';
      var newDeviceWidth = info.screenWidth || 375;
      var newDeviceDPR = info.pixelRatio || 2;

      if (!isIPhone) {
        // HACK switch width and height when landscape
        // const newDeviceHeight = info.screenHeight || 375
        // 暂时不处理转屏的情况
      }

      if (newDeviceWidth !== deviceWidth || newDeviceDPR !== deviceDPR) {
        deviceWidth = newDeviceWidth;
        deviceDPR = newDeviceDPR;
        // console.info('Updated device width: ' + newDeviceWidth + 'px DPR ' + newDeviceDPR)
      }
    };
    checkDeviceWidth();

    var eps = 1e-4;
    var transformByDPR = function transformByDPR(number) {
      if (number === 0) {
        return 0;
      }
      number = number / BASE_DEVICE_WIDTH * deviceWidth;
      number = Math.floor(number + eps);
      if (number === 0) {
        if (deviceDPR === 1 || !isIPhone) {
          return 1;
        }
        return 0.5;
      }
      return number;
    };

    var rpxRE = /([+-]?\d+(?:\.\d+)?)rpx/gi;
    // const inlineRpxRE = /(?::|\s|\(|\/)([+-]?\d+(?:\.\d+)?)rpx/g

    var transformRpx = function transformRpx(style, inline) {
      if (typeof style !== 'string') {
        return style;
      }
      var re = rpxRE;
      return style.replace(re, function (match, num) {
        return transformByDPR(Number(num)) + (inline ? 'px' : '');
      });
    };

    module.exports = {
      transformRpx: transformRpx
    };

    /***/
  },

  /***/6:
  /***/function _(module, exports, __webpack_require__) {

    "use strict";

    /* eslint complexity: ["error", {"max": 50}] */
    /* eslint-disable indent */

    var DEFAULT_SHOW_SCREENS = 4;
    var RECT_SIZE = 200;
    var systemInfo = wx.getSystemInfoSync();
    var DEBUG = false;
    var transformRpx = __webpack_require__(0).transformRpx;

    Component({
      options: {
        multipleSlots: true // 在组件定义时的选项中启用多slot支持
      },
      relations: {
        '../recycle-item/recycle-item': {
          type: 'child', // 关联的目标节点应为子节点
          linked: function linked(target) {
            // 检查第一个的尺寸就好了吧
            if (!this._hasCheckSize) {
              this._hasCheckSize = true;
              var size = this.boundingClientRect(this._pos.beginIndex);
              if (!size) {
                return;
              }
              setTimeout(function () {
                try {
                  target.createSelectorQuery().select('.wx-recycle-item').boundingClientRect(function (rect) {
                    if (rect && (rect.width !== size.width || rect.height !== size.height)) {
                      // eslint-disable-next-line no-console
                      console.warn('[recycle-view] the size in <recycle-item> is not the same with param ' + ('itemSize, expect {width: ' + rect.width + ', height: ' + rect.height + '} but got ') + ('{width: ' + size.width + ', height: ' + size.height + '}'));
                    }
                  }).exec();
                } catch (e) {
                  // do nothing
                }
              }, 10);
            }
          }
        }
      },
      /**
       * 组件的属性列表
       */
      properties: {
        debug: {
          type: Boolean,
          value: false
        },
        scrollY: {
          type: Boolean,
          value: true
        },
        batch: {
          type: Boolean,
          value: false,
          public: true,
          observer: '_recycleInnerBatchDataChanged'
        },
        batchKey: {
          type: String,
          value: 'batchSetRecycleData',
          public: true
        },
        scrollTop: {
          type: Number,
          value: 0,
          public: true,
          observer: '_scrollTopChanged',
          observeAssignments: true
        },
        height: {
          type: Number,
          value: systemInfo.windowHeight,
          public: true,
          observer: '_heightChanged'
        },
        width: {
          type: Number,
          value: systemInfo.windowWidth,
          public: true,
          observer: '_widthChanged'
        },
        // 距顶部/左边多远时，触发bindscrolltoupper
        upperThreshold: {
          type: Number,
          value: 50,
          public: true
        },
        // 距底部/右边多远时，触发bindscrolltolower
        lowerThreshold: {
          type: Number,
          value: 50,
          public: true
        },
        scrollToIndex: {
          type: Number,
          public: true,
          value: 0,
          observer: '_scrollToIndexChanged',
          observeAssignments: true
        },
        scrollWithAnimation: {
          type: Boolean,
          public: true,
          value: false
        },
        enableBackToTop: {
          type: Boolean,
          public: true,
          value: false
        },
        // 是否节流，默认是
        throttle: {
          type: Boolean,
          public: true,
          value: true
        },
        placeholderImage: {
          type: String,
          public: true,
          value: ''
        },
        screen: { // 默认渲染多少屏的数据
          type: Number,
          public: true,
          value: DEFAULT_SHOW_SCREENS
        }
      },

      /**
       * 组件的初始数据
       */
      data: {
        innerBeforeHeight: 0,
        innerAfterHeight: 0,
        innerScrollTop: 0,
        innerScrollIntoView: '',
        placeholderImageStr: '',
        totalHeight: 0,
        useInPage: false
      },
      attached: function attached() {
        if (this.data.placeholderImage) {
          this.setData({
            placeholderImageStr: transformRpx(this.data.placeholderImage, true)
          });
        }
        this.setItemSize({
          array: [],
          map: {},
          totalHeight: 0
        });
      },
      ready: function ready() {
        var _this = this;

        this._initPosition(function () {
          _this._isReady = true; // DOM结构ready了
          // 有一个更新的timer在了
          if (_this._updateTimerId) return;

          _this._scrollViewDidScroll({
            detail: {
              scrollLeft: _this._pos.left,
              scrollTop: _this._pos.top,
              ignoreScroll: true
            }
          }, true);
        });
      },
      detached: function detached() {
        this.page = null;
        // 销毁对应的RecycleContext
        if (this.context) {
          this.context.destroy();
          this.context = null;
        }
      },

      /**
       * 组件的方法列表
       */
      methods: {
        _log: function _log() {
          var _console;

          if (!DEBUG && !this.data.debug) return;
          var h = new Date();
          var str = h.getHours() + ':' + h.getMinutes() + ':' + h.getSeconds() + '.' + h.getMilliseconds();

          for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          Array.prototype.splice.call(args, 0, 0, str);
          // eslint-disable-next-line no-console
          (_console = console).log.apply(_console, args);
        },
        _scrollToUpper: function _scrollToUpper(e) {
          this.triggerEvent('scrolltoupper', e.detail);
        },
        _scrollToLower: function _scrollToLower(e) {
          this.triggerEvent('scrolltolower', e.detail);
        },
        _beginToScroll: function _beginToScroll() {
          if (!this._lastScrollTop) {
            this._lastScrollTop = this._pos && (this._pos.top || 0);
          }
        },
        _clearList: function _clearList(cb) {
          this.currentScrollTop = 0;
          this._lastScrollTop = 0;
          var pos = this._pos;
          pos.beginIndex = this._pos.endIndex = -1;
          pos.afterHeight = pos.minTop = pos.maxTop = 0;
          this.page._recycleViewportChange({
            detail: {
              data: pos,
              id: this.id
            }
          }, cb);
        },

        // 判断RecycleContext是否Ready
        _isValid: function _isValid() {
          return this.page && this.context && this.context.isDataReady;
        },

        // eslint-disable-next-line no-complexity
        _scrollViewDidScroll: function _scrollViewDidScroll(e, force) {
          // 如果RecycleContext还没有初始化, 不做任何事情
          if (!this._isValid()) {
            return;
          }
          // 监测白屏时间
          if (!e.detail.ignoreScroll) {
            this.triggerEvent('scroll', e.detail);
          }
          this.currentScrollTop = e.detail.scrollTop;
          // 高度为0的情况, 不做任何渲染逻辑
          if (!this._pos.height || !this.sizeArray.length) {
            // 没有任何数据的情况下, 直接清理所有的状态
            this._clearList(e.detail.cb);
            return;
          }

          // 在scrollWithAnimation动画最后会触发一次scroll事件, 这次scroll事件必须要被忽略
          if (this._isScrollingWithAnimation) {
            this._isScrollingWithAnimation = false;
            return;
          }
          var pos = this._pos;
          var that = this;
          var scrollLeft = e.detail.scrollLeft;
          var scrollTop = e.detail.scrollTop;
          var scrollDistance = Math.abs(scrollTop - this._lastScrollTop);
          if (!force && Math.abs(scrollTop - pos.top) < pos.height * 1.5) {
            this._log('【not exceed height');
            return;
          }
          this._lastScrollTop = scrollTop;
          var SHOW_SCREENS = this.data.screen; // 固定4屏幕
          this._log('SHOW_SCREENS', SHOW_SCREENS, scrollTop);
          this._calcViewportIndexes(scrollLeft, scrollTop, function (beginIndex, endIndex, minTop, afterHeight, maxTop) {
            that._log('scrollDistance', scrollDistance, 'indexes', beginIndex, endIndex);
            // 渲染的数据不变
            if (!force && pos.beginIndex === beginIndex && pos.endIndex === endIndex && pos.minTop === minTop && pos.afterHeight === afterHeight) {
              that._log('------------is the same beginIndex and endIndex');
              return;
            }
            // 如果这次渲染的范围比上一次的范围小，则忽略
            that._log('【check】before setData, old pos is', pos.minTop, pos.maxTop, minTop, maxTop);
            that._throttle = false;
            pos.left = scrollLeft;
            pos.top = scrollTop;
            pos.beginIndex = beginIndex;
            pos.endIndex = endIndex;
            // console.log('render indexes', endIndex - beginIndex + 1, endIndex, beginIndex)
            pos.minTop = minTop;
            pos.maxTop = maxTop;
            pos.afterHeight = afterHeight;
            pos.ignoreBeginIndex = pos.ignoreEndIndex = -1;
            that.page._recycleViewportChange({
              detail: {
                data: that._pos,
                id: that.id
              }
            }, function () {
              if (e.detail.cb) {
                e.detail.cb();
              }
            });
          });
        },

        // 计算在视窗内渲染的数据
        _calcViewportIndexes: function _calcViewportIndexes(left, top, cb) {
          var that = this;
          // const st = +new Date
          this._getBeforeSlotHeight(function () {
            var _that$__calcViewportI = that.__calcViewportIndexes(left, top),
                beginIndex = _that$__calcViewportI.beginIndex,
                endIndex = _that$__calcViewportI.endIndex,
                minTop = _that$__calcViewportI.minTop,
                afterHeight = _that$__calcViewportI.afterHeight,
                maxTop = _that$__calcViewportI.maxTop;

            if (cb) {
              cb(beginIndex, endIndex, minTop, afterHeight, maxTop);
            }
          });
        },
        _getBeforeSlotHeight: function _getBeforeSlotHeight(cb) {
          if (typeof this.data.beforeSlotHeight !== 'undefined') {
            if (cb) {
              cb(this.data.beforeSlotHeight);
            }
          } else {
            this.reRender(cb);
          }
        },
        _getAfterSlotHeight: function _getAfterSlotHeight(cb) {
          if (typeof this.data.afterSlotHeight !== 'undefined') {
            if (cb) {
              cb(this.data.afterSlotHeight);
            }
            // cb && cb(this.data.afterSlotHeight)
          } else {
            this.reRender(cb);
          }
        },
        _getIndexes: function _getIndexes(minTop, maxTop) {
          if (minTop === maxTop && maxTop === 0) {
            return {
              beginIndex: -1,
              endIndex: -1
            };
          }
          var startLine = Math.floor(minTop / RECT_SIZE);
          var endLine = Math.ceil(maxTop / RECT_SIZE);
          var rectEachLine = Math.floor(this.data.width / RECT_SIZE);
          var beginIndex = void 0;
          var endIndex = void 0;
          var sizeMap = this.sizeMap;
          for (var i = startLine; i <= endLine; i++) {
            for (var col = 0; col < rectEachLine; col++) {
              var key = i + '.' + col;
              // 找到sizeMap里面的最小值和最大值即可
              if (!sizeMap[key]) continue;
              for (var j = 0; j < sizeMap[key].length; j++) {
                if (typeof beginIndex === 'undefined') {
                  beginIndex = endIndex = sizeMap[key][j];
                  continue;
                }
                if (beginIndex > sizeMap[key][j]) {
                  beginIndex = sizeMap[key][j];
                } else if (endIndex < sizeMap[key][j]) {
                  endIndex = sizeMap[key][j];
                }
              }
            }
          }
          return {
            beginIndex: beginIndex,
            endIndex: endIndex
          };
        },
        _isIndexValid: function _isIndexValid(beginIndex, endIndex) {
          if (typeof beginIndex === 'undefined' || beginIndex === -1 || typeof endIndex === 'undefined' || endIndex === -1 || endIndex >= this.sizeArray.length) {
            return false;
          }
          return true;
        },
        __calcViewportIndexes: function __calcViewportIndexes(left, top) {
          if (!this.sizeArray.length) return {};
          var pos = this._pos;
          if (typeof left === 'undefined') {
            left = pos.left;
          }
          if (typeof top === 'undefined') {
            top = pos.top;
          }
          // top = Math.max(top, this.data.beforeSlotHeight)
          var beforeSlotHeight = this.data.beforeSlotHeight || 0;
          // 和direction无关了
          var SHOW_SCREENS = this.data.screen;
          var minTop = top - pos.height * SHOW_SCREENS - beforeSlotHeight;
          var maxTop = top + pos.height * SHOW_SCREENS - beforeSlotHeight;
          // maxTop或者是minTop超出了范围
          if (maxTop > this.totalHeight) {
            minTop -= maxTop - this.totalHeight;
            maxTop = this.totalHeight;
          }
          if (minTop < beforeSlotHeight) {
            maxTop += Math.min(beforeSlotHeight - minTop, this.totalHeight);
            minTop = 0;
          }
          // 计算落在minTop和maxTop之间的方格有哪些
          var indexObj = this._getIndexes(minTop, maxTop);
          var beginIndex = indexObj.beginIndex;
          var endIndex = indexObj.endIndex;
          if (endIndex >= this.sizeArray.length) {
            endIndex = this.sizeArray.length - 1;
          }
          // 校验一下beginIndex和endIndex的有效性,
          if (!this._isIndexValid(beginIndex, endIndex)) {
            return {
              beginIndex: -1,
              endIndex: -1,
              minTop: 0,
              afterHeight: 0,
              maxTop: 0
            };
          }
          // 计算白屏的默认占位的区域
          var maxTopFull = this.sizeArray[endIndex].beforeHeight + this.sizeArray[endIndex].height;
          var minTopFull = this.sizeArray[beginIndex].beforeHeight;

          // console.log('render indexes', beginIndex, endIndex)
          var afterHeight = this.totalHeight - maxTopFull;
          return {
            beginIndex: beginIndex,
            endIndex: endIndex,
            minTop: minTopFull, // 取整, beforeHeight的距离
            afterHeight: afterHeight,
            maxTop: maxTop
          };
        },
        setItemSize: function setItemSize(size) {
          this.sizeArray = size.array;
          this.sizeMap = size.map;
          if (size.totalHeight !== this.totalHeight) {
            // console.log('---totalHeight is', size.totalHeight);
            this.setData({
              totalHeight: size.totalHeight,
              useInPage: this.useInPage || false
            });
          }
          this.totalHeight = size.totalHeight;
        },
        setList: function setList(key, newList) {
          this._currentSetDataKey = key;
          this._currentSetDataList = newList;
        },
        setPage: function setPage(page) {
          this.page = page;
        },
        forceUpdate: function forceUpdate(cb, reInit) {
          var _this2 = this;

          if (!this._isReady) {
            if (this._updateTimerId) {
              // 合并多次的forceUpdate
              clearTimeout(this._updateTimerId);
            }
            this._updateTimerId = setTimeout(function () {
              _this2.forceUpdate(cb, reInit);
            }, 10);
            return;
          }
          this._updateTimerId = null;
          var that = this;
          if (reInit) {
            this.reRender(function () {
              that._scrollViewDidScroll({
                detail: {
                  scrollLeft: that._pos.left,
                  scrollTop: that.currentScrollTop || that.data.scrollTop || 0,
                  ignoreScroll: true,
                  cb: cb
                }
              }, true);
            });
          } else {
            this._scrollViewDidScroll({
              detail: {
                scrollLeft: that._pos.left,
                scrollTop: that.currentScrollTop || that.data.scrollTop || 0,
                ignoreScroll: true,
                cb: cb
              }
            }, true);
          }
        },
        _initPosition: function _initPosition(cb) {
          var that = this;
          that._pos = {
            left: that.data.scrollLeft || 0,
            top: that.data.scrollTop || 0,
            width: this.data.width,
            height: Math.max(500, this.data.height), // 一个屏幕的高度
            direction: 0
          };
          this.reRender(cb);
        },
        _widthChanged: function _widthChanged(newVal) {
          if (!this._isReady) return newVal;
          this._pos.width = newVal;
          this.forceUpdate();
          return newVal;
        },
        _heightChanged: function _heightChanged(newVal) {
          if (!this._isReady) return newVal;
          this._pos.height = Math.max(500, newVal);
          this.forceUpdate();
          return newVal;
        },
        reRender: function reRender(cb) {
          var _this3 = this;

          var beforeSlotHeight = void 0;
          var afterSlotHeight = void 0;
          var that = this;
          // const reRenderStart = Date.now()
          function newCb() {
            if (that._lastBeforeSlotHeight !== beforeSlotHeight || that._lastAfterSlotHeight !== afterSlotHeight) {
              that.setData({
                hasBeforeSlotHeight: true,
                hasAfterSlotHeight: true,
                beforeSlotHeight: beforeSlotHeight,
                afterSlotHeight: afterSlotHeight
              });
            }
            that._lastBeforeSlotHeight = beforeSlotHeight;
            that._lastAfterSlotHeight = afterSlotHeight;
            // console.log('_getBeforeSlotHeight use time', Date.now() - reRenderStart)
            if (cb) {
              cb();
            }
          }
          // 重新渲染事件发生
          var beforeReady = false;
          var afterReady = false;
          // fix：#16 确保获取slot节点实际高度
          this.setData({
            hasBeforeSlotHeight: false,
            hasAfterSlotHeight: false
          }, function () {
            _this3.createSelectorQuery().select('.slot-before').boundingClientRect(function (rect) {
              beforeSlotHeight = rect.height;
              beforeReady = true;
              if (afterReady) {
                if (newCb) {
                  newCb();
                }
              }
            }).exec();
            _this3.createSelectorQuery().select('.slot-after').boundingClientRect(function (rect) {
              afterSlotHeight = rect.height;
              afterReady = true;
              if (beforeReady) {
                if (newCb) {
                  newCb();
                }
              }
            }).exec();
          });
        },
        _setInnerBeforeAndAfterHeight: function _setInnerBeforeAndAfterHeight(obj) {
          if (typeof obj.beforeHeight !== 'undefined') {
            this._tmpBeforeHeight = obj.beforeHeight;
          }
          if (obj.afterHeight) {
            this._tmpAfterHeight = obj.afterHeight;
          }
        },
        _recycleInnerBatchDataChanged: function _recycleInnerBatchDataChanged(cb) {
          var _this4 = this;

          if (typeof this._tmpBeforeHeight !== 'undefined') {
            var setObj = {
              innerBeforeHeight: this._tmpBeforeHeight || 0,
              innerAfterHeight: this._tmpAfterHeight || 0
            };
            if (typeof this._tmpInnerScrollTop !== 'undefined') {
              setObj.innerScrollTop = this._tmpInnerScrollTop;
            }
            var pageObj = {};
            var hasPageData = false;
            if (typeof this._currentSetDataKey !== 'undefined') {
              pageObj[this._currentSetDataKey] = this._currentSetDataList;
              hasPageData = true;
            }
            var saveScrollWithAnimation = this.data.scrollWithAnimation;
            var groupSetData = function groupSetData() {
              // 如果有分页数据的话
              if (hasPageData) {
                _this4.page.setData(pageObj);
              }
              _this4.setData(setObj, function () {
                _this4.setData({
                  scrollWithAnimation: saveScrollWithAnimation
                });
                if (typeof cb === 'function') {
                  cb();
                }
              });
            };
            groupSetData();
            delete this._currentSetDataKey;
            delete this._currentSetDataList;
            this._tmpBeforeHeight = undefined;
            this._tmpAfterHeight = undefined;
            this._tmpInnerScrollTop = undefined;
          }
        },
        _renderByScrollTop: function _renderByScrollTop(scrollTop) {
          // 先setData把目标位置的数据补齐
          this._scrollViewDidScroll({
            detail: {
              scrollLeft: this._pos.scrollLeft,
              scrollTop: scrollTop,
              ignoreScroll: true
            }
          }, true);
          if (this.data.scrollWithAnimation) {
            this._isScrollingWithAnimation = true;
          }
          this.setData({
            innerScrollTop: scrollTop
          });
        },
        _scrollTopChanged: function _scrollTopChanged(newVal, oldVal) {
          var _this5 = this;

          // if (newVal === oldVal && newVal === 0) return
          if (!this._isInitScrollTop && newVal === 0) {
            this._isInitScrollTop = true;
            return newVal;
          }
          this.currentScrollTop = newVal;
          if (!this._isReady) {
            if (this._scrollTopTimerId) {
              clearTimeout(this._scrollTopTimerId);
            }
            this._scrollTopTimerId = setTimeout(function () {
              _this5._scrollTopChanged(newVal, oldVal);
            }, 10);
            return newVal;
          }
          this._isInitScrollTop = true;
          this._scrollTopTimerId = null;
          // this._lastScrollTop = oldVal
          if (typeof this._lastScrollTop === 'undefined') {
            this._lastScrollTop = this.data.scrollTop;
          }
          // 滑动距离小于一个屏幕的高度, 直接setData
          if (Math.abs(newVal - this._lastScrollTop) < this._pos.height) {
            this.setData({
              innerScrollTop: newVal
            });
            return newVal;
          }
          if (!this._isScrollTopChanged) {
            // 首次的值需要延后一点执行才能生效
            setTimeout(function () {
              _this5._isScrollTopChanged = true;
              _this5._renderByScrollTop(newVal);
            }, 10);
          } else {
            this._renderByScrollTop(newVal);
          }
          return newVal;
        },
        _scrollToIndexChanged: function _scrollToIndexChanged(newVal, oldVal) {
          var _this6 = this;

          // if (newVal === oldVal && newVal === 0) return
          // 首次滚动到0的不执行
          if (!this._isInitScrollToIndex && newVal === 0) {
            this._isInitScrollToIndex = true;
            return newVal;
          }
          if (!this._isReady) {
            if (this._scrollToIndexTimerId) {
              clearTimeout(this._scrollToIndexTimerId);
            }
            this._scrollToIndexTimerId = setTimeout(function () {
              _this6._scrollToIndexChanged(newVal, oldVal);
            }, 10);
            return newVal;
          }
          this._isInitScrollToIndex = true;
          this._scrollToIndexTimerId = null;
          if (typeof this._lastScrollTop === 'undefined') {
            this._lastScrollTop = this.data.scrollTop;
          }
          var rect = this.boundingClientRect(newVal);
          if (!rect) return newVal;
          // console.log('rect top', rect, this.data.beforeSlotHeight)
          var calScrollTop = rect.top + (this.data.beforeSlotHeight || 0);
          this.currentScrollTop = calScrollTop;
          if (Math.abs(calScrollTop - this._lastScrollTop) < this._pos.height) {
            this.setData({
              innerScrollTop: calScrollTop
            });
            return newVal;
          }
          if (!this._isScrollToIndexChanged) {
            setTimeout(function () {
              _this6._isScrollToIndexChanged = true;
              _this6._renderByScrollTop(calScrollTop);
            }, 10);
          } else {
            this._renderByScrollTop(calScrollTop);
          }
          return newVal;
        },

        // 提供给开发者使用的接口
        boundingClientRect: function boundingClientRect(idx) {
          if (idx < 0 || idx >= this.sizeArray.length) {
            return null;
          }
          return {
            left: 0,
            top: this.sizeArray[idx].beforeHeight,
            width: this.sizeArray[idx].width,
            height: this.sizeArray[idx].height
          };
        },

        // 获取当前出现在屏幕内数据项， 返回数据项组成的数组
        // 参数inViewportPx表示当数据项至少有多少像素出现在屏幕内才算是出现在屏幕内，默认是1
        getIndexesInViewport: function getIndexesInViewport(inViewportPx) {
          if (!inViewportPx) {
            inViewportPx = 1;
          }
          var scrollTop = this.currentScrollTop;
          var minTop = scrollTop + inViewportPx;
          if (minTop < 0) minTop = 0;
          var maxTop = scrollTop + this.data.height - inViewportPx;
          if (maxTop > this.totalHeight) maxTop = this.totalHeight;
          var indexes = [];
          for (var i = 0; i < this.sizeArray.length; i++) {
            if (this.sizeArray[i].beforeHeight + this.sizeArray[i].height >= minTop && this.sizeArray[i].beforeHeight <= maxTop) {
              indexes.push(i);
            }
            if (this.sizeArray[i].beforeHeight > maxTop) break;
          }
          return indexes;
        },
        getTotalHeight: function getTotalHeight() {
          return this.totalHeight;
        },
        setUseInPage: function setUseInPage(useInPage) {
          this.useInPage = useInPage;
        },
        setPlaceholderImage: function setPlaceholderImage(svgs, size) {
          var fill = 'style=\'fill:rgb(204,204,204);\'';
          var placeholderImages = ['data:image/svg+xml,%3Csvg height=\'' + size.height + '\' width=\'' + size.width + '\' xmlns=\'http://www.w3.org/2000/svg\'%3E'];
          svgs.forEach(function (svg) {
            placeholderImages.push('%3Crect width=\'' + svg.width + '\' x=\'' + svg.left + '\' height=\'' + svg.height + '\' y=\'' + svg.top + '\' ' + fill + ' /%3E');
          });
          placeholderImages.push('%3C/svg%3E');
          this.setData({
            placeholderImageStr: placeholderImages.join('')
          });
        }
      }
    });

    /***/
  }

  /******/ });
});
define("miniprogram_npm/widget-ui/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports = function () {
  var __MODS__ = {};
  var __DEFINE__ = function __DEFINE__(modId, func, req) {
    var m = { exports: {}, _tempexports: {} };__MODS__[modId] = { status: 0, func: func, req: req, m: m };
  };
  var __REQUIRE__ = function __REQUIRE__(modId, source) {
    if (!__MODS__[modId]) return require(source);if (!__MODS__[modId].status) {
      var m = __MODS__[modId].m;m._exports = m._tempexports;var desp = Object.getOwnPropertyDescriptor(m, "exports");if (desp && desp.configurable) Object.defineProperty(m, "exports", { set: function set(val) {
          if ((typeof val === "undefined" ? "undefined" : _typeof(val)) === "object" && val !== m._exports) {
            m._exports.__proto__ = val.__proto__;Object.keys(val).forEach(function (k) {
              m._exports[k] = val[k];
            });
          }m._tempexports = val;
        }, get: function get() {
          return m._tempexports;
        } });__MODS__[modId].status = 1;__MODS__[modId].func(__MODS__[modId].req, m, m.exports);
    }return __MODS__[modId].m.exports;
  };
  var __REQUIRE_WILDCARD__ = function __REQUIRE_WILDCARD__(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var k in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, k)) newObj[k] = obj[k];
        }
      }newObj.default = obj;return newObj;
    }
  };
  var __REQUIRE_DEFAULT__ = function __REQUIRE_DEFAULT__(obj) {
    return obj && obj.__esModule ? obj.default : obj;
  };
  __DEFINE__(1603952260666, function (require, module, exports) {
    !function (t, e) {
      if ("object" == (typeof exports === "undefined" ? "undefined" : _typeof(exports)) && "object" == (typeof module === "undefined" ? "undefined" : _typeof(module))) module.exports = e();else if ("function" == typeof define && define.amd) define([], e);else {
        var o = e();for (var r in o) {
          ("object" == (typeof exports === "undefined" ? "undefined" : _typeof(exports)) ? exports : t)[r] = o[r];
        }
      }
    }(this, function () {
      return function (t) {
        var e = {};function o(r) {
          if (e[r]) return e[r].exports;var i = e[r] = { i: r, l: !1, exports: {} };return t[r].call(i.exports, i, i.exports, o), i.l = !0, i.exports;
        }return o.m = t, o.c = e, o.d = function (t, e, r) {
          o.o(t, e) || Object.defineProperty(t, e, { enumerable: !0, get: r });
        }, o.r = function (t) {
          "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t, "__esModule", { value: !0 });
        }, o.t = function (t, e) {
          if (1 & e && (t = o(t)), 8 & e) return t;if (4 & e && "object" == (typeof t === "undefined" ? "undefined" : _typeof(t)) && t && t.__esModule) return t;var r = Object.create(null);if (o.r(r), Object.defineProperty(r, "default", { enumerable: !0, value: t }), 2 & e && "string" != typeof t) for (var i in t) {
            o.d(r, i, function (e) {
              return t[e];
            }.bind(null, i));
          }return r;
        }, o.n = function (t) {
          var e = t && t.__esModule ? function () {
            return t.default;
          } : function () {
            return t;
          };return o.d(e, "a", e), e;
        }, o.o = function (t, e) {
          return Object.prototype.hasOwnProperty.call(t, e);
        }, o.p = "", o(o.s = 0);
      }([function (t, e, o) {
        var r = this && this.__importDefault || function (t) {
          return t && t.__esModule ? t : { default: t };
        };Object.defineProperty(e, "__esModule", { value: !0 });var i = r(o(1)),
            l = o(2),
            n = 0,
            a = function () {
          function t(e) {
            var o = this;void 0 === e && (e = {}), this.parent = null, this.id = t.uuid(), this.style = {}, this.computedStyle = {}, this.lastComputedStyle = {}, this.children = {}, this.layoutBox = { left: 0, top: 0, width: 0, height: 0 }, e = Object.assign(l.getDefaultStyle(), e), this.computedStyle = Object.assign(l.getDefaultStyle(), e), this.lastComputedStyle = Object.assign(l.getDefaultStyle(), e), Object.keys(e).forEach(function (t) {
              Object.defineProperty(o.style, t, { configurable: !0, enumerable: !0, get: function get() {
                  return e[t];
                }, set: function set(r) {
                  r !== e[t] && void 0 !== r && (o.lastComputedStyle = o.computedStyle[t], e[t] = r, o.computedStyle[t] = r, l.scalableStyles.includes(t) && o.style.scale && (o.computedStyle[t] = r * o.style.scale), "scale" === t && l.scalableStyles.forEach(function (t) {
                    e[t] && (o.computedStyle[t] = e[t] * r);
                  }), "hidden" === t && (r ? l.layoutAffectedStyles.forEach(function (t) {
                    o.computedStyle[t] = 0;
                  }) : l.layoutAffectedStyles.forEach(function (t) {
                    o.computedStyle[t] = o.lastComputedStyle[t];
                  })));
                } });
            }), this.style.scale && l.scalableStyles.forEach(function (t) {
              if (o.style[t]) {
                var e = o.style[t] * o.style.scale;o.computedStyle[t] = e;
              }
            }), e.hidden && l.layoutAffectedStyles.forEach(function (t) {
              o.computedStyle[t] = 0;
            });
          }return t.uuid = function () {
            return n++;
          }, t.prototype.getAbsolutePosition = function (t) {
            if (!t) return this.getAbsolutePosition(this);if (!t.parent) return { left: 0, top: 0 };var e = this.getAbsolutePosition(t.parent),
                o = e.left,
                r = e.top;return { left: o + t.layoutBox.left, top: r + t.layoutBox.top };
          }, t.prototype.add = function (t) {
            t.parent = this, this.children[t.id] = t;
          }, t.prototype.remove = function (t) {
            var e = this;t ? this.children[t.id] && (t.remove(), delete this.children[t.id]) : Object.keys(this.children).forEach(function (t) {
              e.children[t].remove(), delete e.children[t];
            });
          }, t.prototype.getNodeTree = function () {
            var t = this;return { id: this.id, style: this.computedStyle, children: Object.keys(this.children).map(function (e) {
                return t.children[e].getNodeTree();
              }) };
          }, t.prototype.applyLayout = function (t) {
            var e = this;["left", "top", "width", "height"].forEach(function (o) {
              t.layout && "number" == typeof t.layout[o] && (e.layoutBox[o] = t.layout[o], !e.parent || "left" !== o && "top" !== o || (e.layoutBox[o] += e.parent.layoutBox[o]));
            }), t.children.forEach(function (t) {
              e.children[t.id].applyLayout(t);
            });
          }, t.prototype.layout = function () {
            var t = this.getNodeTree();i.default(t), this.applyLayout(t);
          }, t;
        }();e.default = a;
      }, function (t, e, o) {
        o.r(e);var r = function () {
          var t,
              e = "inherit",
              o = "ltr",
              r = "rtl",
              i = "row",
              l = "row-reverse",
              n = "column",
              a = "column-reverse",
              u = "flex-start",
              d = "center",
              s = "flex-end",
              y = "space-between",
              c = "space-around",
              f = "flex-start",
              h = "center",
              p = "flex-end",
              g = "stretch",
              v = "relative",
              m = "absolute",
              b = { row: "left", "row-reverse": "right", column: "top", "column-reverse": "bottom" },
              x = { row: "right", "row-reverse": "left", column: "bottom", "column-reverse": "top" },
              w = { row: "left", "row-reverse": "right", column: "top", "column-reverse": "bottom" },
              S = { row: "width", "row-reverse": "width", column: "height", "column-reverse": "height" };function W(t) {
            return void 0 === t;
          }function L(t) {
            return t === i || t === l;
          }function k(t, e) {
            if (void 0 !== t.style.marginStart && L(e)) return t.style.marginStart;var o = null;switch (e) {case "row":
                o = t.style.marginLeft;break;case "row-reverse":
                o = t.style.marginRight;break;case "column":
                o = t.style.marginTop;break;case "column-reverse":
                o = t.style.marginBottom;}return void 0 !== o ? o : void 0 !== t.style.margin ? t.style.margin : 0;
          }function j(t, e) {
            if (void 0 !== t.style.marginEnd && L(e)) return t.style.marginEnd;var o = null;switch (e) {case "row":
                o = t.style.marginRight;break;case "row-reverse":
                o = t.style.marginLeft;break;case "column":
                o = t.style.marginBottom;break;case "column-reverse":
                o = t.style.marginTop;}return null != o ? o : void 0 !== t.style.margin ? t.style.margin : 0;
          }function B(t, e) {
            if (void 0 !== t.style.borderStartWidth && t.style.borderStartWidth >= 0 && L(e)) return t.style.borderStartWidth;var o = null;switch (e) {case "row":
                o = t.style.borderLeftWidth;break;case "row-reverse":
                o = t.style.borderRightWidth;break;case "column":
                o = t.style.borderTopWidth;break;case "column-reverse":
                o = t.style.borderBottomWidth;}return null != o && o >= 0 ? o : void 0 !== t.style.borderWidth && t.style.borderWidth >= 0 ? t.style.borderWidth : 0;
          }function E(t, e) {
            if (void 0 !== t.style.borderEndWidth && t.style.borderEndWidth >= 0 && L(e)) return t.style.borderEndWidth;var o = null;switch (e) {case "row":
                o = t.style.borderRightWidth;break;case "row-reverse":
                o = t.style.borderLeftWidth;break;case "column":
                o = t.style.borderBottomWidth;break;case "column-reverse":
                o = t.style.borderTopWidth;}return null != o && o >= 0 ? o : void 0 !== t.style.borderWidth && t.style.borderWidth >= 0 ? t.style.borderWidth : 0;
          }function C(t, e) {
            return function (t, e) {
              if (void 0 !== t.style.paddingStart && t.style.paddingStart >= 0 && L(e)) return t.style.paddingStart;var o = null;switch (e) {case "row":
                  o = t.style.paddingLeft;break;case "row-reverse":
                  o = t.style.paddingRight;break;case "column":
                  o = t.style.paddingTop;break;case "column-reverse":
                  o = t.style.paddingBottom;}return null != o && o >= 0 ? o : void 0 !== t.style.padding && t.style.padding >= 0 ? t.style.padding : 0;
            }(t, e) + B(t, e);
          }function T(t, e) {
            return function (t, e) {
              if (void 0 !== t.style.paddingEnd && t.style.paddingEnd >= 0 && L(e)) return t.style.paddingEnd;var o = null;switch (e) {case "row":
                  o = t.style.paddingRight;break;case "row-reverse":
                  o = t.style.paddingLeft;break;case "column":
                  o = t.style.paddingBottom;break;case "column-reverse":
                  o = t.style.paddingTop;}return null != o && o >= 0 ? o : void 0 !== t.style.padding && t.style.padding >= 0 ? t.style.padding : 0;
            }(t, e) + E(t, e);
          }function O(t, e) {
            return B(t, e) + E(t, e);
          }function _(t, e) {
            return k(t, e) + j(t, e);
          }function R(t, e) {
            return C(t, e) + T(t, e);
          }function A(t, e) {
            return e.style.alignSelf ? e.style.alignSelf : t.style.alignItems ? t.style.alignItems : "stretch";
          }function P(t, e) {
            if (e === r) {
              if (t === i) return l;if (t === l) return i;
            }return t;
          }function D(t, e) {
            return function (t) {
              return t === n || t === a;
            }(t) ? P(i, e) : n;
          }function H(t) {
            return t.style.position ? t.style.position : "relative";
          }function M(t) {
            return H(t) === v && t.style.flex > 0;
          }function I(t, e) {
            return t.layout[S[e]] + _(t, e);
          }function N(t, e) {
            return void 0 !== t.style[S[e]] && t.style[S[e]] >= 0;
          }function F(t, e) {
            return void 0 !== t.style[e];
          }function q(t, e) {
            return void 0 !== t.style[e] ? t.style[e] : 0;
          }function z(t, e, o) {
            var r = { row: t.style.minWidth, "row-reverse": t.style.minWidth, column: t.style.minHeight, "column-reverse": t.style.minHeight }[e],
                i = { row: t.style.maxWidth, "row-reverse": t.style.maxWidth, column: t.style.maxHeight, "column-reverse": t.style.maxHeight }[e],
                l = o;return void 0 !== i && i >= 0 && l > i && (l = i), void 0 !== r && r >= 0 && l < r && (l = r), l;
          }function U(t, e) {
            return t > e ? t : e;
          }function G(t, e) {
            void 0 === t.layout[S[e]] && N(t, e) && (t.layout[S[e]] = U(z(t, e, t.style[S[e]]), R(t, e)));
          }function J(t, e, o) {
            e.layout[x[o]] = t.layout[S[o]] - e.layout[S[o]] - e.layout[w[o]];
          }function K(t, e) {
            return void 0 !== t.style[b[e]] ? q(t, b[e]) : -q(t, x[e]);
          }function Q(r, E, Q) {
            var X = function (t, r) {
              var i;return (i = t.style.direction ? t.style.direction : e) === e && (i = void 0 === r ? o : r), i;
            }(r, Q),
                Y = P(function (t) {
              return t.style.flexDirection ? t.style.flexDirection : n;
            }(r), X),
                Z = D(Y, X),
                $ = P(i, X);G(r, Y), G(r, Z), r.layout.direction = X, r.layout[b[Y]] += k(r, Y) + K(r, Y), r.layout[x[Y]] += j(r, Y) + K(r, Y), r.layout[b[Z]] += k(r, Z) + K(r, Z), r.layout[x[Z]] += j(r, Z) + K(r, Z);var tt = r.children.length,
                et = R(r, $);if (function (t) {
              return void 0 !== t.style.measure;
            }(r)) {
              var ot = !W(r.layout[S[$]]),
                  rt = t;rt = N(r, $) ? r.style.width : ot ? r.layout[S[$]] : E - _(r, $), rt -= et;var it = !N(r, $) && !ot,
                  lt = !N(r, n) && W(r.layout[S[n]]);if (it || lt) {
                var nt = r.style.measure(rt);it && (r.layout.width = nt.width + et), lt && (r.layout.height = nt.height + R(r, n));
              }if (0 === tt) return;
            }var at,
                ut,
                dt,
                st,
                yt = function (t) {
              return "wrap" === t.style.flexWrap;
            }(r),
                ct = function (t) {
              return t.style.justifyContent ? t.style.justifyContent : "flex-start";
            }(r),
                ft = C(r, Y),
                ht = C(r, Z),
                pt = R(r, Y),
                gt = R(r, Z),
                vt = !W(r.layout[S[Y]]),
                mt = !W(r.layout[S[Z]]),
                bt = L(Y),
                xt = null,
                wt = null,
                St = t;vt && (St = r.layout[S[Y]] - pt);for (var Wt = 0, Lt = 0, kt = 0, jt = 0, Bt = 0, Et = 0; Lt < tt;) {
              var Ct,
                  Tt = 0,
                  Ot = 0,
                  _t = 0,
                  Rt = 0,
                  At = vt && ct === u || !vt && ct !== d,
                  Pt = At ? tt : Wt,
                  Dt = !0,
                  Ht = tt,
                  Mt = null,
                  It = null,
                  Nt = ft,
                  Ft = 0;for (at = Wt; at < tt; ++at) {
                if ((dt = r.children[at]).lineIndex = Et, dt.nextAbsoluteChild = null, dt.nextFlexChild = null, (Xt = A(r, dt)) === g && H(dt) === v && mt && !N(dt, Z)) dt.layout[S[Z]] = U(z(dt, Z, r.layout[S[Z]] - gt - _(dt, Z)), R(dt, Z));else if (H(dt) === m) for (null === xt && (xt = dt), null !== wt && (wt.nextAbsoluteChild = dt), wt = dt, ut = 0; ut < 2; ut++) {
                  st = 0 !== ut ? i : n, !W(r.layout[S[st]]) && !N(dt, st) && F(dt, b[st]) && F(dt, x[st]) && (dt.layout[S[st]] = U(z(dt, st, r.layout[S[st]] - R(r, st) - _(dt, st) - q(dt, b[st]) - q(dt, x[st])), R(dt, st)));
                }var qt = 0;if (vt && M(dt) ? (Ot++, _t += dt.style.flex, null === Mt && (Mt = dt), null !== It && (It.nextFlexChild = dt), It = dt, qt = R(dt, Y) + _(dt, Y)) : (Ct = t, bt || (Ct = N(r, $) ? r.layout[S[$]] - et : E - _(r, $) - et), 0 === kt && V(dt, Ct, X), H(dt) === v && (Rt++, qt = I(dt, Y))), yt && vt && Tt + qt > St && at !== Wt) {
                  Rt--, kt = 1;break;
                }At && (H(dt) !== v || M(dt)) && (At = !1, Pt = at), Dt && (H(dt) !== v || Xt !== g && Xt !== f || W(dt.layout[S[Z]])) && (Dt = !1, Ht = at), At && (dt.layout[w[Y]] += Nt, vt && J(r, dt, Y), Nt += I(dt, Y), Ft = U(Ft, z(dt, Z, I(dt, Z)))), Dt && (dt.layout[w[Z]] += jt + ht, mt && J(r, dt, Z)), kt = 0, Tt += qt, Lt = at + 1;
              }var zt = 0,
                  Ut = 0,
                  Gt = 0;if (Gt = vt ? St - Tt : U(Tt, 0) - Tt, 0 !== Ot) {
                var Jt,
                    Kt,
                    Qt = Gt / _t;for (It = Mt; null !== It;) {
                  (Jt = Qt * It.style.flex + R(It, Y)) !== (Kt = z(It, Y, Jt)) && (Gt -= Kt, _t -= It.style.flex), It = It.nextFlexChild;
                }for ((Qt = Gt / _t) < 0 && (Qt = 0), It = Mt; null !== It;) {
                  It.layout[S[Y]] = z(It, Y, Qt * It.style.flex + R(It, Y)), Ct = t, N(r, $) ? Ct = r.layout[S[$]] - et : bt || (Ct = E - _(r, $) - et), V(It, Ct, X), dt = It, It = It.nextFlexChild, dt.nextFlexChild = null;
                }
              } else ct !== u && (ct === d ? zt = Gt / 2 : ct === s ? zt = Gt : ct === y ? (Gt = U(Gt, 0), Ut = Ot + Rt - 1 != 0 ? Gt / (Ot + Rt - 1) : 0) : ct === c && (zt = (Ut = Gt / (Ot + Rt)) / 2));for (Nt += zt, at = Pt; at < Lt; ++at) {
                H(dt = r.children[at]) === m && F(dt, b[Y]) ? dt.layout[w[Y]] = q(dt, b[Y]) + B(r, Y) + k(dt, Y) : (dt.layout[w[Y]] += Nt, vt && J(r, dt, Y), H(dt) === v && (Nt += Ut + I(dt, Y), Ft = U(Ft, z(dt, Z, I(dt, Z)))));
              }var Vt = r.layout[S[Z]];for (mt || (Vt = U(z(r, Z, Ft + gt), gt)), at = Ht; at < Lt; ++at) {
                if (H(dt = r.children[at]) === m && F(dt, b[Z])) dt.layout[w[Z]] = q(dt, b[Z]) + B(r, Z) + k(dt, Z);else {
                  var Xt,
                      Yt = ht;if (H(dt) === v) if ((Xt = A(r, dt)) === g) W(dt.layout[S[Z]]) && (dt.layout[S[Z]] = U(z(dt, Z, Vt - gt - _(dt, Z)), R(dt, Z)));else if (Xt !== f) {
                    var Zt = Vt - gt - I(dt, Z);Yt += Xt === h ? Zt / 2 : Zt;
                  }dt.layout[w[Z]] += jt + Yt, mt && J(r, dt, Z);
                }
              }jt += Ft, Bt = U(Bt, Nt), Et += 1, Wt = Lt;
            }if (Et > 1 && mt) {
              var $t = r.layout[S[Z]] - gt,
                  te = $t - jt,
                  ee = 0,
                  oe = ht,
                  re = function (t) {
                return t.style.alignContent ? t.style.alignContent : "flex-start";
              }(r);re === p ? oe += te : re === h ? oe += te / 2 : re === g && $t > jt && (ee = te / Et);var ie = 0;for (at = 0; at < Et; ++at) {
                var le = ie,
                    ne = 0;for (ut = le; ut < tt; ++ut) {
                  if (H(dt = r.children[ut]) === v) {
                    if (dt.lineIndex !== at) break;W(dt.layout[S[Z]]) || (ne = U(ne, dt.layout[S[Z]] + _(dt, Z)));
                  }
                }for (ie = ut, ne += ee, ut = le; ut < ie; ++ut) {
                  if (H(dt = r.children[ut]) === v) {
                    var ae = A(r, dt);if (ae === f) dt.layout[w[Z]] = oe + k(dt, Z);else if (ae === p) dt.layout[w[Z]] = oe + ne - j(dt, Z) - dt.layout[S[Z]];else if (ae === h) {
                      var ue = dt.layout[S[Z]];dt.layout[w[Z]] = oe + (ne - ue) / 2;
                    } else ae === g && (dt.layout[w[Z]] = oe + k(dt, Z));
                  }
                }oe += ne;
              }
            }var de = !1,
                se = !1;if (vt || (r.layout[S[Y]] = U(z(r, Y, Bt + T(r, Y)), pt), Y !== l && Y !== a || (de = !0)), mt || (r.layout[S[Z]] = U(z(r, Z, jt + gt), gt), Z !== l && Z !== a || (se = !0)), de || se) for (at = 0; at < tt; ++at) {
              dt = r.children[at], de && J(r, dt, Y), se && J(r, dt, Z);
            }for (wt = xt; null !== wt;) {
              for (ut = 0; ut < 2; ut++) {
                st = 0 !== ut ? i : n, !W(r.layout[S[st]]) && !N(wt, st) && F(wt, b[st]) && F(wt, x[st]) && (wt.layout[S[st]] = U(z(wt, st, r.layout[S[st]] - O(r, st) - _(wt, st) - q(wt, b[st]) - q(wt, x[st])), R(wt, st))), F(wt, x[st]) && !F(wt, b[st]) && (wt.layout[b[st]] = r.layout[S[st]] - wt.layout[S[st]] - q(wt, x[st]));
              }dt = wt, wt = wt.nextAbsoluteChild, dt.nextAbsoluteChild = null;
            }
          }function V(t, e, r) {
            t.shouldUpdate = !0;var i = t.style.direction || o;!t.isDirty && t.lastLayout && t.lastLayout.requestedHeight === t.layout.height && t.lastLayout.requestedWidth === t.layout.width && t.lastLayout.parentMaxWidth === e && t.lastLayout.direction === i ? (t.layout.width = t.lastLayout.width, t.layout.height = t.lastLayout.height, t.layout.top = t.lastLayout.top, t.layout.left = t.lastLayout.left) : (t.lastLayout || (t.lastLayout = {}), t.lastLayout.requestedWidth = t.layout.width, t.lastLayout.requestedHeight = t.layout.height, t.lastLayout.parentMaxWidth = e, t.lastLayout.direction = i, t.children.forEach(function (t) {
              t.layout.width = void 0, t.layout.height = void 0, t.layout.top = 0, t.layout.left = 0;
            }), Q(t, e, r), t.lastLayout.width = t.layout.width, t.lastLayout.height = t.layout.height, t.lastLayout.top = t.layout.top, t.lastLayout.left = t.layout.left);
          }return { layoutNodeImpl: Q, computeLayout: V, fillNodes: function t(e) {
              return e.layout && !e.isDirty || (e.layout = { width: void 0, height: void 0, top: 0, left: 0, right: 0, bottom: 0 }), e.style || (e.style = {}), e.children || (e.children = []), e.children.forEach(t), e;
            } };
        }();e.default = function (t) {
          r.fillNodes(t), r.computeLayout(t);
        };
      }, function (t, e, o) {
        Object.defineProperty(e, "__esModule", { value: !0 });e.textStyles = ["color", "fontSize", "textAlign", "fontWeight", "lineHeight", "lineBreak"];e.scalableStyles = ["left", "top", "right", "bottom", "width", "height", "margin", "marginLeft", "marginRight", "marginTop", "marginBottom", "padding", "paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "borderWidth", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"];e.layoutAffectedStyles = ["margin", "marginTop", "marginBottom", "marginLeft", "marginRight", "padding", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "width", "height"];e.getDefaultStyle = function () {
          return { left: void 0, top: void 0, right: void 0, bottom: void 0, width: void 0, height: void 0, maxWidth: void 0, maxHeight: void 0, minWidth: void 0, minHeight: void 0, margin: void 0, marginLeft: void 0, marginRight: void 0, marginTop: void 0, marginBottom: void 0, padding: void 0, paddingLeft: void 0, paddingRight: void 0, paddingTop: void 0, paddingBottom: void 0, borderWidth: void 0, flexDirection: void 0, justifyContent: void 0, alignItems: void 0, alignSelf: void 0, flex: void 0, flexWrap: void 0, position: void 0, hidden: !1, scale: 1 };
        };
      }]).default;
    });
  }, function (modId) {
    var map = {};return __REQUIRE__(map[modId], modId);
  });
  return __REQUIRE__(1603952260666);
}();
//# sourceMappingURL=index.js.map
});
define("miniprogram_npm/wxml-to-canvas/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

(function webpackUniversalModuleDefinition(root, factory) {
  if ((typeof exports === 'undefined' ? 'undefined' : _typeof(exports)) === 'object' && (typeof module === 'undefined' ? 'undefined' : _typeof(module)) === 'object') module.exports = factory();else if (typeof define === 'function' && define.amd) define([], factory);else {
    var a = factory();
    for (var i in a) {
      ((typeof exports === 'undefined' ? 'undefined' : _typeof(exports)) === 'object' ? exports : root)[i] = a[i];
    }
  }
})(window, function () {
  return (/******/function (modules) {
      // webpackBootstrap
      /******/ // The module cache
      /******/var installedModules = {};
      /******/
      /******/ // The require function
      /******/function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
          /******/return installedModules[moduleId].exports;
          /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/var module = installedModules[moduleId] = {
          /******/i: moduleId,
          /******/l: false,
          /******/exports: {}
          /******/ };
        /******/
        /******/ // Execute the module function
        /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/return module.exports;
        /******/
      }
      /******/
      /******/
      /******/ // expose the modules object (__webpack_modules__)
      /******/__webpack_require__.m = modules;
      /******/
      /******/ // expose the module cache
      /******/__webpack_require__.c = installedModules;
      /******/
      /******/ // define getter function for harmony exports
      /******/__webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
          /******/Object.defineProperty(exports, name, { enumerable: true, get: getter });
          /******/
        }
        /******/
      };
      /******/
      /******/ // define __esModule on exports
      /******/__webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
          /******/Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
          /******/
        }
        /******/Object.defineProperty(exports, '__esModule', { value: true });
        /******/
      };
      /******/
      /******/ // create a fake namespace object
      /******/ // mode & 1: value is a module id, require it
      /******/ // mode & 2: merge all properties of value into the ns
      /******/ // mode & 4: return value when already ns object
      /******/ // mode & 8|1: behave like require
      /******/__webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/if (mode & 8) return value;
        /******/if (mode & 4 && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value && value.__esModule) return value;
        /******/var ns = Object.create(null);
        /******/__webpack_require__.r(ns);
        /******/Object.defineProperty(ns, 'default', { enumerable: true, value: value });
        /******/if (mode & 2 && typeof value != 'string') for (var key in value) {
          __webpack_require__.d(ns, key, function (key) {
            return value[key];
          }.bind(null, key));
        } /******/return ns;
        /******/
      };
      /******/
      /******/ // getDefaultExport function for compatibility with non-harmony modules
      /******/__webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ?
        /******/function getDefault() {
          return module['default'];
        } :
        /******/function getModuleExports() {
          return module;
        };
        /******/__webpack_require__.d(getter, 'a', getter);
        /******/return getter;
        /******/
      };
      /******/
      /******/ // Object.prototype.hasOwnProperty.call
      /******/__webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
      };
      /******/
      /******/ // __webpack_public_path__
      /******/__webpack_require__.p = "";
      /******/
      /******/
      /******/ // Load entry module and return exports
      /******/return __webpack_require__(__webpack_require__.s = 1);
      /******/
    }(
    /************************************************************************/
    /******/[
    /* 0 */
    /***/function (module, exports) {

      var hex = function hex(color) {
        var result = null;

        if (/^#/.test(color) && (color.length === 7 || color.length === 9)) {
          return color;
          // eslint-disable-next-line no-cond-assign
        } else if ((result = /^(rgb|rgba)\((.+)\)/.exec(color)) !== null) {
          return '#' + result[2].split(',').map(function (part, index) {
            part = part.trim();
            part = index === 3 ? Math.floor(parseFloat(part) * 255) : parseInt(part, 10);
            part = part.toString(16);
            if (part.length === 1) {
              part = '0' + part;
            }
            return part;
          }).join('');
        } else {
          return '#00000000';
        }
      };

      var splitLineToCamelCase = function splitLineToCamelCase(str) {
        return str.split('-').map(function (part, index) {
          if (index === 0) {
            return part;
          }
          return part[0].toUpperCase() + part.slice(1);
        }).join('');
      };

      var compareVersion = function compareVersion(v1, v2) {
        v1 = v1.split('.');
        v2 = v2.split('.');
        var len = Math.max(v1.length, v2.length);
        while (v1.length < len) {
          v1.push('0');
        }
        while (v2.length < len) {
          v2.push('0');
        }
        for (var i = 0; i < len; i++) {
          var num1 = parseInt(v1[i], 10);
          var num2 = parseInt(v2[i], 10);

          if (num1 > num2) {
            return 1;
          } else if (num1 < num2) {
            return -1;
          }
        }

        return 0;
      };

      module.exports = {
        hex: hex,
        splitLineToCamelCase: splitLineToCamelCase,
        compareVersion: compareVersion

        /***/ };
    },
    /* 1 */
    /***/function (module, exports, __webpack_require__) {

      var xmlParse = __webpack_require__(2);

      var _webpack_require__ = __webpack_require__(3),
          Widget = _webpack_require__.Widget;

      var _webpack_require__2 = __webpack_require__(5),
          Draw = _webpack_require__2.Draw;

      var _webpack_require__3 = __webpack_require__(0),
          compareVersion = _webpack_require__3.compareVersion;

      var canvasId = 'weui-canvas';

      Component({
        properties: {
          width: {
            type: Number,
            value: 400
          },
          height: {
            type: Number,
            value: 300
          }
        },
        data: {
          use2dCanvas: false // 2.9.2 后可用canvas 2d 接口
        },
        lifetimes: {
          attached: function attached() {
            var _this = this;

            var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
                SDKVersion = _wx$getSystemInfoSync.SDKVersion,
                dpr = _wx$getSystemInfoSync.pixelRatio;

            var use2dCanvas = compareVersion(SDKVersion, '2.9.2') >= 0;
            this.dpr = dpr;
            this.setData({ use2dCanvas: use2dCanvas }, function () {
              if (use2dCanvas) {
                var query = _this.createSelectorQuery();
                query.select('#' + canvasId).fields({ node: true, size: true }).exec(function (res) {
                  var canvas = res[0].node;
                  var ctx = canvas.getContext('2d');
                  canvas.width = res[0].width * dpr;
                  canvas.height = res[0].height * dpr;
                  ctx.scale(dpr, dpr);
                  _this.ctx = ctx;
                  _this.canvas = canvas;
                });
              } else {
                _this.ctx = wx.createCanvasContext(canvasId, _this);
              }
            });
          }
        },
        methods: {
          renderToCanvas: function renderToCanvas(args) {
            var _this2 = this;

            return _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var wxml, style, ctx, canvas, use2dCanvas, _xmlParse, xom, widget, container, draw;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      wxml = args.wxml, style = args.style;
                      ctx = _this2.ctx;
                      canvas = _this2.canvas;
                      use2dCanvas = _this2.data.use2dCanvas;

                      if (!(use2dCanvas && !canvas)) {
                        _context.next = 6;
                        break;
                      }

                      return _context.abrupt('return', Promise.reject(new Error('renderToCanvas: fail canvas has not been created')));

                    case 6:

                      ctx.clearRect(0, 0, _this2.data.width, _this2.data.height);
                      _xmlParse = xmlParse(wxml), xom = _xmlParse.root;
                      widget = new Widget(xom, style);
                      container = widget.init();

                      _this2.boundary = {
                        top: container.layoutBox.top,
                        left: container.layoutBox.left,
                        width: container.computedStyle.width,
                        height: container.computedStyle.height
                      };
                      draw = new Draw(ctx, canvas, use2dCanvas);
                      _context.next = 14;
                      return draw.drawNode(container);

                    case 14:
                      if (use2dCanvas) {
                        _context.next = 17;
                        break;
                      }

                      _context.next = 17;
                      return _this2.canvasDraw(ctx);

                    case 17:
                      return _context.abrupt('return', Promise.resolve(container));

                    case 18:
                    case 'end':
                      return _context.stop();
                  }
                }
              }, _callee, _this2);
            }))();
          },
          canvasDraw: function canvasDraw(ctx, reserve) {
            return new Promise(function (resolve) {
              ctx.draw(reserve, function () {
                resolve();
              });
            });
          },
          canvasToTempFilePath: function canvasToTempFilePath() {
            var _this3 = this;

            var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            var use2dCanvas = this.data.use2dCanvas;

            return new Promise(function (resolve, reject) {
              var _boundary = _this3.boundary,
                  top = _boundary.top,
                  left = _boundary.left,
                  width = _boundary.width,
                  height = _boundary.height;


              var copyArgs = {
                x: left,
                y: top,
                width: width,
                height: height,
                destWidth: width * _this3.dpr,
                destHeight: height * _this3.dpr,
                canvasId: canvasId,
                fileType: args.fileType || 'png',
                quality: args.quality || 1,
                success: resolve,
                fail: reject
              };

              if (use2dCanvas) {
                delete copyArgs.canvasId;
                copyArgs.canvas = _this3.canvas;
              }
              wx.canvasToTempFilePath(copyArgs, _this3);
            });
          }
        }
      });

      /***/
    },
    /* 2 */
    /***/function (module, exports) {

      /**
       * Module dependencies.
       */

      /**
       * Expose `parse`.
       */

      /**
       * Parse the given string of `xml`.
       *
       * @param {String} xml
       * @return {Object}
       * @api public
       */

      function parse(xml) {
        xml = xml.trim();

        // strip comments
        xml = xml.replace(/<!--[\s\S]*?-->/g, '');

        return document();

        /**
         * XML document.
         */

        function document() {
          return {
            declaration: declaration(),
            root: tag()
          };
        }

        /**
         * Declaration.
         */

        function declaration() {
          var m = match(/^<\?xml\s*/);
          if (!m) return;

          // tag
          var node = {
            attributes: {}

            // attributes
          };while (!(eos() || is('?>'))) {
            var attr = attribute();
            if (!attr) return node;
            node.attributes[attr.name] = attr.value;
          }

          match(/\?>\s*/);

          return node;
        }

        /**
         * Tag.
         */

        function tag() {
          var m = match(/^<([\w-:.]+)\s*/);
          if (!m) return;

          // name
          var node = {
            name: m[1],
            attributes: {},
            children: []

            // attributes
          };while (!(eos() || is('>') || is('?>') || is('/>'))) {
            var attr = attribute();
            if (!attr) return node;
            node.attributes[attr.name] = attr.value;
          }

          // self closing tag
          if (match(/^\s*\/>\s*/)) {
            return node;
          }

          match(/\??>\s*/);

          // content
          node.content = content();

          // children
          var child = void 0;
          while (child = tag()) {
            node.children.push(child);
          }

          // closing
          match(/^<\/[\w-:.]+>\s*/);

          return node;
        }

        /**
         * Text content.
         */

        function content() {
          var m = match(/^([^<]*)/);
          if (m) return m[1];
          return '';
        }

        /**
         * Attribute.
         */

        function attribute() {
          var m = match(/([\w:-]+)\s*=\s*("[^"]*"|'[^']*'|\w+)\s*/);
          if (!m) return;
          return { name: m[1], value: strip(m[2]) };
        }

        /**
         * Strip quotes from `val`.
         */

        function strip(val) {
          return val.replace(/^['"]|['"]$/g, '');
        }

        /**
         * Match `re` and advance the string.
         */

        function match(re) {
          var m = xml.match(re);
          if (!m) return;
          xml = xml.slice(m[0].length);
          return m;
        }

        /**
         * End-of-source.
         */

        function eos() {
          return xml.length == 0;
        }

        /**
         * Check for `prefix`.
         */

        function is(prefix) {
          return xml.indexOf(prefix) == 0;
        }
      }

      module.exports = parse;

      /***/
    },
    /* 3 */
    /***/function (module, exports, __webpack_require__) {

      var Block = __webpack_require__(4);

      var _webpack_require__4 = __webpack_require__(0),
          splitLineToCamelCase = _webpack_require__4.splitLineToCamelCase;

      var Element = function (_Block) {
        _inherits(Element, _Block);

        function Element(prop) {
          _classCallCheck(this, Element);

          var _this4 = _possibleConstructorReturn(this, (Element.__proto__ || Object.getPrototypeOf(Element)).call(this, prop.style));

          _this4.name = prop.name;
          _this4.attributes = prop.attributes;
          return _this4;
        }

        return Element;
      }(Block);

      var Widget = function () {
        function Widget(xom, style) {
          _classCallCheck(this, Widget);

          this.xom = xom;
          this.style = style;

          this.inheritProps = ['fontSize', 'lineHeight', 'textAlign', 'verticalAlign', 'color'];
        }

        _createClass(Widget, [{
          key: 'init',
          value: function init() {
            this.container = this.create(this.xom);
            this.container.layout();

            this.inheritStyle(this.container);
            return this.container;
          }

          // 继承父节点的样式

        }, {
          key: 'inheritStyle',
          value: function inheritStyle(node) {
            var _this5 = this;

            var parent = node.parent || null;
            var children = node.children || {};
            var computedStyle = node.computedStyle;

            if (parent) {
              this.inheritProps.forEach(function (prop) {
                computedStyle[prop] = computedStyle[prop] || parent.computedStyle[prop];
              });
            }

            Object.values(children).forEach(function (child) {
              _this5.inheritStyle(child);
            });
          }
        }, {
          key: 'create',
          value: function create(node) {
            var _this6 = this;

            var classNames = (node.attributes.class || '').split(' ');
            classNames = classNames.map(function (item) {
              return splitLineToCamelCase(item.trim());
            });
            var style = {};
            classNames.forEach(function (item) {
              Object.assign(style, _this6.style[item] || {});
            });

            var args = { name: node.name, style: style };

            var attrs = Object.keys(node.attributes);
            var attributes = {};
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = attrs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var attr = _step.value;

                var value = node.attributes[attr];
                var CamelAttr = splitLineToCamelCase(attr);

                if (value === '' || value === 'true') {
                  attributes[CamelAttr] = true;
                } else if (value === 'false') {
                  attributes[CamelAttr] = false;
                } else {
                  attributes[CamelAttr] = value;
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            attributes.text = node.content;
            args.attributes = attributes;
            var element = new Element(args);
            node.children.forEach(function (childNode) {
              var childElement = _this6.create(childNode);
              element.add(childElement);
            });
            return element;
          }
        }]);

        return Widget;
      }();

      module.exports = { Widget: Widget

        /***/ };
    },
    /* 4 */
    /***/function (module, exports) {

      module.exports = require("widget-ui");

      /***/
    },
    /* 5 */
    /***/function (module, exports) {
      var Draw = function () {
        function Draw(context, canvas) {
          var use2dCanvas = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

          _classCallCheck(this, Draw);

          this.ctx = context;
          this.canvas = canvas || null;
          this.use2dCanvas = use2dCanvas;
        }

        _createClass(Draw, [{
          key: 'roundRect',
          value: function roundRect(x, y, w, h, r) {
            var fill = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : true;
            var stroke = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;

            if (r < 0) return;
            var ctx = this.ctx;

            ctx.beginPath();
            ctx.arc(x + r, y + r, r, Math.PI, Math.PI * 3 / 2);
            ctx.arc(x + w - r, y + r, r, Math.PI * 3 / 2, 0);
            ctx.arc(x + w - r, y + h - r, r, 0, Math.PI / 2);
            ctx.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI);
            ctx.lineTo(x, y + r);
            if (stroke) ctx.stroke();
            if (fill) ctx.fill();
          }
        }, {
          key: 'drawView',
          value: function drawView(box, style) {
            var ctx = this.ctx;
            var x = box.left,
                y = box.top,
                w = box.width,
                h = box.height;
            var _style$borderRadius = style.borderRadius,
                borderRadius = _style$borderRadius === undefined ? 0 : _style$borderRadius,
                _style$borderWidth = style.borderWidth,
                borderWidth = _style$borderWidth === undefined ? 0 : _style$borderWidth,
                borderColor = style.borderColor,
                _style$color = style.color,
                color = _style$color === undefined ? '#000' : _style$color,
                _style$backgroundColo = style.backgroundColor,
                backgroundColor = _style$backgroundColo === undefined ? 'transparent' : _style$backgroundColo;

            ctx.save();
            // 外环
            if (borderWidth > 0) {
              ctx.fillStyle = borderColor || color;
              this.roundRect(x, y, w, h, borderRadius);
            }

            // 内环
            ctx.fillStyle = backgroundColor;
            var innerWidth = w - 2 * borderWidth;
            var innerHeight = h - 2 * borderWidth;
            var innerRadius = borderRadius - borderWidth >= 0 ? borderRadius - borderWidth : 0;
            this.roundRect(x + borderWidth, y + borderWidth, innerWidth, innerHeight, innerRadius);
            ctx.restore();
          }
        }, {
          key: 'drawImage',
          value: function () {
            var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(img, box, style) {
              var _this7 = this;

              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return new Promise(function (resolve, reject) {
                        var ctx = _this7.ctx;
                        var canvas = _this7.canvas;

                        var _style$borderRadius2 = style.borderRadius,
                            borderRadius = _style$borderRadius2 === undefined ? 0 : _style$borderRadius2;
                        var x = box.left,
                            y = box.top,
                            w = box.width,
                            h = box.height;

                        ctx.save();
                        _this7.roundRect(x, y, w, h, borderRadius, false, false);
                        ctx.clip();

                        var _drawImage = function _drawImage(img) {
                          if (_this7.use2dCanvas) {
                            var Image = canvas.createImage();
                            Image.onload = function () {
                              ctx.drawImage(Image, x, y, w, h);
                              ctx.restore();
                              resolve();
                            };
                            Image.onerror = function () {
                              reject(new Error('createImage fail: ' + img));
                            };
                            Image.src = img;
                          } else {
                            ctx.drawImage(img, x, y, w, h);
                            ctx.restore();
                            resolve();
                          }
                        };

                        var isTempFile = /^wxfile:\/\//.test(img);
                        var isNetworkFile = /^https?:\/\//.test(img);

                        if (isTempFile) {
                          _drawImage(img);
                        } else if (isNetworkFile) {
                          wx.downloadFile({
                            url: img,
                            success: function success(res) {
                              if (res.statusCode === 200) {
                                _drawImage(res.tempFilePath);
                              } else {
                                reject(new Error('downloadFile:fail ' + img));
                              }
                            },
                            fail: function fail() {
                              reject(new Error('downloadFile:fail ' + img));
                            }
                          });
                        } else {
                          reject(new Error('image format error: ' + img));
                        }
                      });

                    case 2:
                    case 'end':
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));

            function drawImage(_x5, _x6, _x7) {
              return _ref.apply(this, arguments);
            }

            return drawImage;
          }()

          // eslint-disable-next-line complexity

        }, {
          key: 'drawText',
          value: function drawText(text, box, style) {
            var ctx = this.ctx;
            var x = box.left,
                y = box.top,
                w = box.width,
                h = box.height;
            var _style$color2 = style.color,
                color = _style$color2 === undefined ? '#000' : _style$color2,
                _style$lineHeight = style.lineHeight,
                lineHeight = _style$lineHeight === undefined ? '1.4em' : _style$lineHeight,
                _style$fontSize = style.fontSize,
                fontSize = _style$fontSize === undefined ? 14 : _style$fontSize,
                _style$textAlign = style.textAlign,
                textAlign = _style$textAlign === undefined ? 'left' : _style$textAlign,
                _style$verticalAlign = style.verticalAlign,
                verticalAlign = _style$verticalAlign === undefined ? 'top' : _style$verticalAlign,
                _style$backgroundColo2 = style.backgroundColor,
                backgroundColor = _style$backgroundColo2 === undefined ? 'transparent' : _style$backgroundColo2;


            if (typeof lineHeight === 'string') {
              // 2em
              lineHeight = Math.ceil(parseFloat(lineHeight.replace('em')) * fontSize);
            }
            if (!text || lineHeight > h) return;

            ctx.save();
            ctx.textBaseline = 'top';
            ctx.font = fontSize + 'px sans-serif';
            ctx.textAlign = textAlign;

            // 背景色
            ctx.fillStyle = backgroundColor;
            this.roundRect(x, y, w, h, 0);

            // 文字颜色
            ctx.fillStyle = color;

            // 水平布局
            switch (textAlign) {
              case 'left':
                break;
              case 'center':
                x += 0.5 * w;
                break;
              case 'right':
                x += w;
                break;
              default:
                break;
            }

            var textWidth = ctx.measureText(text).width;
            var actualHeight = Math.ceil(textWidth / w) * lineHeight;
            var paddingTop = Math.ceil((h - actualHeight) / 2);
            if (paddingTop < 0) paddingTop = 0;

            // 垂直布局
            switch (verticalAlign) {
              case 'top':
                break;
              case 'middle':
                y += paddingTop;
                break;
              case 'bottom':
                y += 2 * paddingTop;
                break;
              default:
                break;
            }

            var inlinePaddingTop = Math.ceil((lineHeight - fontSize) / 2);

            // 不超过一行
            if (textWidth <= w) {
              ctx.fillText(text, x, y + inlinePaddingTop);
              return;
            }

            // 多行文本
            var chars = text.split('');
            var _y = y;

            // 逐行绘制
            var line = '';
            var _iteratorNormalCompletion2 = true;
            var _didIteratorError2 = false;
            var _iteratorError2 = undefined;

            try {
              for (var _iterator2 = chars[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                var ch = _step2.value;

                var testLine = line + ch;
                var testWidth = ctx.measureText(testLine).width;

                if (testWidth > w) {
                  ctx.fillText(line, x, y + inlinePaddingTop);
                  y += lineHeight;
                  line = ch;
                  if (y + lineHeight > _y + h) break;
                } else {
                  line = testLine;
                }
              }

              // 避免溢出
            } catch (err) {
              _didIteratorError2 = true;
              _iteratorError2 = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion2 && _iterator2.return) {
                  _iterator2.return();
                }
              } finally {
                if (_didIteratorError2) {
                  throw _iteratorError2;
                }
              }
            }

            if (y + lineHeight <= _y + h) {
              ctx.fillText(line, x, y + inlinePaddingTop);
            }
            ctx.restore();
          }
        }, {
          key: 'drawNode',
          value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(element) {
              var layoutBox, computedStyle, name, _element$attributes, src, text, childs, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, child;

              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      layoutBox = element.layoutBox, computedStyle = element.computedStyle, name = element.name;
                      _element$attributes = element.attributes, src = _element$attributes.src, text = _element$attributes.text;

                      if (!(name === 'view')) {
                        _context3.next = 6;
                        break;
                      }

                      this.drawView(layoutBox, computedStyle);
                      _context3.next = 12;
                      break;

                    case 6:
                      if (!(name === 'image')) {
                        _context3.next = 11;
                        break;
                      }

                      _context3.next = 9;
                      return this.drawImage(src, layoutBox, computedStyle);

                    case 9:
                      _context3.next = 12;
                      break;

                    case 11:
                      if (name === 'text') {
                        this.drawText(text, layoutBox, computedStyle);
                      }

                    case 12:
                      childs = Object.values(element.children);
                      _iteratorNormalCompletion3 = true;
                      _didIteratorError3 = false;
                      _iteratorError3 = undefined;
                      _context3.prev = 16;
                      _iterator3 = childs[Symbol.iterator]();

                    case 18:
                      if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                        _context3.next = 25;
                        break;
                      }

                      child = _step3.value;
                      _context3.next = 22;
                      return this.drawNode(child);

                    case 22:
                      _iteratorNormalCompletion3 = true;
                      _context3.next = 18;
                      break;

                    case 25:
                      _context3.next = 31;
                      break;

                    case 27:
                      _context3.prev = 27;
                      _context3.t0 = _context3['catch'](16);
                      _didIteratorError3 = true;
                      _iteratorError3 = _context3.t0;

                    case 31:
                      _context3.prev = 31;
                      _context3.prev = 32;

                      if (!_iteratorNormalCompletion3 && _iterator3.return) {
                        _iterator3.return();
                      }

                    case 34:
                      _context3.prev = 34;

                      if (!_didIteratorError3) {
                        _context3.next = 37;
                        break;
                      }

                      throw _iteratorError3;

                    case 37:
                      return _context3.finish(34);

                    case 38:
                      return _context3.finish(31);

                    case 39:
                    case 'end':
                      return _context3.stop();
                  }
                }
              }, _callee3, this, [[16, 27, 31, 39], [32,, 34, 38]]);
            }));

            function drawNode(_x8) {
              return _ref2.apply(this, arguments);
            }

            return drawNode;
          }()
        }]);

        return Draw;
      }();

      module.exports = {
        Draw: Draw

        /***/ };
    }]
    /******/)
  );
});
});
define("miniprogram_npm/wxml-to-canvas/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var hex = function hex(color) {
  var result = null;

  if (/^#/.test(color) && (color.length === 7 || color.length === 9)) {
    return color;
    // eslint-disable-next-line no-cond-assign
  } else if ((result = /^(rgb|rgba)\((.+)\)/.exec(color)) !== null) {
    return '#' + result[2].split(',').map(function (part, index) {
      part = part.trim();
      part = index === 3 ? Math.floor(parseFloat(part) * 255) : parseInt(part, 10);
      part = part.toString(16);
      if (part.length === 1) {
        part = '0' + part;
      }
      return part;
    }).join('');
  } else {
    return '#00000000';
  }
};

var splitLineToCamelCase = function splitLineToCamelCase(str) {
  return str.split('-').map(function (part, index) {
    if (index === 0) {
      return part;
    }
    return part[0].toUpperCase() + part.slice(1);
  }).join('');
};

var compareVersion = function compareVersion(v1, v2) {
  v1 = v1.split('.');
  v2 = v2.split('.');
  var len = Math.max(v1.length, v2.length);
  while (v1.length < len) {
    v1.push('0');
  }
  while (v2.length < len) {
    v2.push('0');
  }
  for (var i = 0; i < len; i++) {
    var num1 = parseInt(v1[i], 10);
    var num2 = parseInt(v2[i], 10);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }

  return 0;
};

module.exports = {
  hex: hex,
  splitLineToCamelCase: splitLineToCamelCase,
  compareVersion: compareVersion
};
});
define("packageAPI/pages/action-sheet/action-sheet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '操作菜单',
      path: 'packageAPI/pages/action-sheet/action-sheet'
    };
  },
  actionSheetTap: function actionSheetTap() {
    wx.showActionSheet({
      itemList: ['item1', 'item2', 'item3', 'item4'],
      success: function success(e) {
        console.log(e.tapIndex);
      }
    });
  }
});
});
define("packageAPI/pages/add-contact/add-contact.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '新增联系人',
      path: 'packageAPI/pages/add-contact/add-contact'
    };
  },
  submit: function submit(e) {
    var formData = e.detail.value;
    wx.addPhoneContact(_extends({}, formData, {
      success: function success() {
        wx.showToast({
          title: '联系人创建成功'
        });
      },
      fail: function fail() {
        wx.showToast({
          title: '联系人创建失败'
        });
      }
    }));
  }
});
});
define("packageAPI/pages/animation/animation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '动画',
      path: 'package/API/pages/animation/animation',
      containerStyle1: ''

    };
  },

  data: {
    canIUse: true
  },
  onLoad: function onLoad() {
    var canIUse = this.animate !== undefined;
    if (!canIUse) {
      wx.showModal({
        title: '微信版本过低，暂不支持本功能'
      });
      this.setData({
        canIUse: canIUse
      });
    }
  },


  change: function change() {
    this.animate('#container1', [{ opacity: 1.0, rotate: 0, backgroundColor: '#FF0000' }, { opacity: 0.5, rotate: 45, backgroundColor: '#00FF00', offset: 0.9 }, { opacity: 0.0, rotate: 90, backgroundColor: '#FF0000' }], 5000, function () {
      this.clearAnimation('#container1', { opacity: true, rotate: true }, function () {
        console.log("清除了#container上的动画属性");
      });
    }.bind(this));
    this.animate('.block1', [{ scale: [1, 1], rotate: 0, ease: 'ease-out' }, { scale: [1.5, 1.5], rotate: 45, ease: 'ease-in', offset: 0.9 }, { scale: [2, 2], rotate: 90 }], 5000, function () {
      this.clearAnimation('.block1', { scale: true, rotate: true }, function () {
        console.log("清除了.block1上的动画属性");
      });
    }.bind(this));
  }
});
});
define("packageAPI/pages/audio/audio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'Audio',
      path: 'packageAPI/pages/audio/audio'
    };
  },
  onReady: function onReady(e) {
    // 使用 wx.createAudioContext 获取 audio 上下文 context
    this.audioCtx = wx.createAudioContext('myAudio');
    this.audioCtx.setSrc('https://dldir1.qq.com/music/release/upload/t_mm_file_publish/2339610.m4a');
    this.audioCtx.play();
  },

  data: {
    src: ''
  },
  audioPlay: function audioPlay() {
    this.audioCtx.play();
  },
  audioPause: function audioPause() {
    this.audioCtx.pause();
  },
  audio14: function audio14() {
    this.audioCtx.seek(14);
  },
  audioStart: function audioStart() {
    this.audioCtx.seek(0);
  }
});
});
define("packageAPI/pages/background-audio/background-audio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
var util = require('../../../util/util.js');

var backgroundAudioManager = wx.getBackgroundAudioManager();
var updateInterval = void 0;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '背景音乐',
      path: 'packageAPI/pages/background-audio/background-audio'
    };
  },
  onShow: function onShow() {
    if (!backgroundAudioManager.paused && backgroundAudioManager.paused !== undefined) {
      this._enableInterval();
      this.setData({
        playing: true
      });
    }
  },
  onLoad: function onLoad() {
    var _this = this;

    var that = this;
    // 监听播放事件
    backgroundAudioManager.onPlay(function () {
      // 刷新播放时间
      _this._enableInterval();
      _this.setData({
        pause: false
      });
    });

    // 监听暂停事件
    backgroundAudioManager.onPause(function () {
      clearInterval(updateInterval);
      that.setData({
        playing: false,
        pause: true
      });
    });

    backgroundAudioManager.onEnded(function () {
      clearInterval(updateInterval);
      that.setData({
        playing: false,
        playTime: 0,
        formatedPlayTime: util.formatTime(0)
      });
    });

    backgroundAudioManager.onStop(function () {
      clearInterval(updateInterval);
      that.setData({
        playing: false,
        playTime: 0,
        formatedPlayTime: util.formatTime(0)
      });
    });
  },


  data: {
    playing: false, // 播放状态
    pause: false,
    playTime: 0, // 播放时长
    formatedPlayTime: '00:00:00' // 格式化后的播放时长
  },

  play: function play() {
    backgroundAudioManager.title = '此时此刻';
    backgroundAudioManager.epname = '此时此刻';
    backgroundAudioManager.singer = '许巍';
    backgroundAudioManager.coverImgUrl = 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000';

    var that = this;
    if (that.data.pause) {
      backgroundAudioManager.play();
      this.setData({
        playing: true
      });
    } else {
      that.setData({
        playing: true
      }, function () {
        // 设置src后会自动播放
        backgroundAudioManager.src = 'https://dldir1.qq.com/music/release/upload/t_mm_file_publish/2339610.m4a';
      });
    }
  },
  seek: function seek(e) {
    backgroundAudioManager.seek(e.detail.value);
  },
  pause: function pause() {
    clearInterval(updateInterval);
    backgroundAudioManager.pause();
  },
  stop: function stop() {
    clearInterval(updateInterval);
    backgroundAudioManager.stop();
  },
  _enableInterval: function _enableInterval() {
    var that = this;
    function update() {
      console.log(backgroundAudioManager.currentTime);
      that.setData({
        playTime: backgroundAudioManager.currentTime + 1,
        formatedPlayTime: util.formatTime(backgroundAudioManager.currentTime + 1)
      });
    }
    updateInterval = setInterval(update, 1000);
  },
  onUnload: function onUnload() {
    clearInterval(updateInterval);
  }
});
});
define("packageAPI/pages/bluetooth/bluetooth.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function inArray(arr, key, val) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i;
    }
  }
  return -1;
}

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(new Uint8Array(buffer), function (bit) {
    return ('00' + bit.toString(16)).slice(-2);
  });
  return hexArr.join('');
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '蓝牙',
      path: 'packageAPI/pages/bluetooth/bluetooth'
    };
  },


  data: {
    devices: [],
    connected: false,
    chs: []
  },
  onUnload: function onUnload() {
    this.closeBluetoothAdapter();
  },
  openBluetoothAdapter: function openBluetoothAdapter() {
    var _this = this;

    wx.openBluetoothAdapter({
      success: function success(res) {
        console.log('openBluetoothAdapter success', res);
        _this.startBluetoothDevicesDiscovery();
      },
      fail: function fail(res) {
        if (res.errCode === 10001) {
          wx.showModal({
            title: '错误',
            content: '未找到蓝牙设备, 请打开蓝牙后重试。',
            showCancel: false
          });
          wx.onBluetoothAdapterStateChange(function (res) {

            if (res && res.available) {
              this.startBluetoothDevicesDiscovery();
            }
          });
        }
      }
    });
  },
  getBluetoothAdapterState: function getBluetoothAdapterState() {
    var _this2 = this;

    wx.getBluetoothAdapterState({
      success: function success(res) {
        console.log('getBluetoothAdapterState', res);
        if (res.discovering) {
          _this2.onBluetoothDeviceFound();
        } else if (res.available) {
          _this2.startBluetoothDevicesDiscovery();
        }
      }
    });
  },
  startBluetoothDevicesDiscovery: function startBluetoothDevicesDiscovery() {
    var _this3 = this;

    if (this._discoveryStarted) {
      return;
    }
    this._discoveryStarted = true;
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: function success(res) {
        console.log('startBluetoothDevicesDiscovery success', res);
        _this3.onBluetoothDeviceFound();
      }
    });
  },
  stopBluetoothDevicesDiscovery: function stopBluetoothDevicesDiscovery() {
    var _this4 = this;

    wx.stopBluetoothDevicesDiscovery({
      complete: function complete() {
        _this4._discoveryStarted = false;
      }
    });
  },
  onBluetoothDeviceFound: function onBluetoothDeviceFound() {
    var _this5 = this;

    wx.onBluetoothDeviceFound(function (res) {
      res.devices.forEach(function (device) {
        if (!device.name && !device.localName) {
          return;
        }
        var foundDevices = _this5.data.devices;
        var idx = inArray(foundDevices, 'deviceId', device.deviceId);
        var data = {};
        if (idx === -1) {
          data['devices[' + foundDevices.length + ']'] = device;
        } else {
          data['devices[' + idx + ']'] = device;
        }
        _this5.setData(data);
      });
    });
  },
  createBLEConnection: function createBLEConnection(e) {
    var _this6 = this;

    var ds = e.currentTarget.dataset;
    var deviceId = ds.deviceId;
    var name = ds.name;
    wx.showLoading();
    wx.createBLEConnection({
      deviceId: deviceId,
      success: function success() {
        _this6.setData({
          connected: true,
          name: name,
          deviceId: deviceId
        });
        _this6.getBLEDeviceServices(deviceId);
      },
      complete: function complete() {
        wx.hideLoading();
      }
    });
    this.stopBluetoothDevicesDiscovery();
  },
  closeBLEConnection: function closeBLEConnection() {
    wx.closeBLEConnection({
      deviceId: this.data.deviceId
    });
    this.setData({
      connected: false,
      chs: [],
      canWrite: false
    });
  },
  changeMode: function changeMode() {
    wx.navigateTo({
      url: './slave/slave'
    });
  },
  getBLEDeviceServices: function getBLEDeviceServices(deviceId) {
    var _this7 = this;

    wx.getBLEDeviceServices({
      deviceId: deviceId,
      success: function success(res) {
        for (var i = 0; i < res.services.length; i++) {
          if (res.services[i].isPrimary) {
            _this7.getBLEDeviceCharacteristics(deviceId, res.services[i].uuid);
            return;
          }
        }
      }
    });
  },
  getBLEDeviceCharacteristics: function getBLEDeviceCharacteristics(deviceId, serviceId) {
    var _this8 = this;

    wx.getBLEDeviceCharacteristics({
      deviceId: deviceId,
      serviceId: serviceId,
      success: function success(res) {
        console.log('getBLEDeviceCharacteristics success', res.characteristics);

        for (var i = 0; i < res.characteristics.length; i++) {
          var item = res.characteristics[i];
          if (item.properties.read) {
            wx.readBLECharacteristicValue({
              deviceId: deviceId,
              serviceId: serviceId,
              characteristicId: item.uuid
            });
          }
          if (item.properties.write) {
            _this8.setData({
              canWrite: true
            });
            _this8._deviceId = deviceId;
            _this8._serviceId = serviceId;
            _this8._characteristicId = item.uuid;
            console.log('write');
            _this8.writeBLECharacteristicValue();
          }
          if (item.properties.notify || item.properties.indicate) {
            wx.notifyBLECharacteristicValueChange({
              deviceId: deviceId,
              serviceId: serviceId,
              characteristicId: item.uuid,
              state: true
            });
          }
        }
      },
      fail: function fail(res) {
        console.error('getBLEDeviceCharacteristics', res);
      }
    });
    // 操作之前先监听，保证第一时间获取数据
    wx.onBLECharacteristicValueChange(function (characteristic) {
      var idx = inArray(_this8.data.chs, 'uuid', characteristic.characteristicId);
      var data = {};
      if (idx === -1) {
        data['chs[' + _this8.data.chs.length + ']'] = {
          uuid: characteristic.characteristicId,
          value: ab2hex(characteristic.value)
        };
      } else {
        data['chs[' + idx + ']'] = {
          uuid: characteristic.characteristicId,
          value: ab2hex(characteristic.value)
        };
      }
      wx.showToast({
        title: '收到从机数据'
      });
      // data[`chs[${this.data.chs.length}]`] = {
      //   uuid: characteristic.characteristicId,
      //   value: ab2hex(characteristic.value)
      // }
      _this8.setData(data);
    });
  },
  writeBLECharacteristicValue: function writeBLECharacteristicValue() {
    // 向蓝牙设备发送一个0x00的16进制数据
    var buffer = new ArrayBuffer(1);
    var dataView = new DataView(buffer);
    // eslint-disable-next-line
    dataView.setUint8(0, Math.random() * 19 | 0);
    wx.writeBLECharacteristicValue({
      deviceId: this._deviceId,
      serviceId: this._serviceId,
      characteristicId: this._characteristicId,
      value: buffer,
      success: function success() {
        console.log('writeBLECharacteristicValue: 成功');
      },
      fail: function fail() {
        console.log('writeBLECharacteristicValue: 失败');
      },
      complete: function complete() {
        console.log('writeBLECharacteristicValue: 结束');
      }
    });
  },
  closeBluetoothAdapter: function closeBluetoothAdapter() {
    wx.closeBluetoothAdapter();
    this._discoveryStarted = false;
  }
});
});
define("packageAPI/pages/bluetooth/slave/slave.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var uuid3 = '0C76801A-62EB-45E5-96A8-37C8882ABB2B';
var serviceId = 'D0611E78-BBB4-4591-A5F8-487910AE4366';
var characteristicId = '8667556C-9A37-4C91-84ED-54EE27D90049';
// 上面需要配置主机的 serviceId 和 characteristicId


// ArrayBuffer转16进制字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(new Uint8Array(buffer), function (bit) {
    return ('00' + bit.toString(16)).slice(-2);
  });
  return hexArr.join('');
}

function inArray(arr, key, val) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i;
    }
  }
  return -1;
}

// slave/slave.js
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '蓝牙',
      path: 'packageAPI/pages/slave/slave'
    };
  },

  data: {
    connects: [],
    servers: []
  },

  onLoad: function onLoad(options) {
    var _this = this;

    wx.onBLEPeripheralConnectionStateChanged(function (res) {
      console.log('connect');
      var connects = _this.data.connects;
      var idx = inArray(connects, 'deviceId', res.deviceId);
      if (idx >= 0) {
        connects[idx] = res;
      } else {
        connects.push(res);
      }
      _this.setData({ connects: connects });
    });
  },

  openBluetoothAdapter: function openBluetoothAdapter() {
    var _this2 = this;

    // 初始化蓝牙模块
    wx.openBluetoothAdapter({
      mode: 'peripheral',
      success: function success(res) {
        console.log('openBluetoothAdapter success', res);
        _this2.createBLEPeripheralServer();
      },
      fail: function fail(res) {
        console.log(res);
        wx.showToast({
          title: '\u521B\u5EFA\u5931\u8D25 \u9519\u8BEF\u7801: ' + res.errCode,
          icon: 'none'
        });
        if (res.errCode === 10001) {
          wx.onBluetoothAdapterStateChange(function (res) {
            console.log('onBluetoothAdapterStateChange', res);
            if (res.available) {
              this.createBLEPeripheralServer();
            }
          });
        }
      }
    });
  },
  createBLEPeripheralServer: function createBLEPeripheralServer() {
    var _this3 = this;

    //
    wx.createBLEPeripheralServer().then(function (res) {
      console.log('createBLEPeripheralServer', res);
      _this3.data.servers.push(res.server);
      _this3.server = res.server;
      _this3.setData({
        serverId: _this3.server.serverId
      });
      wx.showToast({
        title: '创建 server '
      });
      _this3.server.onCharacteristicReadRequest(function (res) {
        var serviceId = res.serviceId,
            characteristicId = res.characteristicId,
            callbackId = res.callbackId;

        var buffer = new ArrayBuffer(1);
        var dataView = new DataView(buffer);
        var newValue = Math.ceil(Math.random() * 10);
        dataView.setUint8(0, newValue);
        console.log('onCharacteristicReadRequest', res, newValue);
        _this3.server.writeCharacteristicValue({
          serviceId: serviceId,
          characteristicId: characteristicId,
          value: buffer,
          needNotify: true,
          callbackId: callbackId
        });
      });
      // 监听收到数据
      _this3.server.onCharacteristicWriteRequest(function (res) {
        console.log('onCharacteristicWriteRequest', res);
        var serviceId = res.serviceId,
            characteristicId = res.characteristicId,
            value = res.value,
            callbackId = res.callbackId;

        wx.showToast({
          title: '收到主机数据'
        });
        _this3.server.writeCharacteristicValue({
          serviceId: serviceId,
          characteristicId: characteristicId,
          value: value,
          needNotify: true,
          callbackId: callbackId
        });
      });
    });
  },
  closeServer: function closeServer() {
    this.server.close();
    wx.showToast({
      title: '关闭 server'
    });
  },
  chaneMode: function chaneMode() {
    wx.navigateBack();
  },
  onConfirm: function onConfirm(e) {
    console.log('onConfirm');
    var n = e.detail.value * 1;
    var buffer = new ArrayBuffer(1);
    var dataView = new DataView(buffer);
    dataView.setUint8(0, n);
    this.server.writeCharacteristicValue({
      serviceId: serviceId,
      characteristicId: characteristicId,
      value: buffer,
      needNotify: true
    });
    wx.showModal({
      title: '写入成功',
      content: '请在主机查看'
    });
  },
  showInput: function showInput() {
    this.setData({
      input: !this.data.input
    });
  },
  addService: function addService() {
    var buffer = new ArrayBuffer(1);
    var dataView = new DataView(buffer);
    dataView.setUint8(0, 2);
    var descriptorBuffer = new ArrayBuffer(1);
    var dataView2 = new DataView(descriptorBuffer);
    dataView2.setInt8(0, 3);
    var service = {
      uuid: serviceId,
      characteristics: [{
        uuid: characteristicId,
        properties: {
          write: true,
          read: true,
          notify: true,
          indicate: true
        },
        permission: {
          readable: true,
          writeable: true,
          readEncryptionRequired: true,
          writeEncryptionRequired: true
        },
        value: buffer,
        descriptors: [{
          uuid: uuid3,
          permission: {
            write: true,
            read: true
          },
          value: descriptorBuffer
        }]
      }]
    };

    this.server.addService({
      service: service
    }).then(function (res) {
      console.log('add Service', res);
      wx.showToast({
        title: '创建服务'
      });
    }, function (rej) {
      console.log(rej);
      if (rej.errCode === 10001) {
        wx.showToast({
          title: '请打开蓝牙'
        });
      } else {
        wx.showModal({
          title: '创建失败',
          content: '\u9519\u8BEF\u7801: ' + rej.errCode
        });
      }
    });
  },
  removeService: function removeService() {
    this.server.removeService({
      serviceId: serviceId
    }).then(function (res) {
      wx.showToast({
        title: '关闭服务'
      });
      console.log('removeService', res);
    });
  },
  startAdvertising: function startAdvertising() {
    var buffer = new ArrayBuffer(1);
    var dataView = new DataView(buffer);
    dataView.setInt8(0, 4);
    this.server.startAdvertising({
      advertiseRequest: {
        connectable: true,
        deviceName: 'sanford',
        serviceUuids: [serviceId],
        manufacturerData: [{
          manufacturerId: 'sanfordsun-pc0',
          manufacturerSpecificData: buffer
        }]
      },
      powerLevel: 'medium'
    }).then(function (res) {
      console.log('startAdvertising', res);
      wx.showToast({
        title: '开启广播'
      });
    });
  },
  stopAdvertising: function stopAdvertising() {
    this.server.stopAdvertising();
    wx.showToast({
      title: '关闭广播'
    });
  },
  closeBluetoothAdapter: function closeBluetoothAdapter() {
    wx.showToast({
      title: '结束流程'
    });
    wx.closeBluetoothAdapter();
  },


  onUnload: function onUnload() {
    this.data.servers.forEach(function (server) {
      // server.close()
    });
  }
});
});
define("packageAPI/pages/canvas/canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var example = require('./example.js');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '创建画布',
      path: 'packageAPI/pages/canvas/canvas'
    };
  },
  onLoad: function onLoad() {
    this.context = wx.createContext();

    var methods = Object.keys(example);
    this.setData({
      methods: methods
    });

    var that = this;
    methods.forEach(function (method) {
      that[method] = function () {
        example[method](that.context);
        var actions = that.context.getActions();

        wx.drawCanvas({
          canvasId: 'canvas',
          actions: actions
        });
      };
    });
  },
  toTempFilePath: function toTempFilePath() {
    wx.canvasToTempFilePath({
      canvasId: 'canvas',
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(res) {
        console.log(res);
      }
    });
  }
});
});
define("packageAPI/pages/canvas/example.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var example = {};

example.rotate = function (context) {
  context.beginPath();
  context.rotate(10 * Math.PI / 180);
  context.rect(225, 75, 20, 10);
  context.fill();
};

example.scale = function (context) {
  context.beginPath();
  context.rect(25, 25, 50, 50);
  context.stroke();

  context.scale(2, 2);

  context.beginPath();
  context.rect(25, 25, 50, 50);
  context.stroke();
};

example.reset = function (context) {
  context.beginPath();

  context.setFillStyle('#000000');
  context.setStrokeStyle('#000000');
  context.setFontSize(10);

  context.setShadow(0, 0, 0, 'rgba(0, 0, 0, 0)');

  context.setLineCap('butt');
  context.setLineJoin('miter');
  context.setLineWidth(1);
  context.setMiterLimit(10);
};

example.translate = function (context) {
  context.beginPath();
  context.rect(10, 10, 100, 50);
  context.fill();

  context.translate(70, 70);

  context.beginPath();
  context.fill();
};

example.save = function (context) {
  context.beginPath();
  context.setStrokeStyle('#00ff00');
  context.save();

  context.scale(2, 2);
  context.setStrokeStyle('#ff0000');
  context.rect(0, 0, 100, 100);
  context.stroke();
  context.restore();

  context.rect(0, 0, 50, 50);
  context.stroke();
};

example.restore = function (context) {
  [3, 2, 1].forEach(function (item) {
    context.beginPath();
    context.save();
    context.scale(item, item);
    context.rect(10, 10, 100, 100);
    context.stroke();
    context.restore();
  });
};

example.drawImage = function (context) {
  context.drawImage('/image/wechat.png', 0, 0);
};

example.fillText = function (context) {
  context.setStrokeStyle('#ff0000');

  context.beginPath();
  context.moveTo(0, 10);
  context.lineTo(300, 10);
  context.stroke();

  // context.save()
  // context.scale(1.5, 1.5)
  // context.translate(20, 20)
  context.setFontSize(10);
  context.fillText('Hello World', 0, 30);
  context.setFontSize(20);
  context.fillText('Hello World', 100, 30);

  // context.restore()

  context.beginPath();
  context.moveTo(0, 30);
  context.lineTo(300, 30);
  context.stroke();
};

example.fill = function (context) {
  context.beginPath();
  context.rect(20, 20, 150, 100);
  context.setStrokeStyle('#00ff00');
  context.fill();
};

example.stroke = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.lineTo(20, 100);
  context.lineTo(70, 100);
  context.setStrokeStyle('#00ff00');
  context.stroke();
};

example.clearRect = function (context) {
  context.setFillStyle('#ff0000');
  context.beginPath();
  context.rect(0, 0, 300, 150);
  context.fill();
  context.clearRect(20, 20, 100, 50);
};

example.beginPath = function (context) {
  context.beginPath();
  context.setLineWidth(5);
  context.setStrokeStyle('#ff0000');
  context.moveTo(0, 75);
  context.lineTo(250, 75);
  context.stroke();

  context.beginPath();
  context.setStrokeStyle('#0000ff');
  context.moveTo(50, 0);
  context.lineTo(150, 130);
  context.stroke();
};

example.closePath = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.lineTo(20, 100);
  context.lineTo(70, 100);
  context.closePath();
  context.stroke();
};

example.moveTo = function (context) {
  context.beginPath();
  context.moveTo(0, 0);
  context.lineTo(300, 150);
  context.stroke();
};

example.lineTo = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.lineTo(20, 100);
  context.lineTo(70, 100);
  context.stroke();
};

example.rect = function (context) {
  context.beginPath();
  context.rect(20, 20, 150, 100);
  context.stroke();
};

example.arc = function (context) {
  context.beginPath();
  context.arc(75, 75, 50, 0, Math.PI * 2, true);
  context.moveTo(110, 75);
  context.arc(75, 75, 35, 0, Math.PI, false);
  context.moveTo(65, 65);
  context.arc(60, 65, 5, 0, Math.PI * 2, true);
  context.moveTo(95, 65);
  context.arc(90, 65, 5, 0, Math.PI * 2, true);
  context.stroke();
};

example.quadraticCurveTo = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.quadraticCurveTo(20, 100, 200, 20);
  context.stroke();
};

example.bezierCurveTo = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.bezierCurveTo(20, 100, 200, 100, 200, 20);
  context.stroke();
};

example.setFillStyle = function (context) {
  ['#fef957', 'rgb(242,159,63)', 'rgb(242,117,63)', '#e87e51'].forEach(function (item, index) {
    context.setFillStyle(item);
    context.beginPath();
    context.rect(0 + 75 * index, 0, 50, 50);
    context.fill();
  });
};

example.setStrokeStyle = function (context) {
  ['#fef957', 'rgb(242,159,63)', 'rgb(242,117,63)', '#e87e51'].forEach(function (item, index) {
    context.setStrokeStyle(item);
    context.beginPath();
    context.rect(0 + 75 * index, 0, 50, 50);
    context.stroke();
  });
};

example.setGlobalAlpha = function (context) {
  context.setFillStyle('#000000');
  [1, 0.5, 0.1].forEach(function (item, index) {
    context.setGlobalAlpha(item);
    context.beginPath();
    context.rect(0 + 75 * index, 0, 50, 50);
    context.fill();
  });
};

example.setShadow = function (context) {
  context.beginPath();
  context.setShadow(10, 10, 10, 'rgba(0, 0, 0, 199)');
  context.rect(10, 10, 100, 100);
  context.fill();
};

example.setFontSize = function (context) {
  [10, 20, 30, 40].forEach(function (item, index) {
    context.setFontSize(item);
    context.fillText('Hello, world', 20, 20 + 40 * index);
  });
};

example.setLineCap = function (context) {
  context.setLineWidth(10);
  ['butt', 'round', 'square'].forEach(function (item, index) {
    context.beginPath();
    context.setLineCap(item);
    context.moveTo(20, 20 + 20 * index);
    context.lineTo(100, 20 + 20 * index);
    context.stroke();
  });
};

example.setLineJoin = function (context) {
  context.setLineWidth(10);
  ['bevel', 'round', 'miter'].forEach(function (item, index) {
    context.beginPath();

    context.setLineJoin(item);
    context.moveTo(20 + 80 * index, 20);
    context.lineTo(100 + 80 * index, 50);
    context.lineTo(20 + 80 * index, 100);
    context.stroke();
  });
};

example.setLineWidth = function (context) {
  [2, 4, 6, 8, 10].forEach(function (item, index) {
    context.beginPath();
    context.setLineWidth(item);
    context.moveTo(20, 20 + 20 * index);
    context.lineTo(100, 20 + 20 * index);
    context.stroke();
  });
};

example.setMiterLimit = function (context) {
  context.setLineWidth(4);

  [2, 4, 6, 8, 10].forEach(function (item, index) {
    context.beginPath();
    context.setMiterLimit(item);
    context.moveTo(20 + 80 * index, 20);
    context.lineTo(100 + 80 * index, 50);
    context.lineTo(20 + 80 * index, 100);
    context.stroke();
  });
};

module.exports = example;
});
define("packageAPI/pages/capture-screen/capture-screen.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '用户截屏事件',
      path: 'packageAPI/pages/capture-screen/capture-screen'
    };
  },


  data: {
    captured: false
  },
  onLoad: function onLoad() {
    var _this = this;

    wx.onUserCaptureScreen(function () {
      _this.setData({
        captured: true
      });
    });
  }
});
});
define("packageAPI/pages/choose-address/choose-address.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '收货地址',
      path: 'packageAPI/pages/choose-address/choose-address'
    };
  },


  data: {
    addressInfo: null
  },
  chooseAddress: function chooseAddress() {
    var _this = this;

    wx.chooseAddress({
      success: function success(res) {
        _this.setData({
          addressInfo: res
        });
      },
      fail: function fail(err) {
        console.log(err);
      }
    });
  }
});
});
define("packageAPI/pages/choose-invoice-title/choose-invoice-title.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取发票抬头',
      path: 'packageAPI/pages/choose-invoice-title/choose-invoice-title'
    };
  },


  data: {
    type: '',
    title: '',
    taxNumber: '',
    companyAddress: '',
    telephone: '',
    bankName: '',
    bankAccount: ''
  },
  chooseInvoiceTitle: function chooseInvoiceTitle() {
    var _this = this;

    wx.chooseInvoiceTitle({
      success: function success(res) {
        _this.setData({
          type: res.type,
          title: res.title,
          taxNumber: res.taxNumber,
          companyAddress: res.companyAddress,
          telephone: res.telephone,
          bankName: res.bankName,
          bankAccount: res.bankAccount
        });
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  }
});
});
define("packageAPI/pages/choose-location/choose-location.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../util/util.js');

var formatLocation = util.formatLocation;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '使用原生地图选择位置',
      path: 'packageAPI/pages/choose-location/choose-location'
    };
  },


  data: {
    hasLocation: false
  },
  chooseLocation: function chooseLocation() {
    var that = this;
    wx.chooseLocation({
      success: function success(res) {
        console.log(res);
        that.setData({
          hasLocation: true,
          location: formatLocation(res.longitude, res.latitude),
          locationAddress: res.address
        });
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasLocation: false
    });
  }
});
});
define("packageAPI/pages/clipboard-data/clipboard-data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '剪切板',
      path: 'packageAPI/pages/clipboard-data/clipboard-data'
    };
  },


  data: {
    value: 'edit and copy me',
    pasted: ''
  },

  valueChanged: function valueChanged(e) {
    this.setData({
      value: e.detail.value
    });
  },
  copy: function copy() {
    wx.setClipboardData({
      data: this.data.value,
      success: function success() {
        wx.showToast({
          title: '复制成功',
          icon: 'success',
          duration: 1000
        });
      }
    });
  },
  paste: function paste() {
    var self = this;
    wx.getClipboardData({
      success: function success(res) {
        self.setData({
          pasted: res.data
        });
        wx.showToast({
          title: '粘贴成功',
          icon: 'success',
          duration: 1000
        });
      }
    });
  }
});
});
define("packageAPI/pages/custom-message/custom-message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '客服消息',
      path: 'packageAPI/pages/custom-message/custom-message'
    };
  }
});
});
define("packageAPI/pages/custom-service/custom-service.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '联系客服',
      path: 'packageAPI/pages/custom-service/custom-service'
    };
  }
});
});
define("packageAPI/pages/doc-web-view/doc-web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序接口文档',
      path: 'packageAPI/pages/doc-web-view/doc-web-view'
    };
  }
});
});
define("packageAPI/pages/download-file/download-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var demoImageFileId = require('../../../config').demoImageFileId;
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '下载文件',
      path: 'packageAPI/pages/download-file/download-file'
    };
  },
  downloadImage: function downloadImage() {
    var self = this;

    wx.cloud.downloadFile({
      fileID: demoImageFileId, // 文件 ID
      success: function success(res) {
        console.log('downloadFile success, res is', res);

        self.setData({
          imageSrc: res.tempFilePath
        });
      },
      fail: console.error
    });
  }
});
});
define("packageAPI/pages/file/file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '文件',
      path: 'packageAPI/pages/file/file'
    };
  },
  onLoad: function onLoad() {
    this.setData({
      savedFilePath: wx.getStorageSync('savedFilePath')
    });
  },

  data: {
    tempFilePath: '',
    savedFilePath: '',
    dialog: {
      hidden: true
    }
  },
  chooseImage: function chooseImage() {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function success(res) {
        that.setData({
          tempFilePath: res.tempFilePaths[0]
        });
      }
    });
  },
  saveFile: function saveFile() {
    if (this.data.tempFilePath.length > 0) {
      var that = this;
      wx.saveFile({
        tempFilePath: this.data.tempFilePath,
        success: function success(res) {
          that.setData({
            savedFilePath: res.savedFilePath
          });
          wx.setStorageSync('savedFilePath', res.savedFilePath);
          that.setData({
            dialog: {
              title: '保存成功',
              content: '下次进入应用时，此文件仍可用',
              hidden: false
            }
          });
        },
        fail: function fail() {
          that.setData({
            dialog: {
              title: '保存失败',
              content: '应该是有 bug 吧',
              hidden: false
            }
          });
        }
      });
    }
  },
  clear: function clear() {
    wx.setStorageSync('savedFilePath', '');
    this.setData({
      tempFilePath: '',
      savedFilePath: ''
    });
  },
  confirm: function confirm() {
    this.setData({
      'dialog.hidden': true
    });
  }
});
});
define("packageAPI/pages/get-background-fetch-data/get-background-fetch-data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 使用周期性数据的时候，需要先调用setBackgroundFetchToken, 可在 app.js 中查看具体例子
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '周期性缓存',
      path: 'packageAPI/pages/get-background-fetch-data/get-background-fetch-data'
    };
  },
  onShow: function onShow() {
    // 获取缓存的周期性更新数据
    this.getBackgroundFetchData();
  },

  data: {
    openid: '',
    appid: '',
    canIUse: true
  },
  getBackgroundFetchData: function getBackgroundFetchData() {
    console.log('读取周期性更新数据');
    var that = this;
    if (wx.getBackgroundFetchData) {
      wx.getBackgroundFetchData({
        // 当type = 'periodic' 微信客户端会每隔 12 小时向服务器请求一次数据。
        fetchType: 'periodic',
        success: function success(res) {
          console.log(res);
          var fetchedData = res.fetchedData;

          var result = JSON.parse(fetchedData);
          that.setData({
            appid: result.appid,
            openid: result.openid
          });
          console.log('读取周期性更新数据成功');
        },
        fail: function fail() {
          console.log('读取周期性更新数据失败');
          wx.showToast({
            title: '无缓存数据',
            icon: 'none'
          });
        },
        complete: function complete() {
          console.log('结束读取');
        }
      });
    } else {
      this.setData({
        canIUse: false
      });
      wx.showModal({
        title: '微信版本过低，暂不支持本功能'
      });
    }
  }
});
});
define("packageAPI/pages/get-background-prefetch-data/get-background-prefetch-data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();
// 使用预缓存数据的时候，需要先调用setBackgroundFetchToken, 可在 app.js 中查看具体例子

Date.prototype.Format = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };

  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    }
  }

  return fmt;
};

Page({
  onShow: function onShow() {
    // 获取缓存的预拉取数据
    this.getBackgroundFetchData();
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '预拉取',
      path: 'packageAPI/pages/get-background-prefetch-data/get-background-prefetch-data'
    };
  },

  data: {
    openid: '',
    appid: '',
    getDataTime: '',
    canIUse: true
  },
  getBackgroundFetchData: function getBackgroundFetchData() {
    if (wx.getBackgroundFetchData) {
      console.log('读取预拉取数据');
      var res = app.globalData.backgroundFetchData;
      var fetchedData = res.fetchedData;

      var result = JSON.parse(fetchedData);
      var systemInfo = wx.getSystemInfoSync();
      var timeStamp = systemInfo.brand === 'iPhone' ? res.timeStamp * 1000 : res.timeStamp;
      var time = new Date(timeStamp).Format("yyyy-MM-dd hh:mm:ss");
      this.setData({
        appid: result.appid,
        openid: result.openid,
        getDataTime: time

      });
    } else {
      this.setData({
        canIUse: false
      });
      wx.showModal({
        title: '微信版本过低，暂不支持本功能'
      });
    }
  }
});
});
define("packageAPI/pages/get-battery-info/get-battery-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/page/API/pages/get-battery-info/get-battery-info.js
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取电池信息',
      path: 'packageAPI/pages/get-battery-info/get-battery-info'
    };
  },

  data: {},

  getBatteryInfo: function getBatteryInfo() {
    var _this = this;

    wx.getBatteryInfo({
      complete: function complete(res) {
        var msg = res.isCharging ? '充电中' : '使用电池中';
        _this.setData({
          level: res.level,
          isCharging: msg
        });
      }
    });
  }
});
});
define("packageAPI/pages/get-location/get-location.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../util/util.js');

var formatLocation = util.formatLocation;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取位置',
      path: 'packageAPI/pages/get-location/get-location'
    };
  },


  data: {
    hasLocation: false
  },
  getLocation: function getLocation() {
    var that = this;
    wx.getLocation({
      success: function success(res) {
        console.log(res);
        that.setData({
          hasLocation: true,
          location: formatLocation(res.longitude, res.latitude)
        });
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasLocation: false
    });
  }
});
});
define("packageAPI/pages/get-network-type/get-network-type.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取手机网络状态',
      path: 'packageAPI/pages/get-network-type/get-network-type'
    };
  },


  data: {
    hasNetworkType: false
  },
  getNetworkType: function getNetworkType() {
    var that = this;
    wx.getNetworkType({
      success: function success(res) {
        console.log(res);
        that.setData({
          hasNetworkType: true,
          networkType: res.subtype || res.networkType
        });
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasNetworkType: false,
      networkType: ''
    });
  }
});
});
define("packageAPI/pages/get-performance/get-performance.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/page/API/pages/get-performance/get-performance.js

var util = require('./util');
var performance = wx.getPerformance ? wx.getPerformance() : {};
var performanceObserver = performance.createObserver ? performance.createObserver() : null;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '周期性缓存',
      path: 'packageAPI/pages/get-performance/get-performance'
    };
  },

  data: {
    array: [],
    support: false
  },
  onLoad: function onLoad() {
    console.log('canIUse:getPerformance:', wx.canIUse('getPerformance'));
    var canIUse = false;
    if (wx.getPerformance) {
      canIUse = true;
    }
    this.setData({
      support: canIUse
    });
  },
  getPerformanceInfo: function getPerformanceInfo() {
    var EntryList = performance.getEntries();
    var array = [];
    EntryList.forEach(function (item) {
      array.push({
        entryType: util.renderEntryType(item.entryType),
        name: util.renderName(item.name),
        duration: util.renderDuration(item.duration),
        startTime: util.renderStartTime(item.startTime)
      });
    });
    this.setData({
      array: array
    });
  },
  startObserver: function startObserver() {
    // 监听需要的性能指标
    performanceObserver.observe({ entryTypes: ['render', 'script', 'navigation'] });
  },
  stopObserver: function stopObserver() {
    // 结束监听
    performanceObserver.disconnect();
  }
});
});
define("packageAPI/pages/get-performance/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var util = {};

// const { formatDateTime } = require('../../../../util/util')
Date.prototype.Format = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };

  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    }
  }

  return fmt;
};

util.renderName = function (name) {
  switch (name) {
    case 'appLaunch':
      return '小程序启动';
      break;
    case 'firstRender':
      return '页面首次渲染';
      break;
    case 'route':
      return '路由性能';
      break;
    case 'evaluateScript':
      return '注入脚本';
      break;
  }
};

util.renderEntryType = function (entryType) {
  switch (entryType) {
    case 'navigation':
      return '路由';
      break;
    case 'render':
      return '渲染';
      break;
    case 'script':
      return '脚本';
      break;
  }
};

util.renderDuration = function (duration) {
  return duration ? duration + 'ms' : '';
};

util.renderStartTime = function (startTime) {
  if (!startTime) return '';

  var date = new Date(startTime);
  return date.Format("yyyy-MM-dd hh:mm:ss");
};

module.exports = util;
});
define("packageAPI/pages/get-system-info/get-system-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取手机系统信息',
      path: 'packageAPI/pages/get-system-info/get-system-info'
    };
  },


  data: {
    systemInfo: {}
  },
  getSystemInfo: function getSystemInfo() {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          systemInfo: res
        });
      }
    });
  }
});
});
define("packageAPI/pages/get-user-info/get-user-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取用户信息',
      path: 'packageAPI/pages/get-user-info/get-user-info'
    };
  },


  data: {
    hasUserInfo: false
  },
  getUserInfo: function getUserInfo(info) {
    var userInfo = info.detail.userInfo;
    this.setData({
      userInfo: userInfo,
      hasUserInfo: true
    });
  },
  clear: function clear() {
    this.setData({
      hasUserInfo: false,
      userInfo: {}
    });
  }
});
});
define("packageAPI/pages/get-wxml-node-info/get-wxml-node-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取WXML节点信息',
      path: 'packageAPI/pages/get-wxml-node-info/get-wxml-node-info'
    };
  },


  data: {
    metrics: []
  },

  onReady: function onReady() {
    this.getNodeInfo();
  },
  getNodeInfo: function getNodeInfo() {
    var _this = this;

    var $ = wx.createSelectorQuery();
    var target = $.select('.target');
    target.boundingClientRect();

    $.exec(function (res) {
      var rect = res[0];
      if (rect) {
        var metrics = [];
        // eslint-disable-next-line
        for (var key in rect) {
          if (key !== 'id' && key !== 'dataset') {
            var val = rect[key];
            metrics.push({ key: key, val: val });
          }
        }

        _this.setData({ metrics: metrics });
      }
    });
  }
});
});
define("packageAPI/pages/ibeacon/ibeacon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'iBeacon',
      path: 'packageAPI/pages/ibeacon/ibeacon'
    };
  },


  data: {
    uuid: '',
    beacons: []
  },

  onUnload: function onUnload() {
    this.stopSearch();
  },
  enterUuid: function enterUuid(e) {
    this.setData({
      uuid: e.detail.value
    });
  },
  startSearch: function startSearch() {
    var _this = this;

    if (this._searching) return;
    this._searching = true;
    wx.startBeaconDiscovery({
      uuids: [this.data.uuid],
      success: function success(res) {
        console.log(res);
        wx.onBeaconUpdate(function (_ref) {
          var beacons = _ref.beacons;

          _this.setData({
            beacons: beacons
          });
        });
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  },
  stopSearch: function stopSearch() {
    this._searching = false;
    wx.stopBeaconDiscovery();
  }
});
});
define("packageAPI/pages/image/image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var sourceType = [['camera'], ['album'], ['camera', 'album']];
var sizeType = [['compressed'], ['original'], ['compressed', 'original']];

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '图片',
      path: 'packageAPI/pages/image/image'
    };
  },


  data: {
    imageList: [],
    sourceTypeIndex: 2,
    sourceType: ['拍照', '相册', '拍照或相册'],

    sizeTypeIndex: 2,
    sizeType: ['压缩', '原图', '压缩或原图'],

    countIndex: 8,
    count: [1, 2, 3, 4, 5, 6, 7, 8, 9]
  },
  sourceTypeChange: function sourceTypeChange(e) {
    this.setData({
      sourceTypeIndex: e.detail.value
    });
  },
  sizeTypeChange: function sizeTypeChange(e) {
    this.setData({
      sizeTypeIndex: e.detail.value
    });
  },
  countChange: function countChange(e) {
    this.setData({
      countIndex: e.detail.value
    });
  },
  chooseImage: function chooseImage() {
    var that = this;
    wx.chooseImage({
      sourceType: sourceType[this.data.sourceTypeIndex],
      sizeType: sizeType[this.data.sizeTypeIndex],
      count: this.data.count[this.data.countIndex],
      success: function success(res) {
        console.log(res);
        that.setData({
          imageList: res.tempFilePaths
        });
      }
    });
  },
  previewImage: function previewImage(e) {
    var current = e.target.dataset.src;

    wx.previewImage({
      current: current,
      urls: this.data.imageList
    });
  }
});
});
define("packageAPI/pages/intersection-observer/intersection-observer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'WXML节点布局相交状态',
      path: 'packageAPI/pages/intersection-observer/intersection-observer'
    };
  },


  data: {
    appear: false
  },
  onLoad: function onLoad() {
    var _this = this;

    this._observer = wx.createIntersectionObserver(this);
    this._observer.relativeTo('.scroll-view').observe('.ball', function (res) {
      console.log(res);
      _this.setData({
        appear: res.intersectionRatio > 0
      });
    });
  },
  onUnload: function onUnload() {
    if (this._observer) this._observer.disconnect();
  }
});
});
define("packageAPI/pages/load-font-face/load-font-face.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '动态加载字体',
      path: 'packageAPI/pages/load-font-face/load-font-face'
    };
  },


  data: {
    fontFamily: 'Bitstream Vera Serif Bold',
    loaded: false
  },

  onLoad: function onLoad() {
    this.setData({
      loaded: false
    });
  },
  loadFontFace: function loadFontFace() {
    var self = this;
    wx.loadFontFace({
      family: this.data.fontFamily,
      source: 'url("https://sungd.github.io/Pacifico.ttf")',
      success: function success(res) {
        console.log(res.status);
        self.setData({ loaded: true });
      },
      fail: function fail(res) {
        console.log(res.status);
      },
      complete: function complete(res) {
        console.log(res.status);
      }
    });
  },
  clear: function clear() {
    this.setData({ loaded: false });
  }
});
});
define("packageAPI/pages/login/login.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '微信登录',
      path: 'package/API/pages/login/login'
    };
  },
  onLoad: function onLoad() {
    this.setData({
      hasLogin: app.globalData.hasLogin
    });
  },

  data: {},
  login: function login() {
    var that = this;
    wx.login({
      success: function success() {
        app.globalData.hasLogin = true;
        that.setData({
          hasLogin: true
        });
      }
    });
  }
});
});
define("packageAPI/pages/make-phone-call/make-phone-call.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '打电话',
      path: 'packageAPI/pages/make-phone-call/make-phone-call'
    };
  },


  data: {
    disabled: true
  },
  bindInput: function bindInput(e) {
    this.inputValue = e.detail.value;

    if (this.inputValue.length > 0) {
      this.setData({
        disabled: false
      });
    } else {
      this.setData({
        disabled: true
      });
    }
  },
  makePhoneCall: function makePhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.inputValue,
      success: function success() {
        console.log('成功拨打电话');
      }
    });
  }
});
});
define("packageAPI/pages/mdns/mdns.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/page/API/pages/mdns/mdns.js
var serviceList = [];
var resolveFailList = [];
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'mdns',
      path: 'packageAPI/pages/mdns/mdns'
    };
  },

  daga: {
    serviceList: [],
    resolveFailList: []
  },
  onShow: function onShow() {
    this.onLocalService();
  },
  startDiscovery: function startDiscovery() {
    wx.startLocalServiceDiscovery({
      serviceType: '_http._tcp.',
      success: function success(res) {
        console.log(res);
        wx.showToast({
          title: '开启成功',
          icon: 'none',
          duration: 2000
        });
      },
      fail: function fail(err) {
        wx.showToast({
          title: '开启失败',
          icon: 'none',
          duration: 2000
        });
        console.log(err);
      },
      complete: function complete() {
        console.log('startDiscovery: complete');
      }
    });
  },
  stopDiscovery: function stopDiscovery() {
    var that = this;
    wx.stopLocalServiceDiscovery({
      success: function success(res) {
        wx.showToast({
          title: '关闭成功',
          icon: 'none',
          duration: 2000
        });
        serviceList = [];
        resolveFailList = [];
        that.setData({
          serviceList: [],
          resolveFailList: []
        });
      },
      fail: function fail() {
        console.log('stopDiscovery: fail');
        wx.showToast({
          title: '关闭失败',
          icon: 'none',
          duration: 2000
        });
      },
      complete: function complete() {
        console.log('stopDIscovery: complete');
      }
    });
  },


  // 监听列表
  onLocalService: function onLocalService() {
    var that = this;

    // 监听服务发现事件
    wx.onLocalServiceFound(function (obj) {
      console.log(obj);
      serviceList.push(obj);

      that.setData({
        serviceList: serviceList
      });
    });

    // 监听服务解析失败事件
    wx.onLocalServiceResolveFail(function (obj) {
      console.log(obj);
      resolveFailList.push(obj);
      that.setData({
        resolveFailList: resolveFailList
      });
    });

    // 监听服务离开
    wx.onLocalServiceLost(function (obj) {
      console.log(obj);
    });

    // 监听搜索停止
    wx.onLocalServiceDiscoveryStop(function (obj) {
      console.log('监听到搜索停止事件');
    });
  },

  // 取消监听
  offLocalService: function offLocalService() {

    console.log('是否执行此部分数据');
    // 取消监听服务发现事件
    wx.offLocalServiceFound(function () {
      console.log('取消监听服务发现事件 成功');
    });

    // 取消监听服务解析失败事件
    wx.offLocalServiceResolveFail(function () {
      console.log('取消监听 mDNS 服务解析失败的事件 成功');
    });

    // 取消监听服务离开
    wx.offLocalServiceLost(function () {
      console.log('取消监听服务离开事件 成功');
    });

    // 取消监听搜索停止
    wx.offLocalServiceDiscoveryStop(function () {
      console.log('取消监听 mDNS 服务停止搜索的事件 成功');
    });
  }
});
});
define("packageAPI/pages/media-container/media-container.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '音视频合成',
      path: 'packageAPI/pages/media-container/media-container'
    };
  },
  onLoad: function onLoad() {
    var canIUse = wx.canIUse('wx.createMediaContainer()');
    if (canIUse) {
      this.mediaContainer = wx.createMediaContainer();
    } else {
      this.setData({
        canIUse: false
      });
      wx.showModal({
        title: '微信版本过低，暂不支持本功能'
      });
    }
  },

  data: {
    targetSrc: '',
    one: '',
    two: '',
    canIUse: true
  },
  handleChooseVideo: function handleChooseVideo(e) {
    var that = this;
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      success: function success(res) {
        console.log(res.tempFilePath);
        that.setData(_defineProperty({}, e.currentTarget.dataset.video, res.tempFilePath));
        if (e.currentTarget.dataset.video === 'one') {
          that.mediaContainer.extractDataSource({
            source: that.data.one,
            success: function success(mt) {
              that.mediaTrackOne = mt;
            }
          });
        } else {
          that.mediaContainer.extractDataSource({
            source: that.data.two,
            success: function success(mt) {
              that.mediaTrackTwo = mt;
            }
          });
        }
      }
    });
  },
  handleExport: function handleExport() {
    if (this.data.one === '' || this.data.two === '') {
      wx.showToast({
        title: '请先选择源视频',
        icon: "none"
      });
    } else {
      console.log(this.mediaTrackOne, this.mediaTrackTwo);
      // 获取源视频 1 的视频轨道

      var _mediaTrackOne$tracks = this.mediaTrackOne.tracks.filter(function (item) {
        return item.kind === 'video';
      }),
          _mediaTrackOne$tracks2 = _slicedToArray(_mediaTrackOne$tracks, 1),
          trackMedia = _mediaTrackOne$tracks2[0];
      // 获取源视频 2 的音频轨道


      var _mediaTrackTwo$tracks = this.mediaTrackTwo.tracks.filter(function (item) {
        return item.kind === 'audio';
      }),
          _mediaTrackTwo$tracks2 = _slicedToArray(_mediaTrackTwo$tracks, 1),
          trackAudio = _mediaTrackTwo$tracks2[0];

      console.log(trackMedia, trackAudio);
      // 添加轨道到目标容器
      this.mediaContainer.addTrack(trackMedia);
      this.mediaContainer.addTrack(trackAudio);
      var that = this;
      // 合成目标视频
      this.mediaContainer.export({
        success: function success(res) {
          that.setData({
            targetSrc: res.tempFilePath
          });
        }
      });
    }
  }
});
});
define("packageAPI/pages/modal/modal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '模态弹窗',
      path: 'packageAPI/pages/modal/modal'
    };
  },


  data: {
    modalHidden: true,
    modalHidden2: true
  },
  modalTap: function modalTap() {
    wx.showModal({
      title: '弹窗标题',
      content: '弹窗内容，告知当前状态、信息和解决方法，描述文字尽量控制在三行内',
      showCancel: false,
      confirmText: '确定'
    });
  },
  noTitlemodalTap: function noTitlemodalTap() {
    wx.showModal({
      content: '弹窗内容，告知当前状态、信息和解决方法，描述文字尽量控制在三行内',
      confirmText: '确定',
      cancelText: '取消'
    });
  }
});
});
define("packageAPI/pages/navigation-bar-loading/navigation-bar-loading.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '标题栏加载动画',
      path: 'packageAPI/pages/navigation-bar-loading/navigation-bar-loading'
    };
  },
  showNavigationBarLoading: function showNavigationBarLoading() {
    wx.showNavigationBarLoading();
  },
  hideNavigationBarLoading: function hideNavigationBarLoading() {
    wx.hideNavigationBarLoading();
  }
});
});
define("packageAPI/pages/navigator/navigator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '页面跳转',
      path: 'packageAPI/pages/navigator/navigator'
    };
  },
  navigateTo: function navigateTo() {
    wx.navigateTo({ url: './navigator' });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  redirectTo: function redirectTo() {
    wx.redirectTo({ url: './navigator' });
  },
  switchTab: function switchTab() {
    wx.switchTab({ url: '/page/component/index' });
  },
  reLaunch: function reLaunch() {
    wx.reLaunch({ url: '/page/component/index' });
  }
});
});
define("packageAPI/pages/on-accelerometer-change/on-accelerometer-change.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '监听重力感应数据',
      path: 'packageAPI/pages/on-accelerometer-change/on-accelerometer-change'
    };
  },


  data: {
    x: 0,
    y: 0,
    z: 0,
    enabled: true
  },
  onReady: function onReady() {
    this.drawBigBall();
    var that = this;

    this.position = {
      x: 151,
      y: 151,
      vx: 0,
      vy: 0,
      ax: 0,
      ay: 0
    };
    wx.onAccelerometerChange(function (res) {
      that.setData({
        x: res.x.toFixed(2),
        y: res.y.toFixed(2),
        z: res.z.toFixed(2)
      });
      that.position.ax = Math.sin(res.x * Math.PI / 2);
      that.position.ay = -Math.sin(res.y * Math.PI / 2);
      // that.drawSmallBall()
    });

    this.interval = setInterval(function () {
      that.drawSmallBall();
    }, 17);
  },
  drawBigBall: function drawBigBall() {
    var context = wx.createContext();
    context.beginPath(0);
    context.arc(151, 151, 140, 0, Math.PI * 2);
    context.setFillStyle('#ffffff');
    context.setStrokeStyle('#aaaaaa');
    context.fill();
    // context.stroke()
    wx.drawCanvas({
      canvasId: 'big-ball',
      actions: context.getActions()
    });
  },
  drawSmallBall: function drawSmallBall() {
    var p = this.position;
    var strokeStyle = 'rgba(1,1,1,0)';

    p.x += p.vx;
    p.y += p.vy;
    p.vx += p.ax;
    p.vy += p.ay;

    // eslint-disable-next-line
    if (Math.sqrt(Math.pow(Math.abs(p.x) - 151, 2) + Math.pow(Math.abs(p.y) - 151, 2)) >= 115) {
      if (p.x > 151 && p.vx > 0) {
        p.vx = 0;
      }
      if (p.x < 151 && p.vx < 0) {
        p.vx = 0;
      }
      if (p.y > 151 && p.vy > 0) {
        p.vy = 0;
      }
      if (p.y < 151 && p.vy < 0) {
        p.vy = 0;
      }
      strokeStyle = '#ff0000';
    }

    var context = wx.createContext();
    context.beginPath(0);
    context.arc(p.x, p.y, 15, 0, Math.PI * 2);
    context.setFillStyle('#1aad19');
    context.setStrokeStyle(strokeStyle);
    context.fill();
    // context.stroke()
    wx.drawCanvas({
      canvasId: 'small-ball',
      actions: context.getActions()
    });
  },
  startAccelerometer: function startAccelerometer() {
    if (this.data.enabled) {
      return;
    }
    var that = this;
    wx.startAccelerometer({
      success: function success() {
        that.setData({
          enabled: true
        });
      }
    });
  },
  stopAccelerometer: function stopAccelerometer() {
    if (!this.data.enabled) {
      return;
    }
    var that = this;
    wx.stopAccelerometer({
      success: function success() {
        that.setData({
          enabled: false
        });
      }
    });
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
  }
});
});
define("packageAPI/pages/on-compass-change/on-compass-change.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '监听罗盘数据',
      path: 'packageAPI/pages/on-compass-change/on-compass-change'
    };
  },


  data: {
    enabled: true,
    direction: 0
  },
  onReady: function onReady() {
    var that = this;
    wx.onCompassChange(function (res) {
      that.setData({
        direction: parseInt(res.direction, 10)
      });
    });
  },
  startCompass: function startCompass() {
    if (this.data.enabled) {
      return;
    }
    var that = this;
    wx.startCompass({
      success: function success() {
        that.setData({
          enabled: true
        });
      }
    });
  },
  stopCompass: function stopCompass() {
    if (!this.data.enabled) {
      return;
    }
    var that = this;
    wx.stopCompass({
      success: function success() {
        that.setData({
          enabled: false
        });
      }
    });
  }
});
});
define("packageAPI/pages/on-network-status-change/on-network-status-change.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '监听手机网络变化',
      path: 'packageAPI/pages/on-network-status-change/on-network-status-change'
    };
  },


  data: {
    isConnected: false
  },
  onLoad: function onLoad() {
    var that = this;
    wx.onNetworkStatusChange(function (res) {
      that.setData({
        isConnected: res.isConnected,
        networkType: res.networkType
      });
    });
  },
  onShow: function onShow() {
    var that = this;
    wx.getNetworkType({
      success: function success(res) {
        that.setData({
          isConnected: res.networkType !== 'none',
          networkType: res.networkType
        });
      }
    });
  }
});
});
define("packageAPI/pages/open-location/open-location.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '查看位置',
      path: 'packageAPI/pages/open-location/open-location'
    };
  },
  openLocation: function openLocation(e) {
    console.log(e);
    var value = e.detail.value;
    console.log(value);
    wx.openLocation({
      longitude: Number(value.longitude),
      latitude: Number(value.latitude),
      name: value.name,
      address: value.address
    });
  }
});
});
define("packageAPI/pages/page-scroll/page-scroll.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '页面滚动',
      path: 'packageAPI/pages/page-scroll/page-scroll'
    };
  },
  scrollToTop: function scrollToTop() {
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    });
  },
  scrollToBottom: function scrollToBottom() {
    wx.pageScrollTo({
      scrollTop: 3000,
      duration: 300
    });
  }
});
});
define("packageAPI/pages/pull-down-refresh/pull-down-refresh.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '下拉刷新',
      path: 'packageAPI/pages/pull-down-refresh/pull-down-refresh'
    };
  },
  onPullDownRefresh: function onPullDownRefresh() {
    wx.showToast({
      title: 'loading...',
      icon: 'loading'
    });
    console.log('onPullDownRefresh', new Date());
  },
  stopPullDownRefresh: function stopPullDownRefresh() {
    wx.stopPullDownRefresh({
      complete: function complete(res) {
        wx.hideToast();
        console.log(res, new Date());
      }
    });
  }
});
});
define("packageAPI/pages/request-payment/request-payment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '发起支付',
      path: 'packageAPI/pages/request-payment/request-payment'
    };
  },
  onLoad: function onLoad() {},
  requestPayment: function requestPayment() {
    var self = this;

    self.setData({
      loading: true
    });

    // 此处需要先调用wx.login方法获取code，然后在服务端调用微信接口使用code换取下单用户的openId
    // 具体文档参考https://mp.weixin.qq.com/debug/wxadoc/dev/api/api-login.html?t=20161230#wxloginobject
    app.getUserOpenId(function (err, openid) {
      if (!err) {
        wx.cloud.callFunction({
          name: 'pay',
          data: {
            action: 'unifiedorder',
            userInfo: {
              openId: openid
            },
            price: 0.01
          },
          success: function success(res) {
            console.warn('[云函数] [openapi] templateMessage.send 调用成功：', res);
            var data = res.result.data;
            wx.requestPayment({
              timeStamp: data.time_stamp,
              nonceStr: data.nonce_str,
              package: 'prepay_id=' + data.prepay_id,
              signType: 'MD5',
              paySign: data.sign,
              success: function success() {
                wx.showToast({ title: '支付成功' });
              }
            });
          },
          fail: function fail(err) {
            wx.showToast({
              icon: 'none',
              title: '支付失败'
            });
            console.error('[云函数] [openapi] templateMessage.send 调用失败：', err);
          }
        });
      } else {
        console.log('err:', err);
        self.setData({
          loading: false
        });
      }
    });
  }
});
});
define("packageAPI/pages/request/request.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var requestUrl = require('../../../config').requestUrl;

var duration = 2000;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '网络请求',
      path: 'packageAPI/pages/request/request'
    };
  },
  makeRequest: function makeRequest() {
    var self = this;

    self.setData({
      loading: true
    });

    wx.request({
      url: requestUrl,
      data: {
        noncestr: Date.now()
      },
      success: function success(result) {
        wx.showToast({
          title: '请求成功',
          icon: 'success',
          mask: true,
          duration: duration
        });
        self.setData({
          loading: false
        });
        console.log('request success', result);
      },
      fail: function fail(_ref) {
        var errMsg = _ref.errMsg;

        console.log('request fail', errMsg);
        self.setData({
          loading: false
        });
      }
    });
  }
});
});
define("packageAPI/pages/resizable/resizable.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/packageAPI/pages/resizable/resizable.js
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '屏幕旋转',
      path: 'package/API/pages/resizable/resizable'
    };
  },

  data: {
    status: 'lock'
  },
  handleStatusChange: function handleStatusChange(e) {
    this.setData({
      status: e.currentTarget.dataset.status
    });
  }
});
});
define("packageAPI/pages/scan-code/scan-code.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '扫码',
      path: 'packageAPI/pages/scan-code/scan-code'
    };
  },


  data: {
    result: ''
  },

  scanCode: function scanCode() {
    var that = this;
    wx.scanCode({
      success: function success(res) {
        that.setData({
          result: res.result
        });
      },
      fail: function fail() {}
    });
  }
});
});
define("packageAPI/pages/screen-brightness/screen-brightness.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '屏幕亮度',
      path: 'packageAPI/pages/screen-brightness/screen-brightness'
    };
  },


  data: {
    screenBrightness: 0
  },

  onLoad: function onLoad() {
    this._updateScreenBrightness();
  },
  changeBrightness: function changeBrightness(e) {
    var value = Number.parseFloat(e.detail.value.toFixed(1));
    this.setData({
      screenBrightness: Number.parseFloat(e.detail.value.toFixed(1))
    });
    wx.setScreenBrightness({
      value: value

    });
  },
  _updateScreenBrightness: function _updateScreenBrightness() {
    var _this = this;

    wx.getScreenBrightness({
      success: function success(res) {
        console.log(res);
        _this.setData({
          screenBrightness: Number.parseFloat(res.value.toFixed(1))
        });
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  }
});
});
define("packageAPI/pages/sendMessage/sendMessage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'sendMessage',
      path: 'packageAPI/pages/sendMessage/sendMessage'
    };
  }
});
});
define("packageAPI/pages/set-navigation-bar-title/set-navigation-bar-title.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '设置页面标题',
      path: 'packageAPI/pages/set-navigation-bar-title/set-navigation-bar-title'
    };
  },
  setNaivgationBarTitle: function setNaivgationBarTitle(e) {
    var title = e.detail.value.title;
    console.log(title);
    wx.setNavigationBarTitle({
      title: title,
      success: function success() {
        console.log('setNavigationBarTitle success');
      },
      fail: function fail(err) {
        console.log('setNavigationBarTitle fail, err is', err);
      }
    });

    return false;
  }
});
});
define("packageAPI/pages/setting/setting.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '设置',
      path: 'packageAPI/pages/setting/setting'
    };
  },


  data: {
    setting: {}
  },

  getSetting: function getSetting() {
    var _this = this;

    wx.getSetting({
      success: function success(res) {
        console.log(res);
        _this.setData({ setting: res.authSetting });
      }
    });
  }
});
});
define("packageAPI/pages/share-button/share-button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '转发按钮',
      path: 'packageAPI/pages/share-button/share-button'
    };
  },
  handleTapShareButton: function handleTapShareButton() {
    if (!(typeof wx.canIUse === 'function' && wx.canIUse('button.open-type.share'))) {
      wx.showModal({
        title: '当前版本不支持转发按钮',
        content: '请升级至最新版本微信客户端',
        showCancel: false
      });
    }
  }
});
});
define("packageAPI/pages/share/share.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {
    shareData: {
      title: '自定义转发标题',
      desc: '自定义转发描述',
      path: 'packageAPI/pages/share/share'
    }
  },

  onShareAppMessage: function onShareAppMessage() {
    return this.data.shareData;
  }
});
});
define("packageAPI/pages/soter-authentication/soter-authentication.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '生物认证',
      path: 'packageAPI/pages/soter-authentication/soter-authentication'
    };
  },
  startAuth: function startAuth(e) {
    console.log(e);
    var AUTH_MODE = e.currentTarget.dataset.mode;
    console.log(AUTH_MODE);
    var startSoterAuthentication = function startSoterAuthentication() {
      wx.startSoterAuthentication({
        requestAuthModes: [AUTH_MODE],
        challenge: 'test',
        authContent: '小程序示例',
        success: function success() {
          wx.showToast({
            title: '认证成功'
          });
        },
        fail: function fail(err) {
          console.error(err);
          wx.showModal({
            title: '失败',
            content: '认证失败',
            showCancel: false
          });
        }
      });
    };

    var checkIsEnrolled = function checkIsEnrolled() {
      wx.checkIsSoterEnrolledInDevice({
        checkAuthMode: AUTH_MODE,
        success: function success(res) {
          console.log(res);
          if (parseInt(res.isEnrolled, 10) <= 0) {
            wx.showModal({
              title: '错误',
              content: '\u60A8\u6682\u672A\u5F55\u5165' + (AUTH_MODE === 'facial' ? '人脸' : '指纹') + '\u4FE1\u606F\uFF0C\u8BF7\u5F55\u5165\u540E\u91CD\u8BD5',
              showCancel: false
            });
            return;
          }
          startSoterAuthentication();
        },
        fail: function fail(err) {
          console.error(err);
        }
      });
    };

    var notSupported = function notSupported() {
      wx.showModal({
        title: '错误',
        content: '\u60A8\u7684\u8BBE\u5907\u4E0D\u652F\u6301' + (AUTH_MODE === 'facial' ? '人脸' : '指纹') + '\u8BC6\u522B',
        showCancel: false
      });
    };

    wx.checkIsSupportSoterAuthentication({
      success: function success(res) {
        console.log(res);
        if (!res || res.supportMode.length === 0 || res.supportMode.indexOf(AUTH_MODE) < 0) {
          notSupported();
          return;
        }
        checkIsEnrolled();
      },
      fail: function fail(err) {
        console.error(err);
        notSupported();
      }
    });
  }
});
});
define("packageAPI/pages/storage/storage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '数据存储',
      path: 'packageAPI/pages/storage/storage'
    };
  },


  data: {
    key: '',
    data: '',
    dialog: {
      title: '',
      content: '',
      hidden: true
    }
  },

  keyChange: function keyChange(e) {
    this.data.key = e.detail.value;
  },
  dataChange: function dataChange(e) {
    this.data.data = e.detail.value;
  },
  getStorage: function getStorage() {
    var _data = this.data,
        key = _data.key,
        data = _data.data;

    var storageData = void 0;

    if (key.length === 0) {
      this.setData({
        key: key,
        data: data
      });
      wx.showModal({
        title: '读取数据失败',
        content: 'key 不能为空'
      });
    } else {
      storageData = wx.getStorageSync(key);
      console.log(storageData);
      if (storageData === '') {
        this.setData({
          key: key,
          data: storageData
        });
        wx.showModal({
          title: '读取数据失败',
          content: '找不到 key 对应的数据'
        });
      } else {
        this.setData({
          key: key,
          data: storageData
        });
        wx.showModal({
          title: '读取数据成功',
          content: storageData
        });
      }
    }
  },
  setStorage: function setStorage() {
    var _data2 = this.data,
        key = _data2.key,
        data = _data2.data;

    if (key.length === 0) {
      this.setData({
        key: key,
        data: data
      });
      wx.showModal({
        title: '保存数据失败',
        content: 'key 不能为空'
      });
    } else {
      wx.setStorageSync(key, data);
      this.setData({
        key: key,
        data: data

      });
      wx.showModal({
        title: '存储数据成功'
      });
    }
  },
  clearStorage: function clearStorage() {
    wx.clearStorageSync();
    this.setData({
      key: '',
      data: ''
    });
    wx.showModal({
      title: '清除数据成功'
    });
  }
});
});
define("packageAPI/pages/subscribe-message/subscribe-message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({

  /**
   * 页面的初始数据
   */
  data: {},

  // 请求订阅
  requestSubscribeMessage: function requestSubscribeMessage() {
    var self = this;
    wx.requestSubscribeMessage({
      tmplIds: ['y1bXHAg_oDuvrQ3pHgcODcMPl-2hZHenWugsqdB2CXY'],
      success: function success(res) {
        console.log(res);
        if (res.errMsg === 'requestSubscribeMessage:ok') {
          self.subscribeMessageSend();
        }
      },
      complete: function complete(res) {
        console.log(res);
      }
    });
  },


  // 下发订阅消息
  subscribeMessageSend: function subscribeMessageSend() {
    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendSubscribeMessage'
      },
      success: function success(res) {
        console.warn('[云函数] [openapi] templateMessage.send 调用成功：', res);
        wx.showModal({
          title: '订阅成功',
          content: '请返回微信主界面查看',
          showCancel: false
        });
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '调用失败'
        });
        console.error('[云函数] [openapi] templateMessage.send 调用失败：', err);
      }
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '订阅消息',
      path: 'packageAPI/pages/subscribe-message/subscribe-message'
    };
  }
});
});
define("packageAPI/pages/template-message/template-message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var templateMessageUrl = require('../../../config').templateMessageUrl;

var app = getApp();

var formData = {
  address: 'T.I.T 造舰厂',
  time: '2017.01.09',
  name: '帝国歼星舰',
  serial: '123456789'
};

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '模板消息',
      path: 'packageAPI/pages/template-message/template-message'
    };
  },
  onLoad: function onLoad() {
    this.setData({
      formData: formData
    });
  },
  submitForm: function submitForm(e) {
    var self = this;
    var formId = e.detail.formId;

    var formData = e.detail.value;

    console.log('form_id is:', formId);

    self.setData({
      loading: true
    });

    app.getUserOpenId(function (err, openid) {
      if (!err) {
        wx.request({
          url: templateMessageUrl,
          method: 'POST',
          data: {
            form_id: formId,
            openid: openid,
            formData: formData
          },
          success: function success(res) {
            console.log('submit form success', res);
            wx.showToast({
              title: '发送成功',
              icon: 'success'
            });
            self.setData({
              loading: false
            });
          },
          fail: function fail(_ref) {
            var errMsg = _ref.errMsg;

            console.log('submit form fail, errMsg is:', errMsg);
          }
        });
      } else {
        console.log('err:', err);
      }
    });
  }
});
});
define("packageAPI/pages/toast/toast.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '消息提示框',
      path: 'packageAPI/pages/toast/toast'
    };
  },
  toast1Tap: function toast1Tap() {
    wx.showToast({
      title: '默认'
    });
  },
  toast2Tap: function toast2Tap() {
    wx.showToast({
      title: 'duration 3000',
      duration: 3000
    });
  },
  toast3Tap: function toast3Tap() {
    wx.showToast({
      title: 'loading',
      icon: 'loading',
      duration: 5000
    });
  },
  hideToast: function hideToast() {
    wx.hideToast();
  }
});
});
define("packageAPI/pages/two-way-bindings/two-way-bindings.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/page/API/pages/two-way-bindings/two-way-bindings.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '双向绑定',
      path: 'packageAPI/pages/make-phone-call/make-phone-call'
    };
  }
});
});
define("packageAPI/pages/udp-socket/udp-socket.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var AB2String = function AB2String(arrayBuffer) {
  var unit8Arr = new Uint8Array(arrayBuffer);
  var encodedString = String.fromCharCode.apply(null, unit8Arr),
      decodedString = decodeURIComponent(escape(encodedString)); //没有这一步中文会乱码
  return decodedString;
};

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'UDPSocket',
      path: 'packageAPI/pages/udp-socket/udp-socket'
    };
  },

  data: {
    port: undefined,
    remote_port: undefined,
    startUDP: false,
    mode: 'local',
    address: 'localhost',
    canIUse: true
  },
  onLoad: function onLoad() {
    var canIUse = wx.canIUse('createUDPSocket');
    if (!canIUse) {
      wx.showModal({
        title: '微信版本过低，暂不支持本功能'
      });
      this.setData({
        canIUse: canIUse
      });
    }
  },
  handleCreateUDPTap: function handleCreateUDPTap() {
    this.UDPSocket = wx.createUDPSocket();
    this.remoteUDPSocket = wx.createUDPSocket();
    this.port = this.UDPSocket.bind();
    this.remote_port = this.remoteUDPSocket.bind();
    this.setData({
      port: this.port,
      remote_port: this.remote_port,
      startUDP: true
    });
    this.remoteUDPSocket.onMessage(function (res) {
      var remoteInfo = res.remoteInfo;

      console.log(res);
      wx.showModal({
        title: 'IP:' + remoteInfo.address + '\u53D1\u6765\u7684\u4FE1\u606F',
        content: AB2String(res.message)
      });
    });
  },
  handleCloseUDPTap: function handleCloseUDPTap() {
    this.setData({
      startUDP: false,
      mode: 'local'
    });
    console.log(this.data);
    this.UDPSocket.close();
    this.remoteUDPSocket.close();
  },
  handleSendRemoteMessage: function handleSendRemoteMessage() {
    this.UDPSocket.send({
      address: this.data.address || 'localhost', // 可以是任意 ip 和域名 
      port: this.remote_port,
      message: 'port[' + this.port + '] \u5411 remote-port[' + this.remote_port + '] \u53D1\u9001\u4FE1\u606F: Hello Wechat!'
    });
  },
  changeMode: function changeMode() {
    this.setData({
      mode: 'remote'
    });
  },
  handleInputChange: function handleInputChange(e) {
    this.setData({
      address: e.detail.value
    });
  },
  handleSendMessage: function handleSendMessage() {
    this.UDPSocket.send({
      address: 'localhost', // 可以是任意 ip 和域名 
      port: this.remote_port,
      message: 'port[' + this.port + '] \u5411 remote-port[' + this.remote_port + '] \u53D1\u9001\u4FE1\u606F: Hello Wechat!'
    });
  }
});
});
define("packageAPI/pages/upload-file/upload-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '上传文件',
      path: 'packageAPI/pages/upload-file/upload-file'
    };
  },
  chooseImage: function chooseImage() {
    var self = this;

    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album'],
      success: function success(res) {
        console.log('chooseImage success, temp path is', res.tempFilePaths[0]);

        var imageSrc = res.tempFilePaths[0];

        wx.cloud.uploadFile({
          cloudPath: 'example.png', // 上传至云端的路径
          filePath: imageSrc, // 小程序临时文件路径
          config: {
            env: 'release-b86096'
          },
          success: function success(res) {
            // 返回文件 ID
            console.log(res.fileID);
            console.log('uploadImage success, res is:', res);

            wx.showToast({
              title: '上传成功',
              icon: 'success',
              duration: 1000
            });

            self.setData({
              imageSrc: imageSrc,
              fileID: res.fileID
            });
          },
          fail: function fail(_ref) {
            var errMsg = _ref.errMsg;

            console.log('uploadImage fail, errMsg is', errMsg);
          }
        });
      },


      fail: function fail(res) {
        wx.showToast({
          icon: 'none',
          title: '上传失败'
        });
        console.log('uploadImage fail, errMsg is', res.errMsg);
      }
    });
  },
  onUnload: function onUnload() {
    if (this.data.fileID) {
      wx.cloud.deleteFile({
        fileList: [this.data.fileID]
      });
    }
  }
});
});
define("packageAPI/pages/vibrate/vibrate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '振动',
      path: 'packageAPI/pages/vibrate/vibrate'
    };
  },
  vibrateShort: function vibrateShort() {
    wx.vibrateShort({
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(err) {
        console.error(err);
      },
      complete: function complete() {
        console.log('completed');
      }
    });
  },
  vibrateLong: function vibrateLong() {
    wx.vibrateLong({
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(err) {
        console.error(err);
      },
      complete: function complete() {
        console.log('completed');
      }
    });
  }
});
});
define("packageAPI/pages/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var sourceType = [['camera'], ['album'], ['camera', 'album']];
var camera = [['front'], ['back'], ['front', 'back']];

// eslint-disable-next-line
var duration = Array.apply(null, { length: 60 }).map(function (n, i) {
  return i + 1;
});

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '拍摄/选择视频',
      path: 'packageAPI/pages/video/video'
    };
  },


  data: {
    sourceTypeIndex: 2,
    sourceType: ['拍摄', '相册', '拍摄或相册'],

    cameraIndex: 2,
    camera: ['前置', '后置', '前置或后置'],

    durationIndex: 59,
    duration: duration.map(function (t) {
      return t + '秒';
    }),

    src: ''
  },
  sourceTypeChange: function sourceTypeChange(e) {
    this.setData({
      sourceTypeIndex: e.detail.value
    });
  },
  cameraChange: function cameraChange(e) {
    this.setData({
      cameraIndex: e.detail.value
    });
  },
  durationChange: function durationChange(e) {
    this.setData({
      durationIndex: e.detail.value
    });
  },
  chooseVideo: function chooseVideo() {
    var that = this;
    wx.chooseVideo({
      sourceType: sourceType[this.data.sourceTypeIndex],
      camera: camera[this.data.cameraIndex],
      maxDuration: duration[this.data.durationIndex],
      success: function success(res) {
        that.setData({
          src: res.tempFilePath
        });
      }
    });
  }
});
});
define("packageAPI/pages/voice/voice.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../util/util.js');

var playTimeInterval = void 0;
var recordTimeInterval = void 0;
var recorderManager = wx.getRecorderManager();
var innerAudioContext = wx.createInnerAudioContext();
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '录音',
      path: 'packageAPI/pages/voice/voice'
    };
  },

  data: {
    recording: false, // 录音中
    playing: false, // 播放中
    hasRecord: false, // 已经录音
    recordTime: 0, // 录音时长
    playTime: 0, // 播放时长
    formatedRecordTime: '00:00:00', // 录音时间
    formatedPlayTime: '00:00:00' // 播放时间
  },

  onHide: function onHide() {
    if (this.data.playing) {
      this.stopVoice();
    } else if (this.data.recording) {
      this.stopRecordUnexpectedly();
    }
  },
  onLoad: function onLoad() {
    var that = this;
    // 监听录音开始事件
    recorderManager.onStart(function () {
      console.log('recorderManage: onStart');
      // 录音时长记录 每秒刷新
      recordTimeInterval = setInterval(function () {
        var recordTime = that.data.recordTime += 1;
        that.setData({
          formatedRecordTime: util.formatTime(that.data.recordTime),
          recordTime: recordTime
        });
      }, 1000);
    });

    // 监听录音停止事件
    recorderManager.onStop(function (res) {
      console.log('recorderManage: onStop');
      that.setData({
        hasRecord: true, // 录音完毕
        recording: false,
        tempFilePath: res.tempFilePath,
        formatedPlayTime: util.formatTime(that.data.playTime)
      });
      // 清除录音计时器
      clearInterval(recordTimeInterval);
    });

    // 监听播放开始事件
    innerAudioContext.onPlay(function () {
      console.log('innerAudioContext: onPlay');
      playTimeInterval = setInterval(function () {
        var playTime = that.data.playTime + 1;
        if (that.data.playTime === that.data.recordTime) {
          that.stopVoice();
        } else {
          console.log('update playTime', playTime);
          that.setData({
            formatedPlayTime: util.formatTime(playTime),
            playTime: playTime
          });
        }
      }, 1000);
    });

    innerAudioContext.onStop(function () {});
  },
  startRecord: function startRecord() {
    this.setData({
      recording: true // 录音开始
    });
    // 设置 Recorder 参数
    var options = {
      duration: 10000, // 持续时长
      sampleRate: 44100,
      numberOfChannels: 1,
      encodeBitRate: 192000,
      format: 'aac',
      frameSize: 50
    };
    recorderManager.start(options); // 开始录音
  },
  stopRecord: function stopRecord() {
    recorderManager.stop(); // 停止录音
  },
  stopRecordUnexpectedly: function stopRecordUnexpectedly() {
    var that = this;
    wx.stopRecord({
      success: function success() {
        console.log('stop record success');
        clearInterval(recordTimeInterval);
        that.setData({
          recording: false,
          hasRecord: false,
          recordTime: 0,
          formatedRecordTime: util.formatTime(0)
        });
      }
    });
  },
  playVoice: function playVoice() {
    innerAudioContext.src = this.data.tempFilePath;
    this.setData({
      playing: true

    }, function () {
      innerAudioContext.play();
    });
  },
  pauseVoice: function pauseVoice() {
    clearInterval(playTimeInterval);
    innerAudioContext.pause();
    this.setData({
      playing: false
    });
  },
  stopVoice: function stopVoice() {
    clearInterval(playTimeInterval);
    innerAudioContext.stop();
    this.setData({
      playing: false,
      formatedPlayTime: util.formatTime(0),
      playTime: 0
    });
  },
  clear: function clear() {
    clearInterval(playTimeInterval);
    innerAudioContext.stop();
    this.setData({
      playing: false,
      hasRecord: false,
      tempFilePath: '',
      formatedRecordTime: util.formatTime(0),
      recordTime: 0,
      playTime: 0
    });
  }
});
});
define("packageAPI/pages/web-socket/web-socket.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function showModal(title, content) {
  wx.showModal({
    title: title,
    content: content,
    showCancel: false
  });
}

function showSuccess(title) {
  wx.showToast({
    title: title,
    icon: 'success',
    duration: 1000
  });
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'Web Socket',
      path: 'packageAPI/pages/web-socket/web-socket'
    };
  },


  data: {
    socketStatus: 'closed'
  },

  onLoad: function onLoad() {
    var self = this;
    self.setData({
      hasLogin: true
    });
    // qcloud.setLoginUrl(loginUrl)

    // qcloud.login({
    //   success: function(result) {
    //     console.log('登录成功', result)
    //     self.setData({
    //       hasLogin: true
    //     })
    //   },

    //   fail: function(error) {
    //     console.log('登录失败', error)
    //   }
    // })
  },
  onUnload: function onUnload() {
    this.closeSocket();
  },
  toggleSocket: function toggleSocket(e) {
    var turnedOn = e.detail.value;

    if (turnedOn && this.data.socketStatus === 'closed') {
      this.openSocket();
    } else if (!turnedOn && this.data.socketStatus === 'connected') {
      var _showSuccess = true;
      this.closeSocket(_showSuccess);
    }
  },
  openSocket: function openSocket() {
    var _this = this;

    // var socket = this.socket = new qcloud.Tunnel(tunnelUrl)

    wx.onSocketOpen(function () {
      console.log('WebSocket 已连接');
      showSuccess('Socket已连接');
      _this.setData({
        socketStatus: 'connected',
        waitingResponse: false
      });
    });

    wx.onSocketClose(function () {
      console.log('WebSocket 已断开');
      _this.setData({ socketStatus: 'closed' });
    });

    wx.onSocketError(function (error) {
      showModal('发生错误', JSON.stringify(error));
      console.error('socket error:', error);
      _this.setData({
        loading: false
      });
    });

    // 监听服务器推送消息
    wx.onSocketMessage(function (message) {
      showSuccess('收到信道消息');
      console.log('socket message:', message);
      _this.setData({
        loading: false
      });
    });

    // 打开信道
    wx.connectSocket({
      url: 'wss://echo.websocket.org'
    });
  },
  closeSocket: function closeSocket() {
    var _this2 = this;

    if (this.data.socketStatus === 'connected') {
      wx.closeSocket({
        success: function success() {
          showSuccess('Socket已断开');
          _this2.setData({ socketStatus: 'closed' });
        }
      });
    }
  },
  sendMessage: function sendMessage() {
    if (this.data.socketStatus === 'connected') {
      wx.sendSocketMessage({
        data: 'Hello, Miniprogram!'
      });
    }
  }
});
});
define("packageAPI/pages/wifi/wifi.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'Wi-Fi',
      path: 'packageAPI/pages/wifi/wifi'
    };
  },


  data: {
    wifiList: []
  },

  onUnload: function onUnload() {
    this.stopSearch();
  },
  startSearch: function startSearch() {
    var _this = this;

    var getWifiList = function getWifiList() {
      wx.getWifiList({
        success: function success() {
          wx.onGetWifiList(function (res) {
            var wifiList = res.wifiList.sort(function (a, b) {
              return b.signalStrength - a.signalStrength;
            }).map(function (wifi) {
              var strength = Math.ceil(wifi.signalStrength * 4);
              return Object.assign(wifi, { strength: strength });
            });
            _this.setData({
              wifiList: wifiList
            });
          });
        },
        fail: function fail(err) {
          console.error(err);
        }
      });
    };

    var startWifi = function startWifi() {
      wx.startWifi({
        success: getWifiList,
        fail: function fail(err) {
          console.error(err);
        }
      });
    };

    wx.getSystemInfo({
      success: function success(res) {
        var isIOS = res.platform === 'ios';
        if (isIOS) {
          wx.showModal({
            title: '提示',
            content: '由于系统限制，iOS用户请手动进入系统WiFi页面，然后返回小程序。',
            showCancel: false,
            success: function success() {
              startWifi();
            }
          });
          return;
        }
        startWifi();
      }
    });
  },
  stopSearch: function stopSearch() {
    wx.stopWifi({
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  }
});
});
define("packageAPI/pages/worker/worker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _require = require('../../../util/util.js'),
    fib = _require.fib;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '多线程Worker',
      path: 'packageAPI/pages/worker/worker'
    };
  },


  data: {
    res: '',
    input: 35
  },

  onLoad: function onLoad() {
    this._worker = wx.createWorker('workers/fib/index.js');
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
    if (this._worker) this._worker.terminate();
  },
  bindInput: function bindInput(e) {
    var val = Number(e.detail.value);
    if (val > 40) return { value: 40 };
    if (Number.isNaN(val)) return { value: 33 };
    this.setData({
      input: val
    });
    return undefined;
  },
  reset: function reset() {
    this.setData({ res: '' });
  },
  compute: function compute() {
    this.reset();
    wx.showLoading({
      title: '计算中...'
    });
    var t0 = +Date.now();
    var res = fib(this.data.input);
    var t1 = +Date.now();
    wx.hideLoading();
    this.setData({
      res: res,
      time: t1 - t0
    });
  },
  multiThreadCompute: function multiThreadCompute() {
    var _this = this;

    this.reset();
    wx.showLoading({
      title: '计算中...'
    });

    var t0 = +Date.now();
    this._worker.postMessage({
      type: 'execFunc_fib',
      params: [this.data.input]
    });
    this._worker.onMessage(function (res) {
      if (res.type === 'execFunc_fib') {
        wx.hideLoading();
        var t1 = +Date.now();
        _this.setData({
          res: res.result,
          time: t1 - t0
        });
      }
    });
  },
  onReady: function onReady() {
    this.position = {
      x: 150,
      y: 150,
      vx: 2,
      vy: 2
    };

    this.drawBall();
    this.interval = setInterval(this.drawBall, 17);
  },
  drawBall: function drawBall() {
    var p = this.position;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    var context = wx.createContext();

    function ball(x, y) {
      context.beginPath(0);
      context.arc(x, y, 5, 0, Math.PI * 2);
      context.setFillStyle('#1aad19');
      context.setStrokeStyle('rgba(1,1,1,0)');
      context.fill();
      context.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);

    wx.drawCanvas({
      canvasId: 'canvas',
      actions: context.getActions()
    });
  }
});
});
define("packageAPI/pages/wxs/movable.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// pages/movable/movable.js
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'movable',
      path: 'packageAPI/pages/wxs/movable'
    };
  },

  /**
   * 页面的初始数据
   */
  data: {
    left: 50,
    top: 50,
    taptest: 'taptest',
    show: true,
    dataObj: {
      obj: 1
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    var _this = this;

    setTimeout(function () {
      _this.setData({
        // show: false,
      });
    }, 3000);
  },
  taptest: function taptest() {
    this.setData({
      show: false
    });
  }
});
});
define("packageAPI/pages/wxs/nearby.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var windowWidth = wx.getSystemInfoSync().windowWidth;
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'nearby',
      path: 'packageAPI/pages/wxs/nearby'
    };
  },

  data: {
    imgUrls: ['http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSEV5QjxLDJaL6ibHLSZ02TIcve0ocPXrdTVqGGbqAmh5Mw9V7504dlEiatSvnyibibHCrVQO2GEYsJicPA/0?wx_fmt=jpeg', 'http://mmbiz.qpic.cn/sz_mmbiz_png/GEWVeJPFkSHALb0g5rCc4Jf5IqDfdwhWJ43I1IvriaV5uFr9fLAuv3uxHR7DQstbIxhNXFoQEcxGzWwzQUDBd6Q/0?wx_fmt=png', 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSGqys4ibO2a8L9nnIgH0ibjNXfbicNbZQQYfxxUpmicQglAEYQ2btVXjOhY9gRtSTCxKvAlKFek7sRUFA/0?wx_fmt=jpeg', 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSH2Eic4Lt0HkZeEN08pWXTticVRgyNGgBVHMJwMtRhmB0hE4m4alSuwsBk3uBBOhdCr91bZlSFbYhFg/0?wx_fmt=jpeg'],
    imgSize: [{
      height: 150
    }, {
      height: 200
    }, {
      height: 150
    }, {
      height: 150
    }],
    indicatorDots: true,
    autoplay: false,
    interval: 3000,
    duration: 500,
    left: 0,
    windowWidth: windowWidth
  },
  changeIndicatorDots: function changeIndicatorDots(e) {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    });
  },
  swiperTransition1: function swiperTransition1(e) {
    console.log('e.transition', e);
    this.setData({
      left: e.detail.x / 4
    });
  },
  onReady: function onReady() {},

  changeAutoplay: function changeAutoplay(e) {
    this.setData({
      autoplay: !this.data.autoplay
    });
  },
  intervalChange: function intervalChange(e) {
    this.setData({
      interval: e.detail.value
    });
  },
  durationChange: function durationChange(e) {
    this.setData({
      duration: e.detail.value
    });
  }
});
});
define("packageAPI/pages/wxs/sidebar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// page/one/index.js
Page({
  data: {
    tabs: [],
    open: false,
    mark: 0,
    newmark: 0,
    startmark: 0,
    endmark: 0,
    windowWidth: wx.getSystemInfoSync().windowWidth,
    staus: 1,
    translate: ''
  },
  onLoad: function onLoad() {
    var tabs = [{
      title: '技术开发',
      title2: '小程序开发进阶',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSEV5QjxLDJaL6ibHLSZ02TIcve0ocPXrdTVqGGbqAmh5Mw9V7504dlEiatSvnyibibHCrVQO2GEYsJicPA/0?wx_fmt=jpeg',
      desc: '本视频系列课程，由腾讯课堂NEXT学院与微信团队联合出品，通过实战案例，深入浅出地进行讲解。'
    }];
    this.setData({ tabs: tabs });
    // setTimeout(() => {
    // this.initInteraction()
    // }, 5000)
  }
});
});
define("packageAPI/pages/wxs/stick-top.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var height = wx.getSystemInfoSync().windowHeight;
var app = getApp();
Page({
  data: {
    sticky: false,
    opacity: 0,
    height: height,
    tabs: [],
    theme: app.globalData.theme
  },
  //滚动条监听
  onPageScroll: function onPageScroll(e) {
    // console.log('page scroll')
  },
  onShow: function onShow() {},
  onReady: function onReady() {},
  onLoad: function onLoad() {
    var tabs = [{
      title: '技术开发',
      title2: '小程序开发进阶',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSEV5QjxLDJaL6ibHLSZ02TIcve0ocPXrdTVqGGbqAmh5Mw9V7504dlEiatSvnyibibHCrVQO2GEYsJicPA/0?wx_fmt=jpeg',
      desc: '本视频系列课程，由腾讯课堂NEXT学院与微信团队联合出品，通过实战案例，深入浅出地进行讲解。'
    }, {
      title: '产品解析',
      title2: '微信小程序直播',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_png/GEWVeJPFkSHALb0g5rCc4Jf5IqDfdwhWJ43I1IvriaV5uFr9fLAuv3uxHR7DQstbIxhNXFoQEcxGzWwzQUDBd6Q/0?wx_fmt=png',
      desc: '微信小程序直播系列课程持续更新中，帮助大家更好地理解、应用微信小程序直播功能。'
    }, {
      title: '运营规范',
      title2: '常见问题和解决方案',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSGqys4ibO2a8L9nnIgH0ibjNXfbicNbZQQYfxxUpmicQglAEYQ2btVXjOhY9gRtSTCxKvAlKFek7sRUFA/0?wx_fmt=jpeg',
      desc: '提高审核质量'
    }, {
      title: '营销经验',
      title2: '流量主小程序',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSH2Eic4Lt0HkZeEN08pWXTticVRgyNGgBVHMJwMtRhmB0hE4m4alSuwsBk3uBBOhdCr91bZlSFbYhFg/0?wx_fmt=jpeg',
      desc: '本课程共四节，将分阶段为开发者展示如何开通流量主功能、如何接入广告组件、不同类型小程序接入的建议，以及如何通过工具调优小程序变现效率。'
    }, {
      title: '高校大赛',
      title2: '2020中国高校计算机大赛',
      img: 'http://mmbiz.qpic.cn/mmbiz_jpg/TcDuyasB5T3Eg34AYwjMw7xbEK2n01ekiaicPiaMInEMTkOQtuv1yke5KziaYF4MLia4IAbxlm0m5NxkibicFg4IZ92EA/0?wx_fmt=jpeg',
      desc: '微信小程序应用开发赛'
    }];
    this.setData({ tabs: tabs });
  }
});
});
define("packageAPI/pages/wxs/wxs.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/page/API/pages/wxs/wxs.js
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'wxs',
      path: 'packageAPI/pages/wxs/wxs'
    };
  },
  handleNavChange: function handleNavChange(e) {
    console.log(e);
    wx.navigateTo({
      url: '/packageAPI/pages/wxs/' + e.currentTarget.dataset.nav
    });
  }
});
});
define("packageCloud/pages/cloud-file-component/cloud-file-component.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _require = require('../../../config'),
    demoImageFileId = _require.demoImageFileId,
    demoVideoFileId = _require.demoVideoFileId;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '组件支持',
      path: 'page/cloud/pages/cloud-file-component/cloud-file-component'
    };
  },


  data: {
    imageFileId: demoImageFileId,
    videoFileId: demoVideoFileId
  }
});
});
define("packageCloud/pages/crud-detail/crud-detail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '基本操作',
      path: 'page/cloud/pages/crud/crud'
    };
  },


  data: {
    openid: '',
    todoId: '',
    description: '',
    done: false,
    updating: false,
    deleting: false
  },

  onLoad: function onLoad(options) {
    var _this = this;

    var todoId = options.todoId;

    this.setData({
      todoId: todoId
    });
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      });
      this.queryTodo();
    } else {
      wx.showLoading({
        title: '正在初始化...'
      });
      app.getUserOpenIdViaCloud().then(function (openid) {
        _this.setData({
          openid: openid
        });
        wx.hideLoading();
        _this.queryTodo();
        return openid;
      }).catch(function (err) {
        console.error(err);
        wx.hideLoading();
      });
    }
  },
  queryTodo: function queryTodo() {
    var _this2 = this;

    wx.showLoading({
      title: '正在查询...'
    });
    var db = wx.cloud.database();
    db.collection('todos').doc(this.data.todoId).get({
      success: function success(res) {
        _this2.setData({
          description: res.data.description,
          done: res.data.done
        });
        console.log('[数据库] [查询记录] 成功: ', res);
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        });
        console.error('[数据库] [查询记录] 失败：', err);
      },
      complete: function complete() {
        wx.hideLoading();
      }
    });
  },
  updateTodo: function updateTodo() {
    var _this3 = this;

    if (this.data.updating || !this.data.todoId) {
      return;
    }
    var _data = this.data,
        todoId = _data.todoId,
        description = _data.description;

    if (!description) {
      return;
    }

    this.setData({ updating: true });
    var db = wx.cloud.database();
    db.collection('todos').doc(todoId).update({
      data: {
        description: description
      },
      success: function success() {
        console.log('he');
        wx.showToast({
          title: '更新成功'
        });
        wx.navigateBack();
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '更新失败'
        });
        console.error('[数据库] [更新记录] 失败：', err);
      },
      complete: function complete() {
        _this3.setData({ updating: false });
      }
    });
  },
  removeTodo: function removeTodo() {
    var _this4 = this;

    if (this.data.deleting || !this.data.todoId) {
      return;
    }
    var todoId = this.data.todoId;


    this.setData({ deleting: true });
    var db = wx.cloud.database();
    db.collection('todos').doc(todoId).remove({
      success: function success() {
        wx.showToast({
          title: '删除成功'
        });
        wx.navigateBack();
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '删除失败'
        });
        console.error('[数据库] [删除记录] 失败：', err);
      },
      complete: function complete() {
        _this4.setData({ deleting: false });
      }
    });
  },
  onInputContent: function onInputContent(e) {
    this.setData({
      description: e.detail.value
    });
  }
});
});
define("packageCloud/pages/crud/crud.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/database.html

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '基本操作',
      path: 'page/cloud/pages/crud/crud'
    };
  },


  data: {
    openid: '',
    todoListFetched: false,
    todoList: [],
    searchContent: '',
    newContent: '',
    filtered: false,
    loading: false
  },

  onLoad: function onLoad() {
    var _this = this;

    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      });
      this.queryTodoList();
    } else {
      wx.showLoading({
        title: '正在初始化...'
      });
      app.getUserOpenIdViaCloud().then(function (openid) {
        _this.setData({
          openid: openid
        });
        wx.hideLoading();
        _this.queryTodoList();
        return openid;
      }).catch(function (err) {
        console.error(err);
        wx.hideLoading();
        wx.showToast({
          icon: 'none',
          title: '初始化失败，请检查网络'
        });
      });
    }
  },
  onShow: function onShow() {
    if (this.data.openid) {
      this.queryTodoList();
    }
  },
  createTodo: function createTodo() {
    var _this2 = this;

    if (this.data.loading) {
      return;
    }
    var newContent = this.data.newContent;

    if (!newContent) {
      return;
    }

    this.setData({ loading: true });
    var db = wx.cloud.database();
    db.collection('todos').add({
      data: {
        description: newContent,
        done: false
      },
      success: function success(res) {
        // 在返回结果中会包含新创建的记录的 _id
        _this2.setData({
          todoList: [].concat(_toConsumableArray(_this2.data.todoList), [{
            _id: res._id,
            _openid: _this2.data.openid,
            description: newContent,
            done: false
          }]),
          newContent: ''
        });
        wx.showToast({
          title: '新增记录成功'
        });
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id);
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '新增记录失败'
        });
        console.error('[数据库] [新增记录] 失败：', err);
      },
      complete: function complete() {
        _this2.setData({ loading: false });
      }
    });
  },
  queryTodoList: function queryTodoList() {
    var _this3 = this;

    wx.showLoading({
      title: '正在查询...'
    });
    var db = wx.cloud.database();
    db.collection('todos').where({
      _openid: this.data.openid
    }).get({
      success: function success(res) {
        _this3.setData({
          todoListFetched: true,
          todoList: res.data,
          filtered: false
        });
        console.log('[数据库] [查询记录] 成功: ', res);
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        });
        console.error('[数据库] [查询记录] 失败：', err);
      },
      complete: function complete() {
        wx.hideLoading();
      }
    });
  },
  searchTodo: function searchTodo() {
    var _this4 = this;

    var searchContent = this.data.searchContent;

    if (!searchContent) {
      this.queryTodoList();
      return;
    }

    var db = wx.cloud.database();
    var descriptionCondition = searchContent;
    var execResult = /^\/([\s\S]*)\//.exec(searchContent);
    if (execResult) {
      var reStr = execResult[1].trim().replace(/\s+/g, '|');
      descriptionCondition = db.RegExp({
        regexp: reStr
      });
    }
    wx.showLoading({
      title: '正在查询...'
    });
    db.collection('todos').where({
      _openid: this.data.openid,
      description: descriptionCondition
    }).get({
      success: function success(res) {
        _this4.setData({
          todoList: res.data,
          filtered: true
        });
        console.log('[数据库] [查询记录] 成功: ', res);
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        });
        console.error('[数据库] [查询记录] 失败：', err);
      },
      complete: function complete() {
        wx.hideLoading();
      }
    });
  },
  toggleComplete: function toggleComplete(e) {
    var _this5 = this;

    if (this.data.loading) {
      return;
    }
    var _e$currentTarget$data = e.currentTarget.dataset,
        todoId = _e$currentTarget$data.id,
        index = _e$currentTarget$data.index;

    var todo = this.data.todoList[index];

    this.setData({ loading: true });
    var db = wx.cloud.database();
    db.collection('todos').doc(todoId).update({
      data: { done: !todo.done },
      success: function success() {
        _this5.setData(_defineProperty({}, 'todoList[' + index + '].done', !todo.done));
      },
      fail: function fail(err) {
        wx.showToast({
          icon: 'none',
          title: '更新失败'
        });
        console.error('[数据库] [更新记录] 失败：', err);
      },
      complete: function complete() {
        _this5.setData({ loading: false });
      }
    });
  },
  toDetail: function toDetail(e) {
    var todoId = e.currentTarget.dataset.id;

    wx.navigateTo({
      url: '/page/cloud/pages/crud-detail/crud-detail?todoId=' + todoId
    });
  },
  onInputSearchContent: function onInputSearchContent(e) {
    this.setData({
      searchContent: e.detail.value
    });
  },
  onInputNewContent: function onInputNewContent(e) {
    this.setData({
      newContent: e.detail.value
    });
  }
});
});
define("packageCloud/pages/db-permission/db-permission.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/database/permission.html

var app = getApp();

var sliderWidth = 96;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '权限管理',
      path: 'page/cloud/pages/db-permission/db-permission'
    };
  },


  data: {
    openid: '',
    permissions: ['仅创建者可写，所有人可读', '仅创建者可读写', '仅管理端可写，所有人可读', '仅管理端可读写'],
    currentPermissionIndex: 0,
    tabs: [['我的个性签名', '阿白的个性签名'], ['我的邮箱', '阿绿的邮箱'], [], []],
    activeTabIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,

    querying: false,
    updating: false,

    hasMyWhatsUp: false,
    myWhatsUp: '',
    adminWhatsUp: '',
    myEmail: '',
    adminEmail: '',
    hasProduct: false,
    product: {},
    serverData: ''
  },

  onLoad: function onLoad() {
    var _this = this;

    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      });
    } else {
      wx.showLoading({
        title: '正在初始化...'
      });
      app.getUserOpenIdViaCloud().then(function (openid) {
        _this.setData({
          openid: openid
        });
        wx.hideLoading();
        return openid;
      }).catch(function (err) {
        console.error(err);
        wx.hideLoading();
        wx.showModal({
          content: '初始化失败，请检查网络',
          showCancel: false
        });
      });
    }
    var _app$globalData = app.globalData,
        myWhatsUp = _app$globalData.myWhatsUp,
        adminWhatsUp = _app$globalData.adminWhatsUp,
        myEmail = _app$globalData.myEmail,
        adminEmail = _app$globalData.adminEmail;

    this.setData({
      hasMyWhatsUp: !!myWhatsUp,
      myWhatsUp: myWhatsUp || '',
      adminWhatsUp: adminWhatsUp || '',
      myEmail: myEmail || '',
      adminEmail: adminEmail || ''
    });

    this.initTabs();
  },
  initTabs: function initTabs() {
    var currentPermissionIndex = this.data.currentPermissionIndex;
    var tabLength = this.data.tabs[currentPermissionIndex].length;
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          sliderLeft: (res.windowWidth / tabLength - sliderWidth) / 2,
          sliderOffset: res.windowWidth / tabLength * that.data.activeTabIndex
        });
      }
    });
  },
  onTabClick: function onTabClick(e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeTabIndex: Number(e.currentTarget.id)
    });
  },
  onPermissionChange: function onPermissionChange(e) {
    var oldIndex = this.data.currentPermissionIndex;
    var newIndex = Number(e.detail.value);
    if (oldIndex !== newIndex) {
      this.setData({
        currentPermissionIndex: Number(newIndex),
        activeTabIndex: 0
      });
      this.initTabs();
    }
  },
  bindInput: function bindInput(e) {
    var name = e.currentTarget.dataset.name;

    this.setData(_defineProperty({}, name, e.detail.value));
  },
  showErrorModal: function showErrorModal(name, err) {
    var errMsg = name + '失败';
    if (err.toString().indexOf('permission denied') >= 0) {
      errMsg += '：无权限操作';
    }
    wx.showModal({
      content: errMsg,
      showCancel: false
    });
  },


  // 根据 openid 获取第一条数据
  queryOneByOpenId: function queryOneByOpenId(collection, openid) {
    var _this2 = this;

    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
      showLoading: false,
      showError: false,
      success: null,
      fail: null
    };
    var showLoading = options.showLoading,
        showError = options.showError,
        successCallback = options.success,
        failCallback = options.fail;

    if (showLoading) {
      this.setData({
        querying: true
      });
    }
    var db = wx.cloud.database();
    var _openid = openid || this.data.openid;
    db.collection(collection).where({
      _openid: _openid
    }).get({
      success: function success(res) {
        console.log('[数据库] [查询记录] 成功: ', res);
        var resFirstData = res.data[0] || {};
        // 返回的不是要查询用户的记录，是由于没有读权限，视为查询失败
        if (resFirstData._openid && resFirstData._openid !== _openid) {
          var err = new Error('database permission denied');
          if (showError) _this2.showErrorModal('获取', err);
          if (failCallback) failCallback.call(_this2, err);
        } else if (successCallback) {
          successCallback.call(_this2, res.data[0]);
        }
      },
      fail: function fail(err) {
        if (showError) _this2.showErrorModal('获取', err);
        console.error('[数据库] [查询记录] 失败：', err);
        if (failCallback) failCallback.call(_this2, err);
      },
      complete: function complete() {
        if (showLoading) {
          _this2.setData({
            querying: false
          });
        }
      }
    });
  },


  // 根据 openid 更新数据
  updateOneByOpenId: function updateOneByOpenId(collection, openid, data) {
    var _this3 = this;

    var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {
      showLoading: false,
      showError: false,
      success: null,
      fail: null
    };
    var showLoading = options.showLoading,
        showError = options.showError,
        successCallback = options.success,
        failCallback = options.fail;

    if (showLoading) {
      this.setData({
        updating: true
      });
    }
    var db = wx.cloud.database();
    // 限制每人仅存一条记录，先查询是否已存在记录
    this.queryOneByOpenId(collection, openid || '', {
      success: function success(dbData) {
        if (dbData) {
          // 已有数据，进行更新操作
          db.collection(collection).doc(dbData._id).update({
            data: data,
            success: function success(res) {
              console.log('[数据库] [更新记录] 成功: ', res);
              if (successCallback) successCallback.call(_this3, res.stats);
            },
            fail: function fail(err) {
              if (showError) _this3.showErrorModal('设置', err);
              console.error('[数据库] [更新记录] 失败：', err);
              if (failCallback) failCallback.call(_this3, err);
            },
            complete: function complete() {
              if (showLoading) {
                _this3.setData({
                  updating: false
                });
              }
            }
          });
        } else if (!openid || openid === _this3.data.openid) {
          // 还没有插入过数据且要操作的是自己的数据，进行新增操作
          db.collection(collection).add({
            data: data,
            success: function success(res) {
              console.log('[数据库] [新增记录] 成功：', res);
              if (successCallback) successCallback.call(_this3, { _id: res._id });
            },
            fail: function fail(err) {
              if (showError) _this3.showErrorModal('设置', err);
              console.error('[数据库] [新增记录] 失败：', err);
              if (failCallback) failCallback.call(_this3, err);
            },
            complete: function complete() {
              if (showLoading) {
                _this3.setData({
                  updating: false
                });
              }
            }
          });
        } else {
          var err = new Error('database permission denied');
          if (showError) _this3.showErrorModal('设置', err);
          if (failCallback) failCallback.call(_this3, err);
          if (showLoading) {
            _this3.setData({
              updating: false
            });
          }
        }
      },
      fail: function fail(err) {
        if (showError) _this3.showErrorModal('设置', err);
        if (failCallback) failCallback.call(_this3, err);
        if (showLoading) {
          _this3.setData({
            updating: false
          });
        }
      }
    });
  },


  // perm1：仅创建者可写，所有人可读

  queryMyWhatsUp: function queryMyWhatsUp() {
    this.queryOneByOpenId('perm1', '', {
      showLoading: true,
      showError: true,
      success: function success(data) {
        var content = data && data.whatsUp || '';
        wx.showModal({
          title: '获取成功',
          content: content ? '个性签名为：' + content : '个性签名为空',
          showCancel: false
        });
      }
    });
  },
  updateMyWhatsUp: function updateMyWhatsUp() {
    var _this4 = this;

    var data = {
      whatsUp: this.data.myWhatsUp
    };
    this.updateOneByOpenId('perm1', '', data, {
      showLoading: true,
      showError: true,
      success: function success() {
        app.globalData.myWhatsUp = _this4.data.myWhatsUp;
        _this4.setData({
          hasMyWhatsUp: true
        });
        wx.showModal({
          content: '设置成功',
          showCancel: false
        });
      }
    });
  },
  queryAdminWhatsUp: function queryAdminWhatsUp() {
    this.queryOneByOpenId('perm1', 'kiki', {
      showLoading: true,
      showError: true,
      success: function success(data) {
        var content = data && data.whatsUp || '';
        wx.showModal({
          title: '获取成功',
          content: content ? '个性签名为：' + content : '个性签名为空',
          showCancel: false
        });
      }
    });
  },
  updateAdminWhatsUp: function updateAdminWhatsUp() {
    var _this5 = this;

    var data = {
      whatsUp: this.data.adminWhatsUp
    };
    this.updateOneByOpenId('perm1', 'kiki', data, {
      showLoading: true,
      showError: true,
      success: function success(res) {
        if (res.updated === 0) {
          wx.showModal({
            content: '设置失败：无权限操作',
            showCancel: false
          });
        } else {
          app.globalData.adminWhatsUp = _this5.data.adminWhatsUp;
          wx.showModal({
            content: '设置成功',
            showCancel: false
          });
        }
      }
    });
  },


  // perm2：仅创建者可读写

  queryMyEmail: function queryMyEmail() {
    this.queryOneByOpenId('perm2', '', {
      showLoading: true,
      showError: true,
      success: function success(data) {
        var content = data && data.email || '';
        wx.showModal({
          title: '获取成功',
          content: content ? '邮箱为：' + content : '邮箱为空',
          showCancel: false
        });
      }
    });
  },
  updateMyEmail: function updateMyEmail() {
    var _this6 = this;

    var data = {
      email: this.data.myEmail
    };
    this.updateOneByOpenId('perm2', '', data, {
      showLoading: true,
      showError: true,
      success: function success() {
        app.globalData.myEmail = _this6.data.myEmail;
        wx.showModal({
          content: '设置成功',
          showCancel: false
        });
      }
    });
  },
  queryAdminEmail: function queryAdminEmail() {
    this.queryOneByOpenId('perm2', 'popo', {
      showLoading: true,
      showError: true,
      success: function success(data) {
        var content = data && data.email || '';
        wx.showModal({
          title: '获取成功',
          content: content ? '邮箱为：' + content : '邮箱为空',
          showCancel: false
        });
      }
    });
  },
  updateAdminEmail: function updateAdminEmail() {
    var _this7 = this;

    var data = {
      email: this.data.adminEmail
    };
    this.updateOneByOpenId('perm2', 'popo', data, {
      showLoading: true,
      showError: true,
      success: function success() {
        app.globalData.adminEmail = _this7.data.adminEmail;
        wx.showModal({
          content: '设置成功',
          showCancel: false
        });
      }
    });
  },


  // perm3：仅管理端可写，所有人可读

  queryProduct: function queryProduct() {
    this.queryOneByOpenId('perm3', 'admin', {
      showLoading: true,
      showError: true,
      success: function success(data) {
        var price = data && data.price || null;
        wx.showModal({
          title: '获取成功',
          content: price !== null ? '商品价格为：' + price : '商品价格暂未设置',
          showCancel: false
        });
      }
    });
  },
  updateProductPrice: function updateProductPrice() {
    var data = {
      price: parseInt(this.data.product.price, 10)
    };
    this.updateOneByOpenId('perm3', 'admin', data, {
      showLoading: true,
      showError: true,
      success: function success() {
        wx.showModal({
          content: '设置成功',
          showCancel: false
        });
      }
    });
  },


  // perm4：仅管理端可读写

  queryServerData: function queryServerData() {
    this.queryOneByOpenId('perm4', 'server', {
      showLoading: true,
      showError: true,
      success: function success(data) {
        var content = data && data.serverData || '';
        wx.showModal({
          title: '获取成功',
          content: content ? '后台流水数据为：' + content : '后台流水数据为空',
          showCancel: false
        });
      }
    });
  },
  updateServerData: function updateServerData() {
    var data = {
      data: this.data.serverData
    };
    this.updateOneByOpenId('perm4', 'server', data, {
      showLoading: true,
      showError: true,
      success: function success() {
        wx.showModal({
          content: '设置成功',
          showCancel: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/delete-file/delete-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-client-api/storage/deleteFile.html

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '删除文件',
      path: 'page/cloud/pages/delete-file/delete-file'
    };
  },


  data: {
    fileId: '',
    loading: false
  },

  onLoad: function onLoad() {
    this.setData({
      fileId: app.globalData.fileId || ''
    });
  },
  onShow: function onShow() {
    this.setData({
      fileId: app.globalData.fileId || ''
    });
  },
  deleteFile: function deleteFile() {
    var fileId = this.data.fileId;
    if (!fileId) {
      return;
    }
    var self = this;

    this.setData({
      loading: true
    });
    wx.cloud.deleteFile({
      fileList: [fileId],
      success: function success(res) {
        console.log('[删除文件] 成功：', res);
        if (res.fileList && res.fileList.length) {
          self.setData({
            fileId: ''
          });
        }
        app.globalData.fileId = '';
        wx.showToast({
          title: '删除成功'
        });
      },
      fail: function fail(err) {
        console.error('[删除文件] 失败：', err);
      },
      complete: function complete() {
        self.setData({
          loading: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/doc-web-view/doc-web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序云开发文档',
      path: 'page/cloud/pages/doc-web-view/doc-web-view'
    };
  }
});
});
define("packageCloud/pages/download-file/download-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var demoImageFileId = require('../../../config').demoImageFileId;

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-client-api/storage/downloadFile.html

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '下载文件',
      path: 'page/cloud/pages/download-file/download-file'
    };
  },


  data: {
    fileDownloaded: false,
    fileId: '',
    filePath: '',
    loading: false
  },

  onLoad: function onLoad() {
    this.setData({
      fileId: app.globalData.fileId || demoImageFileId
    });
  },
  downloadFile: function downloadFile() {
    var fileId = this.data.fileId;
    if (!fileId) {
      return;
    }
    var self = this;

    this.setData({
      loading: true
    });
    wx.cloud.downloadFile({
      fileID: fileId,
      success: function success(res) {
        console.log('[下载文件] 成功：', res);
        self.setData({
          fileDownloaded: true,
          filePath: res.tempFilePath
        });
      },
      fail: function fail(err) {
        console.error('[下载文件] 失败：', err);
      },
      complete: function complete() {
        self.setData({
          loading: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/get-temp-file-url/get-temp-file-url.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var demoImageFileId = require('../../../config').demoImageFileId;

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-client-api/storage/getTempFileURL.html

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取临时链接',
      path: 'page/cloud/pages/get-temp-file-url/get-temp-file-url'
    };
  },


  data: {
    fileTempURLDone: false,
    fileId: '',
    tempFileURL: '',
    maxAge: 0,
    loading: false
  },

  onLoad: function onLoad() {
    this.setData({
      fileId: app.globalData.fileId || demoImageFileId
    });
  },
  getTempFileURL: function getTempFileURL() {
    var fileId = this.data.fileId;
    if (!fileId) {
      return;
    }
    var self = this;

    this.setData({
      loading: true
    });
    wx.cloud.getTempFileURL({
      fileList: [fileId],
      success: function success(res) {
        console.log('[换取临时链接] 成功：', res);
        if (res.fileList && res.fileList.length) {
          self.setData({
            fileTempURLDone: true,
            tempFileURL: res.fileList[0].tempFileURL,
            maxAge: res.fileList[0].maxAge
          });
        }
      },
      fail: function fail(err) {
        console.error('[换取临时链接] 失败：', err);
      },
      complete: function complete() {
        self.setData({
          loading: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/get-wx-context/get-wx-context.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-server-api/utils/getWXContext.html

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'WXContext',
      path: 'page/cloud/pages/get-wx-context/get-wx-context'
    };
  },


  data: {
    hasWXContext: false,
    wxContext: {},
    loading: false
  },

  getWXContext: function getWXContext() {
    var _this = this;

    this.setData({
      loading: true
    });
    wx.cloud.callFunction({
      name: 'wxContext',
      data: {},
      success: function success(res) {
        console.log('[云函数] [wxContext] wxContext: ', res.result);
        _this.setData({
          hasWXContext: true,
          wxContext: res.result,
          loading: false
        });
      },
      fail: function fail(err) {
        console.error('[云函数] [wxContext] 调用失败', err);
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasWXContext: false,
      wxContext: {}
    });
  }
});
});
define("packageCloud/pages/scf-database/scf-database.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-server-api/database/

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '云函数操作数据库',
      path: 'page/cloud/pages/scf-database/scf-database'
    };
  },


  data: {
    serverDataClient: '',
    serverDataClientError: false,
    serverDataCloud: '',
    serverDataCloudError: false,
    clientLoading: false,
    cloudLoading: false,
    theme: 'light'
  },

  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  queryServerDataViaClient: function queryServerDataViaClient() {
    var _this2 = this;

    var db = wx.cloud.database();
    this.setData({
      clientLoading: true,
      serverDataClient: '',
      serverDataClientError: false
    });
    db.collection('perm4').where({
      _openid: 'server'
    }).get({
      success: function success(res) {
        var resFirstData = res.data && res.data[0] || {};
        _this2.setData({
          serverDataClient: resFirstData.data
        });
        console.log('[数据库] [查询记录] 成功: ', res);
      },
      fail: function fail(err) {
        _this2.setData({
          serverDataClientError: true
        });
        console.error('[数据库] [查询记录] 失败：', err);
      },
      complete: function complete() {
        _this2.setData({
          clientLoading: false
        });
      }
    });
  },
  queryServerDataViaCloudFunction: function queryServerDataViaCloudFunction() {
    var _this3 = this;

    this.setData({
      cloudLoading: true,
      serverDataCloud: '',
      serverDataCloudError: false
    });
    wx.cloud.callFunction({
      name: 'getServerDataDemo',
      data: {},
      success: function success(res) {
        console.log('[云函数] [getServerDataDemo] res: ', res.result);
        var resFirstData = res.result.data && res.result.data[0] || {};
        _this3.setData({
          serverDataCloud: resFirstData.data
        });
      },
      fail: function fail(err) {
        _this3.setData({
          serverDataCloudError: true
        });
        console.error('[云函数] [getServerDataDemo] 调用失败', err);
      },
      complete: function complete() {
        _this3.setData({
          cloudLoading: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/scf-openapi/scf-openapi.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-server-api/database/

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '云函数中使用微信开放能力',
      path: 'page/cloud/pages/scf-openapi/scf-openapi'
    };
  },


  data: {
    sendTemplateMessageResult: '',
    sendTemplateMessageError: false,
    getWXACodeResult: '',
    getWXACodeError: false,
    sendTemplateMessageLoading: false,
    getWXACodeLoading: false,
    theme: 'light'
  },

  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  sendTemplateMessageViaCloudFunction: function sendTemplateMessageViaCloudFunction(e) {
    var _this2 = this;

    this.setData({
      sendTemplateMessageResult: '',
      sendTemplateMessageError: false,
      sendTemplateMessageLoading: true
    });
    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendTemplateMessage',
        formId: e.detail.formId
      }
      // eslint-disable-next-line
    }).then(function (res) {
      _this2.setData({
        sendTemplateMessageResult: res,
        sendTemplateMessageLoading: false
      });
      console.log('[云调用] [发送模板消息] 成功: ', res);
    }).catch(function (err) {
      _this2.setData({
        sendTemplateMessageError: true,
        sendTemplateMessageLoading: false
      });
      console.error('[云调用] [发送模板消息] 失败: ', err);
    });
  },
  getWXACodeViaCloudFunction: function getWXACodeViaCloudFunction() {
    var _this3 = this;

    this.setData({
      getWXACodeResult: '',
      getWXACodeError: false,
      getWXACodeLoading: true
    });
    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'getWXACode'
        // eslint-disable-next-line
      } }).then(function (res) {
      _this3.setData({
        getWXACodeResult: res,
        getWXACodeLoading: false
      });
      console.log('[云调用] [获取小程序码]] 成功: ', res);
    }).catch(function (err) {
      _this3.setData({
        getWXACodeError: true,
        getWXACodeLoading: false
      });
      console.error('[云调用] [获取小程序码] 失败: ', err);
    });
  },
  queryServerDataViaClient: function queryServerDataViaClient() {
    var _this4 = this;

    var db = wx.cloud.database();
    this.setData({
      clientLoading: true,
      serverDataClient: '',
      serverDataClientError: false
    });
    db.collection('perm4').where({
      _openid: 'server'
    }).get({
      success: function success(res) {
        var resFirstData = res.data && res.data[0] || {};
        _this4.setData({
          serverDataClient: resFirstData.data
        });
        console.log('[数据库] [查询记录] 成功: ', res);
      },
      fail: function fail(err) {
        _this4.setData({
          serverDataClientError: true
        });
        console.error('[数据库] [查询记录] 失败：', err);
      },
      complete: function complete() {
        _this4.setData({
          clientLoading: false
        });
      }
    });
  },
  queryServerDataViaCloudFunction: function queryServerDataViaCloudFunction() {
    var _this5 = this;

    this.setData({
      cloudLoading: true,
      serverDataCloud: '',
      serverDataCloudError: false
    });
    wx.cloud.callFunction({
      name: 'getServerDataDemo',
      data: {},
      success: function success(res) {
        console.log('[云函数] [getServerDataDemo] res: ', res.result);
        var resFirstData = res.result.data && res.result.data[0] || {};
        _this5.setData({
          serverDataCloud: resFirstData.data
        });
      },
      fail: function fail(err) {
        _this5.setData({
          serverDataCloudError: true
        });
        console.error('[云函数] [getServerDataDemo] 调用失败', err);
      },
      complete: function complete() {
        _this5.setData({
          cloudLoading: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/scf-storage/scf-storage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var demoImageFileId = require('../../../config').demoImageFileId;

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-server-api/storage/

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '云函数操作存储',
      path: 'page/cloud/pages/scf-storage/scf-storage'
    };
  },


  data: {
    fileTempURLDone: false,
    fileId: '',
    tempFileURL: '',
    loading: false
  },

  onLoad: function onLoad() {
    this.setData({
      fileId: app.globalData.fileId || demoImageFileId
    });
  },
  getTempFileURL: function getTempFileURL() {
    var _this = this;

    var fileId = this.data.fileId;
    if (!fileId) {
      return;
    }

    this.setData({
      loading: true
    });
    wx.cloud.callFunction({
      name: 'getTempFileURL',
      data: {
        fileIdList: [fileId]
      },
      success: function success(res) {
        console.log('[云函数] [getTempFileURL] res: ', res.result);
        if (res.result.length) {
          _this.setData({
            fileTempURLDone: true,
            tempFileURL: res.result[0].tempFileURL
          });
        }
      },
      fail: function fail(err) {
        console.error('[云函数] [getTempFileURL] 调用失败', err);
      },
      complete: function complete() {
        _this.setData({
          loading: false
        });
      }
    });
  }
});
});
define("packageCloud/pages/server-date/server-date.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../util/util.js');

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-client-api/database/db.serverDate.html

var app = getApp();
var collection = 'serverDate';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '服务端时间',
      path: 'page/cloud/pages/server-date/server-date'
    };
  },


  data: {
    openid: '',
    loading: false,
    clientDate: null,
    serverDate: null,
    clientDateFormatted: '',
    serverDateFormatted: '',
    delta: 0
  },

  onLoad: function onLoad() {
    var _this = this;

    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      });
    } else {
      wx.showLoading({
        title: '正在初始化...'
      });
      app.getUserOpenIdViaCloud().then(function (openid) {
        _this.setData({
          openid: openid
        });
        wx.hideLoading();
        return openid;
      }).catch(function (err) {
        console.error(err);
        wx.hideLoading();
        wx.showToast({
          icon: 'none',
          title: '初始化失败，请检查网络'
        });
      });
    }
  },
  showError: function showError() {
    wx.showToast({
      icon: 'none',
      title: '插入失败'
    });
  },
  completeTask: function completeTask() {
    this.setData({
      loading: false
    });
  },


  // 如果已有记录则更新，否则插入
  insertOrUpdateData: function insertOrUpdateData(existedData, data) {
    var _this2 = this;

    var db = wx.cloud.database();
    if (existedData._id) {
      db.collection(collection).doc(existedData._id).update({ data: data }).then(function (res) {
        _this2.setCompletedData(existedData._id);
        return res;
      }).catch(function (err) {
        _this2.showError();
        console.error('[数据库] [更新记录] 失败：', err);
        _this2.completeTask();
      });
    } else {
      db.collection(collection).add({ data: data }).then(function (res) {
        _this2.setCompletedData(res._id);
        return res;
      }).catch(function (err) {
        _this2.showError();
        console.error('[数据库] [新增记录] 失败：', err);
        _this2.completeTask();
      });
    }
  },


  // 查询已插入/更新的数据中记录的服务端时间
  setCompletedData: function setCompletedData(id) {
    var _this3 = this;

    var db = wx.cloud.database();
    db.collection(collection).doc(id).get().then(function (res) {
      _this3.setData({
        delta: Math.abs(res.data.time - _this3.data.clientDate), // 大致的时间差
        serverDate: res.data.time, // 服务端时间
        clientDateFormatted: util.formatDateTime(_this3.data.clientDate, true),
        serverDateFormatted: util.formatDateTime(res.data.time, true)
      });
      wx.showToast({
        title: '插入成功'
      });
      _this3.completeTask();
      return res;
    }).catch(function (err) {
      _this3.showError();
      console.error('[数据库] [查询记录] 失败：', err);
      _this3.completeTask();
    });
  },
  insertData: function insertData() {
    var _this4 = this;

    var db = wx.cloud.database();
    var data = {
      time: db.serverDate()
    };
    this.setData({
      loading: true
    });
    db.collection(collection).where({
      _openid: this.data.openid
    }).get().then(function (res) {
      _this4.setData({
        clientDate: new Date() // 客户端时间
      });
      console.log('[数据库] [查询记录] 成功: ', res);
      var resFirstData = res.data[0] || {};
      _this4.insertOrUpdateData(resFirstData, data);
      return res;
    }).catch(function (err) {
      _this4.showError();
      console.error('[数据库] [查询记录] 失败：', err);
      _this4.completeTask();
    });
  }
});
});
define("packageCloud/pages/upload-file/upload-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// 参考文档：https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-client-api/storage/uploadFile.html

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '上传文件',
      path: 'page/cloud/pages/upload-file/upload-file'
    };
  },


  data: {
    fileUploaded: false,
    fileId: '',
    filePath: '',
    fromOtherPage: false
  },

  onLoad: function onLoad(options) {
    if (options.from) {
      this.setData({
        fromOtherPage: true
      });
    }
  },
  chooseImage: function chooseImage() {
    var self = this;

    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album'],
      success: function success(res) {
        console.log('chooseImage success, temp path is', res.tempFilePaths[0]);
        var filePath = res.tempFilePaths[0];
        wx.showLoading({
          title: '上传中'
        });
        app.getUserOpenIdViaCloud().then(function (openid) {
          var cloudPath = 'upload/' + openid + filePath.match(/\.[^.]+?$/)[0];
          console.log('cloudPath', cloudPath);
          wx.cloud.uploadFile({
            cloudPath: cloudPath,
            filePath: filePath,
            success: function success(res) {
              console.log('[上传文件] 成功：', res);
              app.globalData.fileId = res.fileID;
              self.setData({
                fileUploaded: true,
                fileId: res.fileID,
                filePath: filePath
              });
              wx.hideLoading();
            },
            fail: function fail(err) {
              console.error('[上传文件] 失败：', err);
              wx.hideLoading();
              wx.showToast({
                icon: 'none',
                title: '上传失败'
              });
            }
          });
          return openid;
        }).catch(function (err) {
          console.error(err);
          wx.hideLoading();
        });
      },
      fail: function fail(_ref) {
        var errMsg = _ref.errMsg;

        console.log('chooseImage fail, err is', errMsg);
      }
    });
  }
});
});
define("packageCloud/pages/user-authentication/user-authentication.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '用户鉴权',
      path: 'page/cloud/pages/user-authentication/user-authentication'
    };
  },


  data: {
    openid: '',
    loading: false
  },

  onGetOpenid: function onGetOpenid() {
    var _this = this;

    this.setData({
      loading: true
    });
    app.getUserOpenIdViaCloud().then(function (openid) {
      _this.setData({
        openid: openid,
        loading: false
      });
      return openid;
    }).catch(function (err) {
      console.error(err);
    });
  },
  clear: function clear() {
    this.setData({
      openid: ''
    });
  }
});
});
define("page/API/components/set-tab-bar/set-tab-bar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var defaultTabBarStyle = {
  color: '#7A7E83',
  selectedColor: '#3cc51f',
  backgroundColor: '#ffffff'
};

var defaultItemName = '接口';

Component({
  data: {
    hasSetTabBarBadge: false,
    hasShownTabBarRedDot: false,
    hasCustomedStyle: false,
    hasCustomedItem: false,
    hasHiddenTabBar: false
  },

  attached: function attached() {
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0
    });
  },
  detached: function detached() {
    this.removeTabBarBadge();
    this.hideTabBarRedDot();
    this.showTabBar();
    this.removeCustomStyle();
    this.removeCustomItem();
  },


  methods: {
    navigateBack: function navigateBack() {
      this.triggerEvent('unmount');
    },
    setTabBarBadge: function setTabBarBadge() {
      if (this.data.hasSetTabBarBadge) {
        this.removeTabBarBadge();
        return;
      }
      this.setData({
        hasSetTabBarBadge: true
      });
      wx.setTabBarBadge({
        index: 1,
        text: '1'
      });
    },
    removeTabBarBadge: function removeTabBarBadge() {
      this.setData({
        hasSetTabBarBadge: false
      });
      wx.removeTabBarBadge({
        index: 1
      });
    },
    showTabBarRedDot: function showTabBarRedDot() {
      if (this.data.hasShownTabBarRedDot) {
        this.hideTabBarRedDot();
        return;
      }
      this.setData({
        hasShownTabBarRedDot: true
      });
      wx.showTabBarRedDot({
        index: 1
      });
    },
    hideTabBarRedDot: function hideTabBarRedDot() {
      this.setData({
        hasShownTabBarRedDot: false
      });
      wx.hideTabBarRedDot({
        index: 1
      });
    },
    showTabBar: function showTabBar() {
      this.setData({ hasHiddenTabBar: false });
      wx.showTabBar();
    },
    hideTabBar: function hideTabBar() {
      if (this.data.hasHiddenTabBar) {
        this.showTabBar();
        return;
      }
      this.setData({ hasHiddenTabBar: true });
      wx.hideTabBar();
    },
    customStyle: function customStyle() {
      if (this.data.hasCustomedStyle) {
        this.removeCustomStyle();
        return;
      }
      this.setData({ hasCustomedStyle: true });
      wx.setTabBarStyle({
        color: '#FFF',
        selectedColor: '#1AAD19',
        backgroundColor: '#000000'
      });
    },
    removeCustomStyle: function removeCustomStyle() {
      this.setData({ hasCustomedStyle: false });
      wx.setTabBarStyle(defaultTabBarStyle);
    },
    customItem: function customItem() {
      if (this.data.hasCustomedItem) {
        this.removeCustomItem();
        return;
      }
      this.setData({ hasCustomedItem: true });
      wx.setTabBarItem({
        index: 1,
        text: 'API'
      });
    },
    removeCustomItem: function removeCustomItem() {
      this.setData({ hasCustomedItem: false });
      wx.setTabBarItem({
        index: 1,
        text: defaultItemName
      });
    }
  }
});
});
define("page/component/pages/official-account/official-account.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

// miniprogram/page/component/pages/official-account/official-account.js
Page({

  /**
   * 页面的初始数据
   */
  data: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});
define("page/component/pages/video/picture-in-picture.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {},
  onLoad: function onLoad(options) {},
  onReady: function onReady() {},
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小窗模式',
      path: 'page/component/pages/picture-in-picture/picture-in-picture'
    };
  }
}
// onShareAppMessage() {
//   return {
//     title: 'video',
//     path: 'page/component/pages/video/video'
//   }
// },
);
});
define("page/weui/base/behaviors/theme.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

module.exports = Behavior({
    data: {
        theme: 'light'
    },
    methods: {
        themeChanged: function themeChanged(theme) {
            this.setData({
                theme: theme
            });
        }
    }
});
});
define("page/weui/base/CustomPage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _theme = require('./behaviors/theme');

var _theme2 = _interopRequireDefault(_theme);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CustomPage = function CustomPage(options) {
	return Page(Object.assign({}, options, {
		behaviors: [_theme2.default].concat(options.behaviors || []),
		onLoad: function onLoad(query) {
			var app = getApp();
			if (this.themeChanged) {
				this.themeChanged(app.globalData.theme);
				app.watchThemeChange && app.watchThemeChange(this.themeChanged);
				options.onLoad && options.onLoad.call(this, query);
			}
		},
		onUnload: function onUnload() {
			var app = getApp();
			if (this.themeChanged) {
				app.unWatchThemeChange && app.unWatchThemeChange(this.themeChanged);
				options.onUnload && options.onUnload.call(this);
			}
		}
	}));
};

exports.default = CustomPage;
});
define("page/weui/example/barrage/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var msgs = ['666666', '保护', '妈妈我上电视了！！', '我要上电视！！', '老板晚上好', '前方高能预警', '主播迟到了~~~', '干的漂亮', '广东人民发来贺电'];

var color = ['red', 'rgb(0, 255, 0)', '#0000FF'];

var getRandom = function getRandom() {
  var max = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 10;
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  return Math.floor(Math.random() * (max - min) + min);
};

var mockData = function mockData(num) {
  var message = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : msgs;

  var data = [];
  for (var i = 0; i < num; i++) {
    var msgId = getRandom(message.length);
    var colorId = getRandom(color.length);
    data.push({
      content: message[msgId],
      color: color[colorId]
    });
  }
  return data;
};

module.exports = {
  mockData: mockData
};
});
define("page/weui/example/button/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'button',
      path: 'page/weui/example/button/button'
    };
  }
});
});
define("page/weui/example/images/base64.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

module.exports = {
    icon20: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAMAAABgZ9sFAAAAVFBMVEXx8fHMzMzr6+vn5+fv7+/t7e3d3d2+vr7W1tbHx8eysrKdnZ3p6enk5OTR0dG7u7u3t7ejo6PY2Njh4eHf39/T09PExMSvr6+goKCqqqqnp6e4uLgcLY/OAAAAnklEQVRIx+3RSRLDIAxE0QYhAbGZPNu5/z0zrXHiqiz5W72FqhqtVuuXAl3iOV7iPV/iSsAqZa9BS7YOmMXnNNX4TWGxRMn3R6SxRNgy0bzXOW8EBO8SAClsPdB3psqlvG+Lw7ONXg/pTld52BjgSSkA3PV2OOemjIDcZQWgVvONw60q7sIpR38EnHPSMDQ4MjDjLPozhAkGrVbr/z0ANjAF4AcbXmYAAAAASUVORK5CYII=",
    icon60: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAMAAAAOusbgAAAAeFBMVEUAwAD///+U5ZTc9twOww7G8MYwzDCH4YcfyR9x23Hw+/DY9dhm2WZG0kbT9NP0/PTL8sux7LFe115T1VM+zz7i+OIXxhes6qxr2mvA8MCe6J6M4oz6/frr+us5zjn2/fa67rqB4IF13XWn6ad83nxa1loqyirn+eccHxx4AAAC/klEQVRo3u2W2ZKiQBBF8wpCNSCyLwri7v//4bRIFVXoTBBB+DAReV5sG6lTXDITiGEYhmEYhmEYhmEYhmEY5v9i5fsZGRx9PyGDne8f6K9cfd+mKXe1yNG/0CcqYE86AkBMBh66f20deBc7wA/1WFiTwvSEpBMA2JJOBsSLxe/4QEEaJRrASP8EVF8Q74GbmevKg0saa0B8QbwBdjRyADYxIhqxAZ++IKYtciPXLQVG+imw+oo4Bu56rjEJ4GYsvPmKOAB+xlz7L5aevqUXuePWVhvWJ4eWiwUQ67mK51qPj4dFDMlRLBZTqF3SDvmr4BwtkECu5gHWPkmDfQh02WLxXuvbvC8ku8F57GsI5e0CmUwLz1kq3kD17R1In5816rGvQ5VMk5FEtIiWislTffuDpl/k/PzscdQsv8r9qWq4LRWX6tQYtTxvI3XyrwdyQxChXioOngH3dLgOFjk0all56XRi/wDFQrGQU3Os5t0wJu1GNtNKHdPqYaGYQuRDfbfDf26AGLYSyGS3ZAK4S8XuoAlxGSdYMKwqZKM9XJMtyqXi7HX/CiAZS6d8bSVUz5J36mEMFDTlAFQzxOT1dzLRljjB6+++ejFqka+mXIe6F59mw22OuOw1F4T6lg/9VjL1rLDoI9Xzl1MSYDNHnPQnt3D1EE7PrXjye/3pVpr1Z45hMUdcACc5NVQI0bOdS1WA0wuz73e7/5TNqBPhQXPEFGJNV2zNqWI7QKBd2Gn6AiBko02zuAOXeWIXjV0jNqdKegaE/kJQ6Bfs4aju04lMLkA2T5wBSYPKDGF3RKhFYEa6A1L1LG2yacmsaZ6YPOSAMKNsO+N5dNTfkc5Aqe26uxHpx7ZirvgCwJpWq/lmX1hA7LyabQ34tt5RiJKXSwQ+0KU0V5xg+hZrd4Bn1n4EID+WkQdgLfRNtvil9SPfwy+WQ7PFBWQz6dGWZBLkeJFXZGCfLUjCgGgqXo5TuSu3cugdcTv/HjqnBTEMwzAMwzAMwzAMwzAMw/zf/AFbXiOA6frlMAAAAABJRU5ErkJggg=="
};
});
define("page/weui/example/input/input.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Component({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'input',
            path: 'page/weui/example/input/input'
        };
    },

    data: {
        showTopTips: false,

        radioItems: [{ name: 'cell standard', value: '0', checked: true }, { name: 'cell standard', value: '1' }],
        checkboxItems: [{ name: 'standard is dealt for u.', value: '0', checked: true }, { name: 'standard is dealicient for u.', value: '1' }],
        items: [{ name: 'USA', value: '美国' }, { name: 'CHN', value: '中国', checked: 'true' }, { name: 'BRA', value: '巴西' }, { name: 'JPN', value: '日本' }, { name: 'ENG', value: '英国' }, { name: 'TUR', value: '法国' }],

        date: "2016-09-01",
        time: "12:01",

        countryCodes: ["+86", "+80", "+84", "+87"],
        countryCodeIndex: 0,

        countries: ["中国", "美国", "英国"],
        countryIndex: 0,

        accounts: ["微信号", "QQ", "Email"],
        accountIndex: 0,

        isAgree: false,
        formData: {},
        rules: [{
            name: 'radio',
            rules: { required: true, message: '单选列表是必选项' }
        }, {
            name: 'checkbox',
            rules: { required: true, message: '多选列表是必选项' }
        }, {
            name: 'qq',
            rules: { required: true, message: 'qq必填' }
        }, {
            name: 'mobile',
            rules: [{ required: true, message: 'mobile必填' }, { mobile: true, message: 'mobile格式不对' }]
        }, {
            name: 'vcode',
            rules: { required: true, message: '验证码必填' }
        }, {
            name: 'idcard',
            rules: { required: true, message: 'idcard必填' }
        }]
    },
    methods: {
        radioChange: function radioChange(e) {
            console.log('radio发生change事件，携带value值为：', e.detail.value);

            var radioItems = this.data.radioItems;
            for (var i = 0, len = radioItems.length; i < len; ++i) {
                radioItems[i].checked = radioItems[i].value == e.detail.value;
            }

            this.setData(_defineProperty({
                radioItems: radioItems
            }, 'formData.radio', e.detail.value));
        },
        checkboxChange: function checkboxChange(e) {
            console.log('checkbox发生change事件，携带value值为：', e.detail.value);

            var checkboxItems = this.data.checkboxItems,
                values = e.detail.value;
            for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
                checkboxItems[i].checked = false;

                for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
                    if (checkboxItems[i].value == values[j]) {
                        checkboxItems[i].checked = true;
                        break;
                    }
                }
            }

            this.setData(_defineProperty({
                checkboxItems: checkboxItems
            }, 'formData.checkbox', e.detail.value));
        },
        bindDateChange: function bindDateChange(e) {
            this.setData(_defineProperty({
                date: e.detail.value
            }, 'formData.date', e.detail.value));
        },
        formInputChange: function formInputChange(e) {
            var field = e.currentTarget.dataset.field;

            this.setData(_defineProperty({}, 'formData.' + field, e.detail.value));
        },

        bindTimeChange: function bindTimeChange(e) {
            this.setData({
                time: e.detail.value
            });
        },
        bindCountryCodeChange: function bindCountryCodeChange(e) {
            console.log('picker country code 发生选择改变，携带值为', e.detail.value);

            this.setData({
                countryCodeIndex: e.detail.value
            });
        },
        bindCountryChange: function bindCountryChange(e) {
            console.log('picker country 发生选择改变，携带值为', e.detail.value);

            this.setData({
                countryIndex: e.detail.value
            });
        },
        bindAccountChange: function bindAccountChange(e) {
            console.log('picker account 发生选择改变，携带值为', e.detail.value);

            this.setData({
                accountIndex: e.detail.value
            });
        },
        bindAgreeChange: function bindAgreeChange(e) {
            this.setData({
                isAgree: !!e.detail.value.length
            });
        },
        submitForm: function submitForm() {
            var _this = this;

            this.selectComponent('#form').validate(function (valid, errors) {
                console.log('valid', valid, errors);
                if (!valid) {
                    var firstError = Object.keys(errors);
                    if (firstError.length) {
                        _this.setData({
                            error: errors[firstError[0]].message
                        });
                    }
                } else {
                    wx.showToast({
                        title: '校验通过'
                    });
                }
            });
        }
    }
});
});
define("page/weui/example/list/list.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var base64 = require("../images/base64");
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'list',
      path: 'page/weui/example/list/list'
    };
  },

  onLoad: function onLoad() {
    this.setData({
      icon: base64.icon20,
      slideButtons: [{
        text: '删除',
        extClass: 'delete'
      }, {
        text: '测试测试',
        extClass: 'test'
      }]
    });
  },
  slideButtonTap: function slideButtonTap(e) {
    console.log('slide button tap', e.detail);
  }
});
});
define("page/weui/example/picker/picker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'picker',
            path: 'page/weui/example/picker/picker'
        };
    },

    data: {
        array: ['美国', '中国', '巴西', '日本'],
        index: 0,
        date: '2016-09-01',
        time: '12:01'
    },
    bindPickerChange: function bindPickerChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            index: e.detail.value
        });
    },
    bindDateChange: function bindDateChange(e) {
        this.setData({
            date: e.detail.value
        });
    },
    bindTimeChange: function bindTimeChange(e) {
        this.setData({
            time: e.detail.value
        });
    }
});
});
define("page/weui/example/progress/progress.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function _next() {
    var that = this;
    if (this.data.progress >= 100) {
        this.setData({
            disabled: false
        });
        return true;
    }
    this.setData({
        progress: ++this.data.progress
    });
    setTimeout(function () {
        _next.call(that);
    }, 20);
}

Page({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'progress',
            path: 'page/weui/example/progress/progress'
        };
    },

    data: {
        progress: 0,
        disabled: false
    },
    upload: function upload() {
        if (this.data.disabled) return;

        this.setData({
            progress: 0,
            disabled: true
        });
        _next.call(this);
    }
});
});
define("page/weui/example/slider/slider.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'slider',
      path: 'page/weui/example/slider/slider'
    };
  }
});
});
define("page/weui/example/tabs/webview.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _Page;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// miniprogram/page/weui/example/tabs/webview.js
Page((_Page = {

  /**
   * 页面的初始数据
   */
  onLoad: function onLoad(option) {
    // const { query } = option;
    // this.setData({
    //   src: query.url
    // })
  },
  data: {
    src: 'https://developers.weixin.qq.com/community/business'
  }

}, _defineProperty(_Page, 'onLoad', function onLoad(options) {}), _defineProperty(_Page, 'onReady', function onReady() {}), _defineProperty(_Page, 'onShow', function onShow() {}), _defineProperty(_Page, 'onHide', function onHide() {}), _defineProperty(_Page, 'onUnload', function onUnload() {}), _defineProperty(_Page, 'onPullDownRefresh', function onPullDownRefresh() {}), _defineProperty(_Page, 'onReachBottom', function onReachBottom() {}), _defineProperty(_Page, 'onShareAppMessage', function onShareAppMessage() {
  return {
    title: 'webview',
    path: 'page/weui/example/webview/webview'
  };
}), _Page));
});
define("page/weui/example/toast/toast.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'toast',
            path: 'page/weui/example/toast/toast'
        };
    },

    openToast: function openToast() {
        wx.showToast({
            title: '已完成',
            icon: 'success',
            duration: 3000
        });
    },
    openLoading: function openLoading() {
        wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 3000
        });
    }
});
});
define("page/weui/example/wxml-to-canvas/demo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var wxml = function wxml(url) {
  return '<view class="container">\n  <image class="img" mode="aspectFit" src="' + url + '"></image>\n  <text class="title">\n    \u5FAE\u4FE1\u5F00\u653E\u793E\u533A\u7B80\u4ECB\uFF08\u89C6\u9891\uFF09\n  </text>\n  <text class="desc">\n    \u5FAE\u4FE1\u5F00\u653E\u793E\u533A\uFF0C\u662F\u4E00\u4E2A\u4E3A\u4F7F\u7528\u8005\u63D0\u4F9B\u4EA4\u6D41\u3001\u670D\u52A1\u7684\u5E73\u53F0\u3002\n  </text>\n</view>\n';
};

var style = {

  img: {
    width: 200,
    height: 120
  },
  container: {
    height: 200,
    width: 200,
    flexDirection: 'column'
  },
  title: {
    height: 20,
    width: 200,
    color: '#15c15f',
    margin: 4

  },
  desc: {
    fontSize: 13,
    height: 40,
    width: 200,
    color: '#4c4c4c',
    margin: 4
  }
};

module.exports = {
  wxml: wxml,
  style: style
};
});
define("util/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function formatTime(time) {
  if (typeof time !== 'number' || time < 0) {
    return time;
  }

  var hour = parseInt(time / 3600, 10);
  time %= 3600;
  var minute = parseInt(time / 60, 10);
  time = parseInt(time % 60, 10);
  var second = time;

  return [hour, minute, second].map(function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  }).join(':');
}

function formatLocation(longitude, latitude) {
  if (typeof longitude === 'string' && typeof latitude === 'string') {
    longitude = parseFloat(longitude);
    latitude = parseFloat(latitude);
  }

  longitude = longitude.toFixed(2);
  latitude = latitude.toFixed(2);

  return {
    longitude: longitude.toString().split('.'),
    latitude: latitude.toString().split('.')
  };
}

function fib(n) {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fib(n - 1) + fib(n - 2);
}

function formatLeadingZeroNumber(n) {
  var digitNum = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

  n = n.toString();
  var needNum = Math.max(digitNum - n.length, 0);
  return new Array(needNum).fill(0).join('') + n;
}

function formatDateTime(date) {
  var withMs = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var ms = date.getMilliseconds();

  var ret = [year, month, day].map(function (value) {
    return formatLeadingZeroNumber(value, 2);
  }).join('-') + ' ' + [hour, minute, second].map(function (value) {
    return formatLeadingZeroNumber(value, 2);
  }).join(':');
  if (withMs) {
    ret += '.' + formatLeadingZeroNumber(ms, 3);
  }
  return ret;
}

function compareVersion(v1, v2) {
  v1 = v1.split('.');
  v2 = v2.split('.');
  var len = Math.max(v1.length, v2.length);

  while (v1.length < len) {
    v1.push('0');
  }
  while (v2.length < len) {
    v2.push('0');
  }

  for (var i = 0; i < len; i++) {
    var num1 = parseInt(v1[i], 10);
    var num2 = parseInt(v2[i], 10);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }

  return 0;
}

module.exports = {
  formatTime: formatTime,
  formatLocation: formatLocation,
  fib: fib,
  formatDateTime: formatDateTime,
  compareVersion: compareVersion
};
});
define("workers/fib/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function fib(n) {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fib(n - 1) + fib(n - 2);
}

worker.onMessage(function (msg) {
  if (msg.type === 'execFunc_fib') {
    worker.postMessage({
      type: 'execFunc_fib',
      result: fib(msg.params[0])
    });
  }
});
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var config = require('./config');
var themeListeners = [];
global.isDemo = true;
App({
  onLaunch: function onLaunch(opts, data) {
    var that = this;
    var canIUseSetBackgroundFetchToken = wx.canIUse('setBackgroundFetchToken');
    if (canIUseSetBackgroundFetchToken) {
      wx.setBackgroundFetchToken({
        token: 'getBackgroundFetchToken'
      });
    }
    if (wx.getBackgroundFetchData) {
      wx.getBackgroundFetchData({
        fetchType: 'pre',
        success: function success(res) {
          that.globalData.backgroundFetchData = res;
          console.log('读取预拉取数据成功');
        },
        fail: function fail() {
          console.log('读取预拉取数据失败');
          wx.showToast({
            title: '无缓存数据',
            icon: 'none'
          });
        },
        complete: function complete() {
          console.log('结束读取');
        }
      });
    }
    console.log('App Launch', opts);
    if (data && data.path) {
      wx.navigateTo({
        url: data.path
      });
    }
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
    } else {
      wx.cloud.init({
        env: config.envId,
        traceUser: true
      });
    }
  },
  onShow: function onShow(opts) {
    console.log('App Show', opts);
    // console.log(wx.getSystemInfoSync())
  },
  onHide: function onHide() {
    console.log('App Hide');
  },
  onThemeChange: function onThemeChange(_ref) {
    var theme = _ref.theme;

    this.globalData.theme = theme;
    themeListeners.forEach(function (listener) {
      listener(theme);
    });
  },
  watchThemeChange: function watchThemeChange(listener) {
    if (themeListeners.indexOf(listener) < 0) {
      themeListeners.push(listener);
    }
  },
  unWatchThemeChange: function unWatchThemeChange(listener) {
    var index = themeListeners.indexOf(listener);
    if (index > -1) {
      themeListeners.splice(index, 1);
    }
  },

  globalData: {
    theme: wx.getSystemInfoSync().theme,
    hasLogin: false,
    openid: null,
    iconTabbar: '/page/weui/example/images/icon_tabbar.png'
  },
  // lazy loading openid
  getUserOpenId: function getUserOpenId(callback) {
    var self = this;

    if (self.globalData.openid) {
      callback(null, self.globalData.openid);
    } else {
      wx.login({
        success: function success(data) {
          wx.cloud.callFunction({
            name: 'login',
            data: {
              action: 'openid'
            },
            success: function success(res) {
              console.log('拉取openid成功', res);
              self.globalData.openid = res.result.openid;
              callback(null, self.globalData.openid);
            },
            fail: function fail(err) {
              console.log('拉取用户openid失败，将无法正常使用开放接口等服务', res);
              callback(res);
            }
          });
        },
        fail: function fail(err) {
          console.log('wx.login 接口调用失败，将无法正常使用开放接口等服务', err);
          callback(err);
        }
      });
    }
  },

  // 通过云函数获取用户 openid，支持回调或 Promise
  getUserOpenIdViaCloud: function getUserOpenIdViaCloud() {
    var _this = this;

    return wx.cloud.callFunction({
      name: 'wxContext',
      data: {}
    }).then(function (res) {
      _this.globalData.openid = res.result.openid;
      return res.result.openid;
    });
  }
});
});require("app.js")
var __wxRoute = "page/component/index", __wxRouteBegin = true;
define("page/component/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShow: function onShow() {
    wx.reportAnalytics('enter_home_programmatically', {});
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序官方组件展示',
      path: 'page/component/index'
    };
  },


  data: {
    list: [{
      id: 'view',
      name: '视图容器',
      open: false,
      pages: ['view', 'scroll-view', 'swiper', 'movable-view', 'cover-view']
    }, {
      id: 'content',
      name: '基础内容',
      open: false,
      pages: ['text', 'icon', 'progress', 'rich-text']
    }, {
      id: 'form',
      name: '表单组件',
      open: false,
      pages: ['button', 'checkbox', 'form', 'input', 'label', 'picker', 'picker-view', 'radio', 'slider', 'switch', 'textarea', 'editor']
    }, {
      id: 'nav',
      name: '导航',
      open: false,
      pages: ['navigator']
    }, {
      id: 'media',
      name: '媒体组件',
      open: false,
      pages: ['image', 'video', 'camera', 'live-pusher', 'live-player']
    }, {
      id: 'map',
      name: '地图',
      open: false,
      pages: ['map']
    }, {
      id: 'canvas',
      name: '画布',
      open: false,
      pages: ['canvas', 'canvas-2d', 'webgl']
    }, {
      id: 'open',
      name: '开放能力',
      open: false,
      pages: ['ad', 'open-data', 'web-view']
    }, {
      id: 'obstacle-free',
      name: '无障碍访问',
      open: false,
      pages: ['aria-component']
    }],
    theme: 'light'
  },

  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  kindToggle: function kindToggle(e) {
    var id = e.currentTarget.id;
    var list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id === id) {
        list[i].open = !list[i].open;
      } else {
        list[i].open = false;
      }
    }
    this.setData({
      list: list
    });
    wx.reportAnalytics('click_view_programmatically', {});
  }
});
});require("page/component/index.js")
var __wxRoute = "page/component/pages/view/view", __wxRouteBegin = true;
define("page/component/pages/view/view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'view',
      path: 'page/component/pages/view/view'
    };
  }
});
});require("page/component/pages/view/view.js")
var __wxRoute = "page/component/pages/scroll-view/scroll-view", __wxRouteBegin = true;
define("page/component/pages/scroll-view/scroll-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var order = ['demo1', 'demo2', 'demo3'];

Page({
  onLoad: function onLoad() {
    this.animate('#scroll-sample-object1', [{
      borderRadius: '0',
      offset: 0
    }, {
      borderRadius: '25%',
      offset: .5
    }, {
      borderRadius: '50%',
      offset: 1
    }], 2000, {
      scrollSource: '#scroll-view_D',
      timeRange: 2000,
      startScrollOffset: 0,
      endScrollOffset: 150
    });

    this.animate('#scroll-sample-object2', [{
      opacity: 1,
      offset: 0
    }, {
      opacity: .5,
      offset: .5
    }, {
      opacity: .3,
      offset: 1
    }], 2000, {
      scrollSource: '#scroll-view_D',
      timeRange: 2000,
      startScrollOffset: 150,
      endScrollOffset: 300
    });

    this.animate('#scroll-sample-object3', [{
      background: "white",
      offset: 0
    }, {
      background: "yellow",
      offset: 1
    }], 2000, {
      scrollSource: '#scroll-view_D',
      timeRange: 2000,
      startScrollOffset: 300,
      endScrollOffset: 400
    });
  },
  onPulling: function onPulling(e) {
    console.log('onPulling:', e);
  },
  onRefresh: function onRefresh() {
    var _this = this;

    if (this._freshing) return;
    this._freshing = true;
    setTimeout(function () {
      _this.setData({
        triggered: false
      });
      _this._freshing = false;
    }, 3000);
  },
  onRestore: function onRestore(e) {
    console.log('onRestore:', e);
  },
  onAbort: function onAbort(e) {
    console.log('onAbort', e);
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'scroll-view',
      path: 'page/component/pages/scroll-view/scroll-view'
    };
  },


  data: {
    toView: 'green',
    triggered: false
  },

  upper: function upper(e) {
    console.log(e);
  },
  lower: function lower(e) {
    console.log(e);
  },
  scroll: function scroll(e) {
    console.log(e);
  },
  scrollToTop: function scrollToTop() {
    this.setAction({
      scrollTop: 0
    });
  },
  tap: function tap() {
    for (var i = 0; i < order.length; ++i) {
      if (order[i] === this.data.toView) {
        this.setData({
          toView: order[i + 1],
          scrollTop: (i + 1) * 200
        });
        break;
      }
    }
  },
  tapMove: function tapMove() {
    this.setData({
      scrollTop: this.data.scrollTop + 10
    });
  }
});
});require("page/component/pages/scroll-view/scroll-view.js")
var __wxRoute = "page/component/pages/swiper/swiper", __wxRouteBegin = true;
define("page/component/pages/swiper/swiper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'swiper',
      path: 'page/component/pages/swiper/swiper'
    };
  },


  data: {
    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
    indicatorDots: true,
    vertical: false,
    autoplay: false,
    interval: 2000,
    duration: 500
  },

  changeIndicatorDots: function changeIndicatorDots() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    });
  },
  changeAutoplay: function changeAutoplay() {
    this.setData({
      autoplay: !this.data.autoplay
    });
  },
  intervalChange: function intervalChange(e) {
    this.setData({
      interval: e.detail.value
    });
  },
  durationChange: function durationChange(e) {
    this.setData({
      duration: e.detail.value
    });
  }
});
});require("page/component/pages/swiper/swiper.js")
var __wxRoute = "page/component/pages/text/text", __wxRouteBegin = true;
define("page/component/pages/text/text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var texts = ['2011年1月，微信1.0发布', '同年5月，微信2.0语音对讲发布', '10月，微信3.0新增摇一摇功能', '2012年3月，微信用户突破1亿', '4月份，微信4.0朋友圈发布', '同年7月，微信4.2发布公众平台', '2013年8月，微信5.0发布微信支付', '2014年9月，企业号发布', '同月，发布微信卡包', '2015年1月，微信第一条朋友圈广告', '2016年1月，企业微信发布', '2017年1月，小程序发布', '......'];

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'text',
      path: 'page/component/pages/text/text'
    };
  },


  data: {
    text: '',
    canAdd: true,
    canRemove: false
  },
  extraLine: [],

  add: function add() {
    var _this = this;

    this.extraLine.push(texts[this.extraLine.length % 12]);
    this.setData({
      text: this.extraLine.join('\n'),
      canAdd: this.extraLine.length < 12,
      canRemove: this.extraLine.length > 0
    });
    setTimeout(function () {
      _this.setData({
        scrollTop: 99999
      });
    }, 0);
  },
  remove: function remove() {
    var _this2 = this;

    if (this.extraLine.length > 0) {
      this.extraLine.pop();
      this.setData({
        text: this.extraLine.join('\n'),
        canAdd: this.extraLine.length < 12,
        canRemove: this.extraLine.length > 0
      });
    }
    setTimeout(function () {
      _this2.setData({
        scrollTop: 99999
      });
    }, 0);
  }
});
});require("page/component/pages/text/text.js")
var __wxRoute = "page/component/pages/icon/icon", __wxRouteBegin = true;
define("page/component/pages/icon/icon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'icon',
      path: 'page/component/pages/icon/icon'
    };
  }
});
});require("page/component/pages/icon/icon.js")
var __wxRoute = "page/component/pages/progress/progress", __wxRouteBegin = true;
define("page/component/pages/progress/progress.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'progress',
      path: 'page/component/pages/progress/progress'
    };
  }
});
});require("page/component/pages/progress/progress.js")
var __wxRoute = "page/component/pages/button/button", __wxRouteBegin = true;
define("page/component/pages/button/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var types = ['default', 'primary', 'warn'];
var pageObject = _defineProperty({
  data: {
    defaultSize: 'default',
    primarySize: 'default',
    warnSize: 'default',
    disabled: false,
    plain: false,
    loading: false
  },

  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'button',
      path: 'page/component/pages/button/button'
    };
  },
  setDisabled: function setDisabled() {
    this.setData({
      disabled: !this.data.disabled
    });
  },
  setPlain: function setPlain() {
    this.setData({
      plain: !this.data.plain
    });
  },
  setLoading: function setLoading() {
    this.setData({
      loading: !this.data.loading
    });
  },
  handleContact: function handleContact(e) {
    console.log(e.detail);
  },
  handleGetPhoneNumber: function handleGetPhoneNumber(e) {
    console.log(e.detail);
  },
  handleGetUserInfo: function handleGetUserInfo(e) {
    console.log(e.detail);
  },
  handleOpenSetting: function handleOpenSetting(e) {
    console.log(e.detail.authSetting);
  }
}, 'handleGetUserInfo', function handleGetUserInfo(e) {
  console.log(e.detail.userInfo);
});

for (var i = 0; i < types.length; ++i) {
  (function (type) {
    pageObject[type] = function () {
      var key = type + 'Size';
      var changedData = {};
      changedData[key] = this.data[key] === 'default' ? 'mini' : 'default';
      this.setData(changedData);
    };
  })(types[i]);
}

Page(pageObject);
});require("page/component/pages/button/button.js")
var __wxRoute = "page/component/pages/checkbox/checkbox", __wxRouteBegin = true;
define("page/component/pages/checkbox/checkbox.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'checkbox',
      path: 'page/component/pages/checkbox/checkbox'
    };
  },


  data: {
    items: [{ value: 'USA', name: '美国' }, { value: 'CHN', name: '中国', checked: 'true' }, { value: 'BRA', name: '巴西' }, { value: 'JPN', name: '日本' }, { value: 'ENG', name: '英国' }, { value: 'FRA', name: '法国' }]
  },

  checkboxChange: function checkboxChange(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);

    var items = this.data.items;
    var values = e.detail.value;
    for (var i = 0, lenI = items.length; i < lenI; ++i) {
      items[i].checked = false;

      for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
        if (items[i].value === values[j]) {
          items[i].checked = true;
          break;
        }
      }
    }

    this.setData({
      items: items
    });
  }
});
});require("page/component/pages/checkbox/checkbox.js")
var __wxRoute = "page/component/pages/form/form", __wxRouteBegin = true;
define("page/component/pages/form/form.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'form',
      path: 'page/component/pages/form/form'
    };
  },


  data: {
    pickerHidden: true,
    chosen: ''
  },

  pickerConfirm: function pickerConfirm(e) {
    this.setData({
      pickerHidden: true
    });
    this.setData({
      chosen: e.detail.value
    });
  },
  pickerCancel: function pickerCancel() {
    this.setData({
      pickerHidden: true
    });
  },
  pickerShow: function pickerShow() {
    this.setData({
      pickerHidden: false
    });
  },
  formSubmit: function formSubmit(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
  },
  formReset: function formReset(e) {
    console.log('form发生了reset事件，携带数据为：', e.detail.value);
    this.setData({
      chosen: ''
    });
  }
});
});require("page/component/pages/form/form.js")
var __wxRoute = "page/component/pages/input/input", __wxRouteBegin = true;
define("page/component/pages/input/input.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'input',
      path: 'page/component/pages/input/input'
    };
  },


  data: {
    focus: false,
    inputValue: ''
  },

  bindKeyInput: function bindKeyInput(e) {
    this.setData({
      inputValue: e.detail.value
    });
  },
  bindReplaceInput: function bindReplaceInput(e) {
    var value = e.detail.value;
    var pos = e.detail.cursor;
    var left = void 0;
    if (pos !== -1) {
      // 光标在中间
      left = e.detail.value.slice(0, pos);
      // 计算光标的位置
      pos = left.replace(/11/g, '2').length;
    }

    // 直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
    return {
      value: value.replace(/11/g, '2'),
      cursor: pos

      // 或者直接返回字符串,光标在最后边
      // return value.replace(/11/g,'2'),
    };
  },
  bindHideKeyboard: function bindHideKeyboard(e) {
    if (e.detail.value === '123') {
      // 收起键盘
      wx.hideKeyboard();
    }
  }
});
});require("page/component/pages/input/input.js")
var __wxRoute = "page/component/pages/label/label", __wxRouteBegin = true;
define("page/component/pages/label/label.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'label',
      path: 'page/component/pages/label/label'
    };
  },


  data: {
    checkboxItems: [{ name: 'USA', value: '美国' }, { name: 'CHN', value: '中国', checked: 'true' }],
    radioItems: [{ name: 'USA', value: '美国' }, { name: 'CHN', value: '中国', checked: 'true' }],
    hidden: false
  },

  checkboxChange: function checkboxChange(e) {
    var checked = e.detail.value;
    var changed = {};
    for (var i = 0; i < this.data.checkboxItems.length; i++) {
      if (checked.indexOf(this.data.checkboxItems[i].name) !== -1) {
        changed['checkboxItems[' + i + '].checked'] = true;
      } else {
        changed['checkboxItems[' + i + '].checked'] = false;
      }
    }
    this.setData(changed);
  },
  radioChange: function radioChange(e) {
    var checked = e.detail.value;
    var changed = {};
    for (var i = 0; i < this.data.radioItems.length; i++) {
      if (checked.indexOf(this.data.radioItems[i].name) !== -1) {
        changed['radioItems[' + i + '].checked'] = true;
      } else {
        changed['radioItems[' + i + '].checked'] = false;
      }
    }
    this.setData(changed);
  },
  tapEvent: function tapEvent() {
    console.log('按钮被点击');
  }
});
});require("page/component/pages/label/label.js")
var __wxRoute = "page/component/pages/picker/picker", __wxRouteBegin = true;
define("page/component/pages/picker/picker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'picker',
      path: 'page/component/pages/picker/picker'
    };
  },


  data: {
    array: ['中国', '美国', '巴西', '日本'],
    index: 0,
    date: '2016-09-01',
    time: '12:01'
  },

  bindPickerChange: function bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      index: e.detail.value
    });
  },
  bindDateChange: function bindDateChange(e) {
    this.setData({
      date: e.detail.value
    });
  },
  bindTimeChange: function bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    });
  }
});
});require("page/component/pages/picker/picker.js")
var __wxRoute = "page/component/pages/radio/radio", __wxRouteBegin = true;
define("page/component/pages/radio/radio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'radio',
      path: 'page/component/pages/radio/radio'
    };
  },


  data: {
    items: [{ value: 'USA', name: '美国' }, { value: 'CHN', name: '中国', checked: 'true' }, { value: 'BRA', name: '巴西' }, { value: 'JPN', name: '日本' }, { value: 'ENG', name: '英国' }, { value: 'FRA', name: '法国' }]
  },

  radioChange: function radioChange(e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value);

    var items = this.data.items;
    for (var i = 0, len = items.length; i < len; ++i) {
      items[i].checked = items[i].value === e.detail.value;
    }

    this.setData({
      items: items
    });
  }
});
});require("page/component/pages/radio/radio.js")
var __wxRoute = "page/component/pages/slider/slider", __wxRouteBegin = true;
define("page/component/pages/slider/slider.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var pageData = {
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'slider',
      path: 'page/component/pages/slider/slider'
    };
  }
};

for (var i = 1; i < 5; ++i) {
  (function (index) {
    pageData['slider' + index + 'change'] = function (e) {
      console.log('slider' + index + '发生change事件，携带值为', e.detail.value);
    };
  })(i);
}

Page(pageData);
});require("page/component/pages/slider/slider.js")
var __wxRoute = "page/component/pages/switch/switch", __wxRouteBegin = true;
define("page/component/pages/switch/switch.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'switch',
      path: 'page/component/pages/switch/switch'
    };
  },
  switch1Change: function switch1Change(e) {
    console.log('switch1 发生 change 事件，携带值为', e.detail.value);
  },
  switch2Change: function switch2Change(e) {
    console.log('switch2 发生 change 事件，携带值为', e.detail.value);
  }
});
});require("page/component/pages/switch/switch.js")
var __wxRoute = "page/component/pages/textarea/textarea", __wxRouteBegin = true;
define("page/component/pages/textarea/textarea.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'textarea',
      path: 'page/component/pages/textarea/textarea'
    };
  },


  data: {
    focus: false
  },

  bindTextAreaBlur: function bindTextAreaBlur(e) {
    console.log(e.detail.value);
  }
});
});require("page/component/pages/textarea/textarea.js")
var __wxRoute = "page/component/pages/navigator/navigator", __wxRouteBegin = true;
define("page/component/pages/navigator/navigator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'navigator',
      path: 'page/component/pages/navigator/navigator'
    };
  }
});
});require("page/component/pages/navigator/navigator.js")
var __wxRoute = "page/component/pages/navigator/navigate", __wxRouteBegin = true;
define("page/component/pages/navigator/navigate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'navigatePage',
      path: 'page/component/pages/navigator/navigate'
    };
  },
  onLoad: function onLoad(options) {
    console.log(options);
    this.setData({
      title: options.title
    });
  }
});
});require("page/component/pages/navigator/navigate.js")
var __wxRoute = "page/component/pages/navigator/redirect", __wxRouteBegin = true;
define("page/component/pages/navigator/redirect.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'redirectPage',
      path: 'page/component/pages/navigator/redirect'
    };
  },
  onLoad: function onLoad(options) {
    console.log(options);
    this.setData({
      title: options.title
    });
  }
});
});require("page/component/pages/navigator/redirect.js")
var __wxRoute = "page/component/pages/image/image", __wxRouteBegin = true;
define("page/component/pages/image/image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'image',
      path: 'page/component/pages/image/image'
    };
  },
  onLoad: function onLoad() {
    var _this = this;

    wx.cloud.getTempFileURL({
      fileList: [{
        fileID: 'cloud://release-b86096.7265-release-b86096-1258211818/开发者社区.webp',
        maxAge: 60 * 60
      }]
    }).then(function (res) {
      console.log(res);
      _this.setData({
        webpImageUrl: res.fileList[0].tempFileURL
      });
    }).catch(function (error) {
      console.log('CLOUD：image 临时链接获取失败');
    });
  },

  data: {
    imageUrl: 'cloud://release-b86096.7265-release-b86096-1258211818/demo.jpg',
    webpImageURL: ''
  }
});
});require("page/component/pages/image/image.js")
var __wxRoute = "page/component/pages/video/video", __wxRouteBegin = true;
define("page/component/pages/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function getRandomColor() {
  var rgb = [];
  for (var i = 0; i < 3; ++i) {
    var color = Math.floor(Math.random() * 256).toString(16);
    color = color.length === 1 ? '0' + color : color;
    rgb.push(color);
  }
  return '#' + rgb.join('');
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'video',
      path: 'page/component/pages/video/video'
    };
  },
  onReady: function onReady() {
    this.videoContext = wx.createVideoContext('myVideo');
  },
  onHide: function onHide() {},


  inputValue: '',
  data: {
    enableAutoRotation: true,
    src: '',
    danmuList: [{
      text: '第 1s 出现的弹幕',
      color: '#ff0000',
      time: 1
    }, {
      text: '第 3s 出现的弹幕',
      color: '#ff00ff',
      time: 3
    }]
  },

  bindInputBlur: function bindInputBlur(e) {
    this.inputValue = e.detail.value;
  },
  bindButtonTap: function bindButtonTap() {
    var that = this;
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: ['front', 'back'],
      success: function success(res) {
        that.setData({
          src: res.tempFilePath
        });
      }
    });
  },
  bindVideoEnterPictureInPicture: function bindVideoEnterPictureInPicture() {
    console.log('进入小窗模式');
  },
  bindVideoLeavePictureInPicture: function bindVideoLeavePictureInPicture() {
    console.log('退出小窗模式');
  },
  bindPlayVideo: function bindPlayVideo() {
    this.videoContext.play();
  },
  bindSendDanmu: function bindSendDanmu() {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
    });
  },
  videoErrorCallback: function videoErrorCallback(e) {
    console.log('视频错误信息:');
    console.log(e.detail.errMsg);
  },
  handleSwitchChange: function handleSwitchChange(e) {
    this.setData({
      enableAutoRotation: e.detail.value
    });
  }
});
});require("page/component/pages/video/video.js")
var __wxRoute = "page/component/pages/map/map", __wxRouteBegin = true;
define("page/component/pages/map/map.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'map',
      path: 'page/component/pages/map/map'
    };
  },


  data: {
    latitude: 23.099994,
    longitude: 113.324520,
    markers: [{
      latitude: 23.099994,
      longitude: 113.324520,
      name: 'T.I.T 创意园'
    }],
    covers: [{
      latitude: 23.099994,
      longitude: 113.344520,
      iconPath: '/image/location.png'
    }, {
      latitude: 23.099994,
      longitude: 113.304520,
      iconPath: '/image/location.png'
    }],
    polygons: [{
      points: [{
        latitude: 23.099994,
        longitude: 113.324520
      }, {
        latitude: 23.098994,
        longitude: 113.323520
      }, {
        latitude: 23.098994,
        longitude: 113.325520
      }],
      strokeWidth: 3,
      strokeColor: '#FFFFFFAA'
    }],
    subKey: 'B5QBZ-7JTLU-DSSVA-2BRJ3-TNXLF-2TBR7',
    enable3d: false,
    showCompass: false,
    enableOverlooking: false,
    enableZoom: true,
    enableScroll: true,
    enableRotate: false,
    drawPolygon: false,
    enableSatellite: false,
    enableTraffic: false
  },
  toggle3d: function toggle3d() {
    this.setData({
      enable3d: !this.data.enable3d
    });
  },
  toggleShowCompass: function toggleShowCompass() {
    this.setData({
      showCompass: !this.data.showCompass
    });
  },
  toggleOverlooking: function toggleOverlooking() {
    this.setData({
      enableOverlooking: !this.data.enableOverlooking
    });
  },
  toggleZoom: function toggleZoom() {
    this.setData({
      enableZoom: !this.data.enableZoom
    });
  },
  toggleScroll: function toggleScroll() {
    this.setData({
      enableScroll: !this.data.enableScroll
    });
  },
  toggleRotate: function toggleRotate() {
    this.setData({
      enableRotate: !this.data.enableRotate
    });
  },
  togglePolygon: function togglePolygon() {
    this.setData({
      drawPolygon: !this.data.drawPolygon
    });
  },
  toggleSatellite: function toggleSatellite() {
    this.setData({
      enableSatellite: !this.data.enableSatellite
    });
  },
  toggleTraffic: function toggleTraffic() {
    this.setData({
      enableTraffic: !this.data.enableTraffic
    });
  }
});
});require("page/component/pages/map/map.js")
var __wxRoute = "page/component/pages/canvas/canvas", __wxRouteBegin = true;
define("page/component/pages/canvas/canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _util = require('../../../../util/util');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'canvas',
      path: 'page/component/pages/canvas/canvas'
    };
  },

  data: {
    canIUse: true
  },
  onReady: function onReady() {

    // 解决基础库小于 2.7.0 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    if ((0, _util.compareVersion)(SDKVersion, '2.7.0') < 0) {
      console.log('123');
      this.setData({
        canIUse: false
      });
    } else {
      // canvas
      this.position = {
        x: 150,
        y: 150,
        vx: 2,
        vy: 2
      };

      this.drawBall();
      this.interval = setInterval(this.drawBall, 17);
    }
  },
  init: function init(res) {
    var _this = this;

    var width = res[0].width;
    var height = res[0].height;

    var canvas = res[0].node;
    var ctx = canvas.getContext('2d');

    var dpr = wx.getSystemInfoSync().pixelRatio;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    var renderLoop = function renderLoop() {
      _this.render(canvas, ctx);
      canvas.requestAnimationFrame(renderLoop);
    };
    canvas.requestAnimationFrame(renderLoop);

    var img = canvas.createImage();
    img.onload = function () {
      _this._img = img;
    };
    img.src = './car.png';
  },
  render: function render(canvas, ctx) {
    ctx.clearRect(0, 0, 305, 305);
    this.drawBall2D(ctx);
    this.drawCar(ctx);
  },
  drawBall: function drawBall() {
    var p = this.position;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    var context = wx.createCanvasContext('canvas');

    function ball(x, y) {
      context.beginPath(0);
      context.arc(x, y, 5, 0, Math.PI * 2);
      context.setFillStyle('#1aad19');
      context.setStrokeStyle('rgba(1,1,1,0)');
      context.fill();
      context.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);
    context.draw();
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
  }
});
});require("page/component/pages/canvas/canvas.js")
var __wxRoute = "page/component/pages/ad/ad", __wxRouteBegin = true;
define("page/component/pages/ad/ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var info = wx.getSystemInfoSync();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'ad',
      path: 'page/component/pages/ad/ad'
    };
  },


  data: {
    platform: info.platform
  }
});
});require("page/component/pages/ad/ad.js")
var __wxRoute = "page/component/pages/movable-view/movable-view", __wxRouteBegin = true;
define("page/component/pages/movable-view/movable-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'movable-view',
      path: 'page/component/pages/movable-view/movable-view'
    };
  },


  data: {
    x: 0,
    y: 0,
    scale: 2
  },

  tap: function tap() {
    this.setData({
      x: 30,
      y: 30
    });
  },
  tap2: function tap2() {
    this.setData({
      scale: 3
    });
  },
  onChange: function onChange(e) {
    console.log(e.detail);
  },
  onScale: function onScale(e) {
    console.log(e.detail);
  }
});
});require("page/component/pages/movable-view/movable-view.js")
var __wxRoute = "page/component/pages/cover-view/cover-view", __wxRouteBegin = true;
define("page/component/pages/cover-view/cover-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'cover-view',
      path: 'page/component/pages/cover-view/cover-view'
    };
  },


  data: {
    latitude: 23.099994,
    longitude: 113.324520
  }
});
});require("page/component/pages/cover-view/cover-view.js")
var __wxRoute = "page/component/pages/rich-text/rich-text", __wxRouteBegin = true;
define("page/component/pages/rich-text/rich-text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var htmlSnip = '<div class="div_class">\n  <h1>Title</h1>\n  <p class="p">\n    Life is&nbsp;<i>like</i>&nbsp;a box of\n    <b>&nbsp;chocolates</b>.\n  </p>\n</div>\n';

var nodeSnip = 'Page({\n  data: {\n    nodes: [{\n      name: \'div\',\n      attrs: {\n        class: \'div_class\',\n        style: \'line-height: 60px; color: red;\'\n      },\n      children: [{\n        type: \'text\',\n        text: \'You never know what you\'re gonna get.\'\n      }]\n    }]\n  }\n})\n';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'rich-text',
      path: 'page/component/pages/rich-text/rich-text'
    };
  },


  data: {
    htmlSnip: htmlSnip,
    nodeSnip: nodeSnip,
    renderedByHtml: false,
    renderedByNode: false,
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: #1AAD19;'
      },
      children: [{
        type: 'text',
        text: 'You never know what you\'re gonna get.'
      }]
    }]
  },
  renderHtml: function renderHtml() {
    this.setData({
      renderedByHtml: true
    });
  },
  renderNode: function renderNode() {
    this.setData({
      renderedByNode: true
    });
  },
  enterCode: function enterCode(e) {
    console.log(e.detail.value);
    this.setData({
      htmlSnip: e.detail.value
    });
  }
});
});require("page/component/pages/rich-text/rich-text.js")
var __wxRoute = "page/component/pages/picker-view/picker-view", __wxRouteBegin = true;
define("page/component/pages/picker-view/picker-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var date = new Date();
var years = [];
var months = [];
var days = [];

for (var i = 1990; i <= date.getFullYear(); i++) {
  years.push(i);
}

for (var _i = 1; _i <= 12; _i++) {
  months.push(_i);
}

for (var _i2 = 1; _i2 <= 31; _i2++) {
  days.push(_i2);
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'picker-view',
      path: 'page/component/pages/picker-view/picker-view'
    };
  },


  data: {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [9999, 1, 1],
    isDaytime: true
  },

  bindChange: function bindChange(e) {
    var val = e.detail.value;
    this.setData({
      year: this.data.years[val[0]],
      month: this.data.months[val[1]],
      day: this.data.days[val[2]],
      isDaytime: !val[3]
    });
  }
});
});require("page/component/pages/picker-view/picker-view.js")
var __wxRoute = "page/component/pages/camera/camera", __wxRouteBegin = true;
define("page/component/pages/camera/camera.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var vs = '\n  attribute vec3 aPos;\n  attribute vec2 aVertexTextureCoord;\n  varying highp vec2 vTextureCoord;\n\n  void main(void){\n    gl_Position = vec4(aPos, 1);\n    vTextureCoord = aVertexTextureCoord;\n  }\n';

var fs = '\n  varying highp vec2 vTextureCoord;\n  uniform sampler2D uSampler;\n\n  void main(void) {\n    gl_FragColor = texture2D(uSampler, vTextureCoord);\n  }\n';

var vertex = [-1, -1, 0.0, 1, -1, 0.0, 1, 1, 0.0, -1, 1, 0.0];

var vertexIndice = [0, 1, 2, 0, 2, 3];

var texCoords = [0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0];
function createShader(gl, src, type) {
  var shader = gl.createShader(type);
  gl.shaderSource(shader, src);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error('Error compiling shader: ' + gl.getShaderInfoLog(shader));
  }
  return shader;
}

var buffers = {};

function createRenderer(canvas, width, height) {
  var gl = canvas.getContext("webgl");
  if (!gl) {
    console.error('Unable to get webgl context.');
    return;
  }

  var info = wx.getSystemInfoSync();
  gl.canvas.width = info.pixelRatio * width;
  gl.canvas.height = info.pixelRatio * height;
  gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);

  var vertexShader = createShader(gl, vs, gl.VERTEX_SHADER);
  var fragmentShader = createShader(gl, fs, gl.FRAGMENT_SHADER);

  var program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error('Unable to initialize the shader program.');
    return;
  }

  gl.useProgram(program);

  var texture = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.bindTexture(gl.TEXTURE_2D, null);

  buffers.vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertex), gl.STATIC_DRAW);

  buffers.vertexIndiceBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.vertexIndiceBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(vertexIndice), gl.STATIC_DRAW);

  var aVertexPosition = gl.getAttribLocation(program, 'aPos');
  gl.vertexAttribPointer(aVertexPosition, 3, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(aVertexPosition);

  buffers.trianglesTexCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.trianglesTexCoordBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texCoords), gl.STATIC_DRAW);

  var vertexTexCoordAttribute = gl.getAttribLocation(program, "aVertexTextureCoord");
  gl.enableVertexAttribArray(vertexTexCoordAttribute);
  gl.vertexAttribPointer(vertexTexCoordAttribute, 2, gl.FLOAT, false, 0, 0);

  var samplerUniform = gl.getUniformLocation(program, 'uSampler');
  gl.uniform1i(samplerUniform, 0);

  return function (arrayBuffer, width, height) {
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, arrayBuffer);
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
  };
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'camera',
      path: 'page/component/pages/camera/camera'
    };
  },


  data: {
    src: '',
    videoSrc: '',
    position: 'back',
    mode: 'scanCode',
    result: {},
    frameWidth: 0,
    frameHeight: 0,
    width: 288,
    height: 358,
    showCanvas: false
  },

  onReady: function onReady() {
    this.ctx = wx.createCameraContext();
    // const selector = wx.createSelectorQuery();
    // selector.select('#webgl')
    // .node(this.init)
    // .exec()
  },
  init: function init(res) {
    var _this = this;

    if (this.listener) {
      this.listener.stop();
    }
    var canvas = res.node;
    var render = createRenderer(canvas, this.data.width, this.data.height);

    // if (!render || typeof render !== 'function') return

    this.listener = this.ctx.onCameraFrame(function (frame) {

      render(new Uint8Array(frame.data), frame.width, frame.height);

      var _data = _this.data,
          frameWidth = _data.frameWidth,
          frameHeight = _data.frameHeight;


      if (frameWidth === frame.width && frameHeight == frame.height) return;
      _this.setData({
        frameWidth: frame.width,
        frameHeight: frame.height

      });
    });
    this.listener.start();
  },
  takePhoto: function takePhoto() {
    var _this2 = this;

    this.ctx.takePhoto({
      quality: 'high',
      success: function success(res) {
        _this2.setData({
          src: res.tempImagePath
        });
      }
    });
  },
  startRecord: function startRecord() {
    this.ctx.startRecord({
      success: function success() {
        console.log('startRecord');
      }
    });
  },
  stopRecord: function stopRecord() {
    var _this3 = this;

    this.ctx.stopRecord({
      success: function success(res) {
        _this3.setData({
          src: res.tempThumbPath,
          videoSrc: res.tempVideoPath
        });
      }
    });
  },
  togglePosition: function togglePosition() {
    this.setData({
      position: this.data.position === 'front' ? 'back' : 'front'
    });
  },
  error: function error(e) {
    console.log(e.detail);
  },
  handleShowCanvas: function handleShowCanvas() {
    var _this4 = this;

    var that = this;

    this.setData({
      showCanvas: !this.data.showCanvas
    }, function () {
      if (_this4.data.showCanvas) {
        var selector = wx.createSelectorQuery();
        selector.select('#webgl').node(_this4.init).exec();
      }
    });
  }
});
});require("page/component/pages/camera/camera.js")
var __wxRoute = "page/component/pages/camera-scan-code/camera-scan-code", __wxRouteBegin = true;
define("page/component/pages/camera-scan-code/camera-scan-code.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'camera',
      path: 'page/component/pages/camera-scan-code/camera-scan-code'
    };
  },


  data: {
    result: {}
  },
  onReady: function onReady() {
    wx.showModal({
      title: '提示',
      content: '将摄像头对准一维码即可扫描',
      showCancel: false
    });
  },
  scanCode: function scanCode(e) {
    console.log('scanCode:', e);
    this.setData({
      result: e.detail
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  error: function error(e) {
    console.log(e.detail);
  }
});
});require("page/component/pages/camera-scan-code/camera-scan-code.js")
var __wxRoute = "page/component/pages/map-styles/map-styles", __wxRouteBegin = true;
define("page/component/pages/map-styles/map-styles.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'map底图样式',
      path: 'page/component/pages/map-styles/map-styles'
    };
  }
});
});require("page/component/pages/map-styles/map-styles.js")
var __wxRoute = "page/component/pages/live-player/live-player", __wxRouteBegin = true;
define("page/component/pages/live-player/live-player.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'live-player',
      path: 'page/component/pages/live-player/live-player'
    };
  },

  data: {
    videoSrc: ""
  },
  onReady: function onReady(res) {
    this.ctx = wx.createLivePlayerContext('player');
  },
  handleScanQRCode: function handleScanQRCode() {
    var _this = this;

    wx.scanCode({
      complete: function complete(res) {
        var result = res.result;

        _this.setData({
          videoSrc: result
        });
      }
    });
  },
  handleLivePlayerStateChange: function handleLivePlayerStateChange(e) {
    console.log('live-player code:', e.detail.code);
  },
  handleLivePlayerError: function handleLivePlayerError(e) {
    console.error('live-player error:', e.detail.errMsg);
  },
  handlePlay: function handlePlay() {
    this.ctx.play({
      success: function success(res) {
        console.log('play success');
      },
      fail: function fail(res) {
        console.log('play fail');
      }
    });
  },
  handlePause: function handlePause() {
    this.ctx.pause({
      success: function success(res) {
        console.log('pause success');
      },
      fail: function fail(res) {
        console.log('pause fail');
      }
    });
  },
  handleStop: function handleStop() {
    this.ctx.stop({
      success: function success(res) {
        console.log('stop success');
      },
      fail: function fail(res) {
        console.log('stop fail');
      }
    });
  },
  handleResume: function handleResume() {
    this.ctx.resume({
      success: function success(res) {
        console.log('resume success');
      },
      fail: function fail(res) {
        console.log('resume fail');
      }
    });
  },
  handleMute: function handleMute() {
    this.ctx.mute({
      success: function success(res) {
        console.log('mute success');
      },
      fail: function fail(res) {
        console.log('mute fail');
      }
    });
  },
  handleVideoSrcInput: function handleVideoSrcInput(e) {
    this.setData({
      videoSrc: e.detail.value
    });
  }
});
});require("page/component/pages/live-player/live-player.js")
var __wxRoute = "page/component/pages/live-pusher/live-pusher", __wxRouteBegin = true;
define("page/component/pages/live-pusher/live-pusher.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'live-pusher',
      path: 'page/component/pages/live-pusher/live-pusher'
    };
  },

  data: {
    videoSrc: ''
  },
  onReady: function onReady(res) {
    this.ctx = wx.createLivePusherContext('pusher');
  },
  handleLivePusherStateChange: function handleLivePusherStateChange(e) {
    console.log('live-pusher code:', e.detail.code);
  },
  handleLivePusherError: function handleLivePusherError(e) {
    console.error('live-pusher error:', e.detail.errMsg);
  },
  handleStart: function handleStart() {
    this.ctx.start({
      success: function success(res) {
        console.log('start success');
      },
      fail: function fail(res) {
        console.log('start fail');
      }
    });
  },
  handleScanQRCode: function handleScanQRCode() {
    var _this = this;

    wx.scanCode({
      complete: function complete(res) {
        var result = res.result;

        _this.setData({
          videoSrc: result
        });
      }
    });
  },
  handlePause: function handlePause() {
    this.ctx.pause({
      success: function success(res) {
        console.log('pause success');
      },
      fail: function fail(res) {
        console.log('pause fail');
      }
    });
  },
  handleStop: function handleStop() {
    this.ctx.stop({
      success: function success(res) {
        console.log('stop success');
      },
      fail: function fail(res) {
        console.log('stop fail');
      }
    });
  },
  handleResume: function handleResume() {
    this.ctx.resume({
      success: function success(res) {
        console.log('resume success');
      },
      fail: function fail(res) {
        console.log('resume fail');
      }
    });
  },
  handleSwitchCamera: function handleSwitchCamera() {
    this.ctx.switchCamera({
      success: function success(res) {
        console.log('switch camera success');
      },
      fail: function fail(res) {
        console.log('switch camera fail');
      }
    });
  },
  handleVideoSrcInput: function handleVideoSrcInput(e) {
    this.setData({
      videoSrc: e.detail.value
    });
  }
});
});require("page/component/pages/live-pusher/live-pusher.js")
var __wxRoute = "page/component/pages/aria-component/aria-component", __wxRouteBegin = true;
define("page/component/pages/aria-component/aria-component.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// miniprogram/page/component/pages/aria-component/aria-component.js
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '无障碍访问',
      path: 'page/component/pages/aria-component/aria-component'
    };
  }
});
});require("page/component/pages/aria-component/aria-component.js")
var __wxRoute = "page/API/index", __wxRouteBegin = true;
define("page/API/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序接口能力展示',
      path: 'page/API/index'
    };
  },


  data: {
    list: [{
      id: 'api',
      name: '开放接口',
      open: false,
      pages: [{
        zh: '微信登录',
        url: 'login/login'
      }, {
        zh: '获取用户信息',
        url: 'get-user-info/get-user-info'
      }, {
        zh: '发起支付',
        url: 'request-payment/request-payment'
      }, {
        zh: '转发',
        url: 'share/share'
      }, {
        zh: '转发按钮',
        url: 'share-button/share-button'
      }, {
        zh: '客服消息',
        url: 'custom-message/custom-message'
      }, {
        zh: '订阅消息',
        url: 'subscribe-message/subscribe-message'
      }, {
        zh: '收货地址',
        url: 'choose-address/choose-address'
      }, {
        zh: '获取发票抬头',
        url: 'choose-invoice-title/choose-invoice-title'
      }, {
        zh: '生物认证',
        url: 'soter-authentication/soter-authentication'
      }, {
        zh: '设置',
        url: 'setting/setting'
      }]
    }, {
      id: 'page',
      name: '界面',
      open: false,
      pages: [{
        zh: '设置界面标题',
        url: 'set-navigation-bar-title/set-navigation-bar-title'
      }, {
        zh: '标题栏加载动画',
        url: 'navigation-bar-loading/navigation-bar-loading'
      }, {
        zh: '设置TabBar',
        url: '@set-tab-bar'
      }, {
        zh: '页面跳转',
        url: 'navigator/navigator'
      }, {
        zh: '下拉刷新',
        url: 'pull-down-refresh/pull-down-refresh'
      }, {
        zh: '创建动画',
        url: 'animation/animation'
      }, {
        zh: '创建绘画',
        url: 'canvas/canvas'
      }, {
        zh: '显示操作菜单',
        url: 'action-sheet/action-sheet'
      }, {
        zh: '显示模态弹窗',
        url: 'modal/modal'
      }, {
        zh: '页面滚动',
        url: 'page-scroll/page-scroll'
      }, {
        zh: '显示消息提示框',
        url: 'toast/toast'
      }, {
        zh: '获取WXML节点信息',
        url: 'get-wxml-node-info/get-wxml-node-info'
      }, {
        zh: 'WXML节点布局相交状态',
        url: 'intersection-observer/intersection-observer'
      }]
    }, {
      id: 'device',
      name: '设备',
      open: false,
      pages: [{
        zh: '获取手机网络状态',
        url: 'get-network-type/get-network-type'
      }, {
        zh: '监听手机网络变化',
        url: 'on-network-status-change/on-network-status-change'
      }, {
        zh: '获取手机系统信息',
        url: 'get-system-info/get-system-info'
      }, {
        zh: '获取手机设备电量',
        url: 'get-battery-info/get-battery-info'
      }, {
        zh: '监听重力感应数据',
        url: 'on-accelerometer-change/on-accelerometer-change'
      }, {
        zh: '监听罗盘数据',
        url: 'on-compass-change/on-compass-change'
      }, {
        zh: '打电话',
        url: 'make-phone-call/make-phone-call'
      }, {
        zh: '扫码',
        url: 'scan-code/scan-code'
      }, {
        zh: '剪切板',
        url: 'clipboard-data/clipboard-data'
      }, {
        zh: '蓝牙',
        url: 'bluetooth/bluetooth'
      }, {
        zh: 'iBeacon',
        url: 'ibeacon/ibeacon'
      }, {
        zh: '屏幕亮度',
        url: 'screen-brightness/screen-brightness'
      }, {
        zh: '用户截屏事件',
        url: 'capture-screen/capture-screen'
      }, {
        zh: '振动',
        url: 'vibrate/vibrate'
      }, {
        zh: '手机联系人',
        url: 'add-contact/add-contact'
      }, {
        zh: 'Wi-Fi',
        url: 'wifi/wifi'
      }]
    }, {
      id: 'performance',
      name: '性能',
      open: false,
      pages: [{
        zh: '获取性能数据',
        url: 'get-performance/get-performance'
      }]
    }, {
      id: 'network',
      name: '网络',
      open: false,
      pages: [{
        zh: '发起一个请求',
        url: 'request/request'
      }, {
        zh: 'WebSocket',
        url: 'web-socket/web-socket'
      }, {
        zh: '上传文件',
        url: 'upload-file/upload-file'
      }, {
        zh: '下载文件',
        url: 'download-file/download-file'
      }, {
        zh: 'UDPSocket',
        url: 'udp-socket/udp-socket'
      }, {
        zh: 'mDNS',
        url: 'mdns/mdns'
      }]
    }, {
      id: 'media',
      name: '媒体',
      open: false,
      pages: [{
        zh: '图片',
        url: 'image/image'
      }, {
        zh: '音频',
        url: 'audio/audio'
      }, {
        zh: '录音',
        url: 'voice/voice'
      }, {
        zh: '背景音频',
        url: 'background-audio/background-audio'
      }, {
        zh: '文件',
        url: 'file/file'
      }, {
        zh: '视频',
        url: 'video/video'
      }, {
        zh: '音视频合成',
        url: 'media-container/media-container'
      }, {
        zh: '动态加载字体',
        url: 'load-font-face/load-font-face'
      }]
    }, {
      id: 'location',
      name: '位置',
      open: false,
      pages: [{
        zh: '获取当前位置',
        url: 'get-location/get-location'
      }, {
        zh: '使用原生地图查看位置',
        url: 'open-location/open-location'
      }, {
        zh: '使用原生地图选择位置',
        url: 'choose-location/choose-location'
      }]
    }, {
      id: 'storage',
      name: '数据',
      pages: [{
        zh: '本地存储',
        url: 'storage/storage'
      }, {
        zh: '周期性更新',
        url: 'get-background-fetch-data/get-background-fetch-data'

      }, {
        zh: '数据预拉取',
        url: 'get-background-prefetch-data/get-background-prefetch-data'
      }]
    }, {
      id: 'worker',
      name: '多线程',
      url: 'worker/worker'
    }, {
      id: 'framework',
      name: '框架',
      pages: [{
        zh: '双向绑定',
        url: 'two-way-bindings/two-way-bindings'
      }, {
        zh: 'WXS',
        url: 'wxs/wxs'
      }, {
        zh: '屏幕旋转',
        url: 'resizable/resizable'
      }]
    }],
    isSetTabBarPage: false,
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  onShow: function onShow() {
    this.leaveSetTabBarPage();
  },
  onHide: function onHide() {
    this.leaveSetTabBarPage();
  },
  kindToggle: function kindToggle(e) {
    var id = e.currentTarget.id;var list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id === id) {
        if (list[i].url) {
          wx.navigateTo({
            url: '../../packageAPI/pages/' + list[i].url
          });
          return;
        }
        list[i].open = !list[i].open;
      } else {
        list[i].open = false;
      }
    }
    this.setData({
      list: list
    });
  },
  enterSetTabBarPage: function enterSetTabBarPage() {
    this.setData({
      isSetTabBarPage: true
    });
  },
  leaveSetTabBarPage: function leaveSetTabBarPage() {
    this.setData({
      isSetTabBarPage: false
    });
  }
});
});require("page/API/index.js")
var __wxRoute = "page/cloud/index", __wxRouteBegin = true;
define("page/cloud/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序云开发展示',
      path: 'page/cloud/index'
    };
  },


  data: {
    list: [{
      id: 'user',
      name: '用户鉴权',
      open: false,
      pages: [{
        zh: '获取 OpenID',
        url: 'user-authentication/user-authentication'
      }]
    }, {
      id: 'database',
      name: '数据库',
      open: false,
      pages: [{
        zh: '基本操作',
        url: 'crud/crud'
      }, {
        zh: '权限管理',
        url: 'db-permission/db-permission'
      }, {
        zh: '服务端时间',
        url: 'server-date/server-date'
      }]
    }, {
      id: 'storage',
      name: '存储',
      open: false,
      pages: [{
        zh: '上传文件',
        url: 'upload-file/upload-file'
      }, {
        zh: '下载文件',
        url: 'download-file/download-file'
      }, {
        zh: '删除文件',
        url: 'delete-file/delete-file'
      }, {
        zh: '换取临时链接',
        url: 'get-temp-file-url/get-temp-file-url'
      }, {
        zh: '组件支持',
        url: 'cloud-file-component/cloud-file-component'
      }]
    }, {
      id: 'scf',
      name: '云函数',
      open: false,
      pages: [{
        zh: 'WXContext',
        url: 'get-wx-context/get-wx-context'
      }, {
        zh: '数据库',
        url: 'scf-database/scf-database'
      }, {
        zh: '存储',
        url: 'scf-storage/scf-storage'
      }, {
        zh: '云调用',
        url: 'scf-openapi/scf-openapi'
      }]
    }],
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  kindToggle: function kindToggle(e) {
    var id = e.currentTarget.id;
    var list = this.data.list;
    console.log(id, list);
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id === id) {
        if (list[i].url) {
          console.log(list[i].url);
          wx.navigateTo({
            url: '../../packageCloud/pages/' + list[i].url
          });
          return;
        }
        list[i].open = !list[i].open;
      } else {
        list[i].open = false;
      }
    }
    this.setData({
      list: list
    });
  }
});
});require("page/cloud/index.js")
var __wxRoute = "page/component/pages/doc-web-view/doc-web-view", __wxRouteBegin = true;
define("page/component/pages/doc-web-view/doc-web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序组件文档',
      path: 'page/component/pages/doc-web-view/doc-web-view'
    };
  }
});
});require("page/component/pages/doc-web-view/doc-web-view.js")
var __wxRoute = "page/component/pages/open-data/open-data", __wxRouteBegin = true;
define("page/component/pages/open-data/open-data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'open-data',
      path: 'page/component/pages/open-data/open-data'
    };
  }
});
});require("page/component/pages/open-data/open-data.js")
var __wxRoute = "page/component/pages/web-view/web-view", __wxRouteBegin = true;
define("page/component/pages/web-view/web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'webview',
      path: 'page/component/pages/web-view/web-view'
    };
  }
});
});require("page/component/pages/web-view/web-view.js")
var __wxRoute = "page/component/pages/editor/editor", __wxRouteBegin = true;
define("page/component/pages/editor/editor.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'editor',
      path: 'page/component/pages/editor/editor'
    };
  },

  data: {
    formats: {},
    readOnly: false,
    placeholder: '开始输入...',
    editorHeight: 300,
    keyboardHeight: 0,
    isIOS: false,
    safeHeight: 0,
    toolBarHeight: 50
  },
  readOnlyChange: function readOnlyChange() {
    this.setData({
      readOnly: !this.data.readOnly
    });
  },
  onLoad: function onLoad() {
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        platform = _wx$getSystemInfoSync.platform,
        safeArea = _wx$getSystemInfoSync.safeArea,
        model = _wx$getSystemInfoSync.model,
        screenHeight = _wx$getSystemInfoSync.screenHeight;

    var safeHeight = void 0;
    if (safeArea) {
      safeHeight = screenHeight - safeArea.bottom;
    } else {
      safeHeight = 32;
    }
    this._safeHeight = safeHeight;
    var isIOS = platform === 'ios';
    this.setData({ isIOS: isIOS, safeHeight: safeHeight, toolBarHeight: isIOS ? safeHeight + 50 : 50 });
    var that = this;
    this.updatePosition(0);
    var keyboardHeight = 0;
    wx.onKeyboardHeightChange(function (res) {
      if (res.height === keyboardHeight) {
        return;
      }
      var duration = res.height > 0 ? res.duration * 1000 : 0;
      keyboardHeight = res.height;
      setTimeout(function () {
        wx.pageScrollTo({
          scrollTop: 0,
          success: function success() {
            that.updatePosition(keyboardHeight);
            that.editorCtx.scrollIntoView();
          }
        });
      }, duration);
    });
  },
  updatePosition: function updatePosition(keyboardHeight) {
    var toolbarHeight = 50;

    var _wx$getSystemInfoSync2 = wx.getSystemInfoSync(),
        windowHeight = _wx$getSystemInfoSync2.windowHeight,
        platform = _wx$getSystemInfoSync2.platform;

    var editorHeight = keyboardHeight > 0 ? windowHeight - keyboardHeight - toolbarHeight : windowHeight;
    if (keyboardHeight === 0) {
      this.setData({
        editorHeight: editorHeight, keyboardHeight: keyboardHeight,
        toolBarHeight: this.data.isIOS ? 50 + this._safeHeight : 50,
        safeHeight: this._safeHeight
      });
    } else {
      this.setData({ editorHeight: editorHeight, keyboardHeight: keyboardHeight,
        toolBarHeight: 50,
        safeHeight: 0
      });
    }
  },
  calNavigationBarAndStatusBar: function calNavigationBarAndStatusBar() {
    var systemInfo = wx.getSystemInfoSync();
    var statusBarHeight = systemInfo.statusBarHeight,
        platform = systemInfo.platform;

    var isIOS = platform === 'ios';
    var navigationBarHeight = isIOS ? 44 : 48;
    return statusBarHeight + navigationBarHeight;
  },
  onEditorReady: function onEditorReady() {
    var that = this;
    wx.createSelectorQuery().select('#editor').context(function (res) {
      that.editorCtx = res.context;
    }).exec();
  },
  blur: function blur() {
    this.editorCtx.blur();
  },
  format: function format(e) {
    var _e$target$dataset = e.target.dataset,
        name = _e$target$dataset.name,
        value = _e$target$dataset.value;

    if (!name) return;
    // console.log('format', name, value)
    this.editorCtx.format(name, value);
  },
  onStatusChange: function onStatusChange(e) {
    var formats = e.detail;
    this.setData({ formats: formats });
  },
  insertDivider: function insertDivider() {
    this.editorCtx.insertDivider({
      success: function success() {
        console.log('insert divider success');
      }
    });
  },
  clear: function clear() {
    this.editorCtx.clear({
      success: function success(res) {
        console.log("clear success");
      }
    });
  },
  removeFormat: function removeFormat() {
    this.editorCtx.removeFormat();
  },
  insertDate: function insertDate() {
    var date = new Date();
    var formatDate = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
    this.editorCtx.insertText({
      text: formatDate
    });
  },
  insertImage: function insertImage() {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function success(res) {
        that.editorCtx.insertImage({
          src: res.tempFilePaths[0],
          data: {
            id: 'abcd',
            role: 'god'
          },
          width: '80%',
          success: function success() {
            console.log('insert image success');
          }
        });
      }
    });
  }
});
});require("page/component/pages/editor/editor.js")
var __wxRoute = "page/weui/example/index", __wxRouteBegin = true;
define("page/weui/example/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _CustomPage = require('../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: '扩展能力',
            path: 'page/weui/example/index'
        };
    },

    data: {
        list: [{
            id: 'form',
            name: '表单',
            open: false,
            pages: ['cell', 'slideview', 'form', 'uploader']
        }, {
            id: 'widget',
            name: '基础组件',
            open: false,
            pages: ['article', 'icons', 'badge', 'flex', 'footer', 'gallery', 'grid', 'loadmore', 'loading', 'panel', 'preview']
        }, {
            id: 'feedback',
            name: '操作反馈',
            open: false,
            pages: ['dialog', 'msg', 'half-screen-dialog', 'actionsheet', 'toptips']
        }, {
            id: 'nav',
            name: '导航相关',
            open: false,
            pages: ['navigation', 'tabbar']
        }, {
            id: 'search',
            name: '搜索相关',
            open: false,
            pages: ['searchbar']
        }, {
            id: 'extended',
            name: '扩展组件',
            open: false,
            pages: ['emoji', 'video-swiper', 'index-list', 'recycle-view', 'sticky', 'tabs', 'vtabs', 'barrage', 'select-text', 'wxml-to-canvas']
        }, {
            id: 'adaptive',
            name: '多端适配（需在PC端体验）',
            open: false,
            pages: [{ zh: '左右伸缩', url: 'telescopic/telescopic' }, { zh: '换行排列', url: 'linebreak/linebreak' }, { zh: '侧边导航栏', url: 'sidenavigation/sidenavigation' }, { zh: '分页展现', url: 'pagination/pagination' }, { zh: '自由布局', url: 'freelayout/freelayout' }, { zh: '分层展现', url: 'layeredpresentation/layeredpresentation' }, { zh: '横向拓展', url: 'horizontalexpansion/horizontalexpansion' }]
        }],
        extendedList: [{
            id: 'extended',
            name: '扩展组件',
            open: false,
            pages: ['emoji', 'video-swiper', 'index-list', 'recycle-view', 'sticky', 'tabs', 'vtabs', 'barrage', 'select-text', 'wxml-to-canvas']
        }]
    },
    kindToggle: function kindToggle(e) {
        var id = e.currentTarget.id,
            list = this.data.list;
        for (var i = 0, len = list.length; i < len; ++i) {
            if (list[i].id == id) {
                list[i].open = !list[i].open;
            } else {
                list[i].open = false;
            }
        }
        // const extendedList = this.data.extendedList.map((item) => ({...item, open: false}))
        this.setData({
            list: list
            // extendedList,

        });
    },
    kindExtenedListToggle: function kindExtenedListToggle(e) {
        var id = e.currentTarget.id;
        var extendedList = this.data.extendedList;
        for (var i = 0, len = extendedList.length; i < len; ++i) {
            if (extendedList[i].id == id) {
                extendedList[i].open = !extendedList[i].open;
            } else {
                extenedList[i].open = false;
            }
        }
        var list = this.data.list.map(function (item) {
            return _extends({}, item, { open: false });
        });
        this.setData({
            extendedList: extendedList,
            list: list
        });
    },
    themeToggle: function themeToggle() {
        var App = getApp();

        if (App.themeChanged) {
            if (App.globalData.theme === 'light') {
                App.themeChanged('dark');
            } else {
                App.themeChanged('light');
            }
        }
    }
});
});require("page/weui/example/index.js")
var __wxRoute = "page/weui/example/cell/cell", __wxRouteBegin = true;
define("page/weui/example/cell/cell.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var base64 = require("../images/base64");


(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'cell',
      path: 'page/weui/example/cell/cell'
    };
  },

  onLoad: function onLoad() {
    this.setData({
      icon: base64.icon20,
      slideButtons: [{
        text: '普通',
        src: global.isDemo ? '/page/weui/example/cell/icon_love.svg' : '/example/cell/icon_love.svg' // icon的路径
      }, {
        text: '普通',
        extClass: 'test',
        src: global.isDemo ? '/page/weui/example/cell/icon_star.svg' : '/example/cell/icon_star.svg' // icon的路径
      }, {
        type: 'warn',
        text: '警示',
        extClass: 'test',
        src: global.isDemo ? '/page/weui/example/cell/icon_del.svg' : '/example/cell/icon_del.svg' // icon的路径
      }]
    });
  },
  slideButtonTap: function slideButtonTap(e) {
    console.log('slide button tap', e.detail);
  }
});
});require("page/weui/example/cell/cell.js")
var __wxRoute = "page/weui/example/slideview/slideview", __wxRouteBegin = true;
define("page/weui/example/slideview/slideview.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var base64 = require("../images/base64");


(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'sliderview',
      path: 'page/weui/example/sliderview/sliderview'
    };
  },

  onLoad: function onLoad() {
    this.setData({
      icon: base64.icon20,
      slideButtons: [{
        text: '普通',
        src: global.isDemo ? '/page/weui/example/cell/icon_love.svg' : '/example/cell/icon_love.svg' // icon的路径
      }, {
        text: '普通',
        extClass: 'test',
        src: global.isDemo ? '/page/weui/example/cell/icon_star.svg' : '/example/cell/icon_star.svg' // icon的路径
      }, {
        type: 'warn',
        text: '警示',
        extClass: 'test',
        src: global.isDemo ? '/page/weui/example/cell/icon_del.svg' : '/example/cell/icon_del.svg' // icon的路径
      }]
    });
  },
  slideButtonTap: function slideButtonTap(e) {
    console.log('slide button tap', e.detail);
  }
});
});require("page/weui/example/slideview/slideview.js")
var __wxRoute = "page/weui/example/form/form", __wxRouteBegin = true;
define("page/weui/example/form/form.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'form',
            path: 'page/weui/example/form/form'
        };
    },

    data: {
        showTopTips: false,

        radioItems: [{ name: 'cell standard', value: '0', checked: true }, { name: 'cell standard', value: '1' }],
        checkboxItems: [{ name: 'standard is dealt for u.', value: '0', checked: true }, { name: 'standard is dealicient for u.', value: '1' }],
        items: [{ name: 'USA', value: '美国' }, { name: 'CHN', value: '中国', checked: 'true' }, { name: 'BRA', value: '巴西' }, { name: 'JPN', value: '日本' }, { name: 'ENG', value: '英国' }, { name: 'TUR', value: '法国' }],

        date: "2016-09-01",
        time: "12:01",

        countryCodes: ["+86", "+80", "+84", "+87"],
        countryCodeIndex: 0,

        countries: ["中国", "美国", "英国"],
        countryIndex: 0,

        accounts: ["微信号", "QQ", "Email"],
        accountIndex: 0,

        isAgree: false,
        formData: {},
        rules: [{
            name: 'radio',
            rules: { required: false, message: '单选列表是必选项' }
        }, {
            name: 'checkbox',
            rules: { required: true, message: '多选列表是必选项' }
        }, {
            name: 'name',
            rules: { required: true, message: '请输入姓名' }
        }, {
            name: 'qq',
            rules: { required: true, message: 'qq必填' }
        }, {
            name: 'mobile',
            rules: [{ required: true, message: 'mobile必填' }, { mobile: true, message: 'mobile格式不对' }]
        }, {
            name: 'vcode',
            rules: { required: true, message: '验证码必填' }
        }, {
            name: 'idcard',
            rules: { validator: function validator(rule, value, param, modeels) {
                    if (!value || value.length !== 18) {
                        return 'idcard格式不正确';
                    }
                } }
        }]
    },
    radioChange: function radioChange(e) {
        console.log('radio发生change事件，携带value值为：', e.detail.value);

        var radioItems = this.data.radioItems;
        for (var i = 0, len = radioItems.length; i < len; ++i) {
            radioItems[i].checked = radioItems[i].value == e.detail.value;
        }

        this.setData(_defineProperty({
            radioItems: radioItems
        }, 'formData.radio', e.detail.value));
    },
    checkboxChange: function checkboxChange(e) {
        console.log('checkbox发生change事件，携带value值为：', e.detail.value);

        var checkboxItems = this.data.checkboxItems,
            values = e.detail.value;
        for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
            checkboxItems[i].checked = false;

            for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
                if (checkboxItems[i].value == values[j]) {
                    checkboxItems[i].checked = true;
                    break;
                }
            }
        }

        this.setData(_defineProperty({
            checkboxItems: checkboxItems
        }, 'formData.checkbox', e.detail.value));
    },
    bindDateChange: function bindDateChange(e) {
        this.setData(_defineProperty({
            date: e.detail.value
        }, 'formData.date', e.detail.value));
    },
    formInputChange: function formInputChange(e) {
        var field = e.currentTarget.dataset.field;

        this.setData(_defineProperty({}, 'formData.' + field, e.detail.value));
    },

    bindTimeChange: function bindTimeChange(e) {
        this.setData({
            time: e.detail.value
        });
    },
    bindCountryCodeChange: function bindCountryCodeChange(e) {
        console.log('picker country code 发生选择改变，携带值为', e.detail.value);

        this.setData({
            countryCodeIndex: e.detail.value
        });
    },
    bindCountryChange: function bindCountryChange(e) {
        console.log('picker country 发生选择改变，携带值为', e.detail.value);

        this.setData({
            countryIndex: e.detail.value
        });
    },
    bindAccountChange: function bindAccountChange(e) {
        console.log('picker account 发生选择改变，携带值为', e.detail.value);

        this.setData({
            accountIndex: e.detail.value
        });
    },
    bindAgreeChange: function bindAgreeChange(e) {
        this.setData({
            isAgree: !!e.detail.value.length
        });
    },
    submitForm: function submitForm() {
        var _this = this;

        this.selectComponent('#form').validate(function (valid, errors) {
            console.log('valid', valid, errors);
            if (!valid) {
                var firstError = Object.keys(errors);
                if (firstError.length) {
                    _this.setData({
                        error: errors[firstError[0]].message
                    });
                }
            } else {
                wx.showToast({
                    title: '校验通过'
                });
            }
        });
        // this.selectComponent('#form').validateField('mobile', (valid, errors) => {
        //     console.log('valid', valid, errors)
        // })
    }
});
});require("page/weui/example/form/form.js")
var __wxRoute = "page/weui/example/uploader/uploader", __wxRouteBegin = true;
define("page/weui/example/uploader/uploader.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'uploader',
            path: 'page/weui/example/uploader/uploader'
        };
    },

    data: {
        files: [{
            url: 'http://mmbiz.qpic.cn/mmbiz_png/VUIF3v9blLsicfV8ysC76e9fZzWgy8YJ2bQO58p43Lib8ncGXmuyibLY7O3hia8sWv25KCibQb7MbJW3Q7xibNzfRN7A/0'
        }]
    },
    onLoad: function onLoad() {
        this.setData({
            selectFile: this.selectFile.bind(this),
            uplaodFile: this.uplaodFile.bind(this)
        });
    },

    chooseImage: function chooseImage(e) {
        var that = this;
        wx.chooseImage({
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function success(res) {
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                that.setData({
                    files: that.data.files.concat(res.tempFilePaths)
                });
            }
        });
    },
    previewImage: function previewImage(e) {
        wx.previewImage({
            current: e.currentTarget.id, // 当前显示图片的http链接
            urls: this.data.files // 需要预览的图片http链接列表
        });
    },
    selectFile: function selectFile(files) {
        console.log('files', files);
        // 返回false可以阻止某次文件上传
    },
    uplaodFile: function uplaodFile(files) {
        console.log('upload files', files);
        // 文件上传的函数，返回一个promise
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                reject('some error');
            }, 1000);
        });
    },
    uploadError: function uploadError(e) {
        console.log('upload error', e.detail);
    },
    uploadSuccess: function uploadSuccess(e) {
        console.log('upload success', e.detail);
    }
});
});require("page/weui/example/uploader/uploader.js")
var __wxRoute = "page/weui/example/article/article", __wxRouteBegin = true;
define("page/weui/example/article/article.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'article',
      path: 'page/weui/example/article/article'
    };
  }
});
});require("page/weui/example/article/article.js")
var __wxRoute = "page/weui/example/badge/badge", __wxRouteBegin = true;
define("page/weui/example/badge/badge.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'badge',
      path: 'page/weui/example/badge/badge'
    };
  }
});
});require("page/weui/example/badge/badge.js")
var __wxRoute = "page/weui/example/flex/flex", __wxRouteBegin = true;
define("page/weui/example/flex/flex.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'flex',
      path: 'page/weui/example/flex/flex'
    };
  }
});
});require("page/weui/example/flex/flex.js")
var __wxRoute = "page/weui/example/footer/footer", __wxRouteBegin = true;
define("page/weui/example/footer/footer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'footer',
      path: 'page/weui/example/footer/footer'
    };
  }
});
});require("page/weui/example/footer/footer.js")
var __wxRoute = "page/weui/example/gallery/gallery", __wxRouteBegin = true;
define("page/weui/example/gallery/gallery.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'gallery',
            path: 'page/weui/example/gallery/gallery'
        };
    },

    data: {
        imgUrls: ['http://desk-fd.zol-img.com.cn/g5/M00/02/05/ChMkJ1bKyZmIWCwZABEwe5zfvyMAALIQABa1z4AETCT730.jpg', 'http://desk-fd.zol-img.com.cn/g5/M00/02/05/ChMkJ1bKyZmIWCwZABEwe5zfvyMAALIQABa1z4AETCT730.jpg', 'http://desk-fd.zol-img.com.cn/g5/M00/02/05/ChMkJ1bKyZmIWCwZABEwe5zfvyMAALIQABa1z4AETCT730.jpg'],
        show: true
    },
    change: function change(e) {
        console.log('current index has changed', e.detail);
    },
    delete: function _delete(e) {
        console.log('delete', e.detail);
    },
    hide: function hide() {
        var _this = this;

        console.log('component hide');
        setTimeout(function () {
            console.log('component show');
            _this.setData({
                show: true
            });
        }, 1000);
    }
});
});require("page/weui/example/gallery/gallery.js")
var __wxRoute = "page/weui/example/grid/grid", __wxRouteBegin = true;
define("page/weui/example/grid/grid.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var GRID_DEMO_URL = getApp().globalData.GRID_DEMO_URL;

var app = getApp();

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'grid',
            path: 'page/weui/example/grid/grid'
        };
    },

    data: { grids: [{
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }, {
            imgUrl: app.globalData.iconTabbar,
            url: GRID_DEMO_URL,
            text: 'Grid'
        }]
    }
});
});require("page/weui/example/grid/grid.js")
var __wxRoute = "page/weui/example/loadmore/loadmore", __wxRouteBegin = true;
define("page/weui/example/loadmore/loadmore.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'loadmore',
      path: 'page/weui/example/loadmore/loadmore'
    };
  }
});
});require("page/weui/example/loadmore/loadmore.js")
var __wxRoute = "page/weui/example/loading/loading", __wxRouteBegin = true;
define("page/weui/example/loading/loading.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'loading',
      path: 'page/weui/example/loading/loading'
    };
  },

  data: {
    tips: '请稍后',
    show: true,
    animated: true
  },
  onShow: function onShow() {
    var _this = this;

    this.timer = setInterval(function () {
      _this.setData({
        show: !_this.data.show
      });
    }, 2000);
  },
  close: function close() {
    this.setData({
      animated: !this.data.animated
    });
  },
  onUnload: function onUnload() {
    clearInterval(this.timer);
  }
});
});require("page/weui/example/loading/loading.js")
var __wxRoute = "page/weui/example/panel/panel", __wxRouteBegin = true;
define("page/weui/example/panel/panel.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var base64 = require("../images/base64");

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'panel',
            path: 'page/weui/example/panel/panel'
        };
    },

    onLoad: function onLoad() {
        this.setData({
            icon20: base64.icon20,
            icon60: base64.icon60
        });
    }
});
});require("page/weui/example/panel/panel.js")
var __wxRoute = "page/weui/example/preview/preview", __wxRouteBegin = true;
define("page/weui/example/preview/preview.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'preview',
      path: 'page/weui/example/preview/preview'
    };
  }
});
});require("page/weui/example/preview/preview.js")
var __wxRoute = "page/weui/example/dialog/dialog", __wxRouteBegin = true;
define("page/weui/example/dialog/dialog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'dialog',
            path: 'page/weui/example/dialog/dialog'
        };
    },

    data: {
        dialogShow: false,
        showOneButtonDialog: false,
        buttons: [{ text: '取消' }, { text: '确定' }],
        oneButton: [{ text: '确定' }]
    },
    openConfirm: function openConfirm() {
        this.setData({
            dialogShow: true
        });
    },
    tapDialogButton: function tapDialogButton(e) {
        this.setData({
            dialogShow: false,
            showOneButtonDialog: false
        });
    },
    tapOneDialogButton: function tapOneDialogButton(e) {
        this.setData({
            showOneButtonDialog: true
        });
    }
});
});require("page/weui/example/dialog/dialog.js")
var __wxRoute = "page/weui/example/msg/msg", __wxRouteBegin = true;
define("page/weui/example/msg/msg.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'msg',
            path: 'page/weui/example/msg/msg'
        };
    },

    openSuccess: function openSuccess() {
        wx.navigateTo({
            url: 'msg_success'
        });
    },
    openText: function openText() {
        wx.navigateTo({
            url: 'msg_text'
        });
    },
    openTextPrimary: function openTextPrimary() {
        wx.navigateTo({
            url: 'msg_text_primary'
        });
    },
    openFail: function openFail() {
        wx.navigateTo({
            url: 'msg_fail'
        });
    }
});
});require("page/weui/example/msg/msg.js")
var __wxRoute = "page/weui/example/msg/msg_text", __wxRouteBegin = true;
define("page/weui/example/msg/msg_text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'msg_text',
      path: 'page/weui/example/msg_text/msg_text'
    };
  }
});
});require("page/weui/example/msg/msg_text.js")
var __wxRoute = "page/weui/example/msg/msg_text_primary", __wxRouteBegin = true;
define("page/weui/example/msg/msg_text_primary.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'msg_text_primary',
      path: 'page/weui/example/msg_text_primary/msg_text_primary'
    };
  }
});
});require("page/weui/example/msg/msg_text_primary.js")
var __wxRoute = "page/weui/example/msg/msg_success", __wxRouteBegin = true;
define("page/weui/example/msg/msg_success.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'msg_success',
      path: 'page/weui/example/msg_success'
    };
  }
});
});require("page/weui/example/msg/msg_success.js")
var __wxRoute = "page/weui/example/msg/msg_fail", __wxRouteBegin = true;
define("page/weui/example/msg/msg_fail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'msg_fail',
      path: 'page/weui/example/msg_fail/msg_fail'
    };
  }
});
});require("page/weui/example/msg/msg_fail.js")
var __wxRoute = "page/weui/example/navbar/navbar", __wxRouteBegin = true;
define("page/weui/example/navbar/navbar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置

Page({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'navbar',
            path: 'page/weui/example/navbar/navbar'
        };
    },

    data: {
        tabs: ["选项一", "选项二", "选项三"],
        activeIndex: 1,
        sliderOffset: 0,
        sliderLeft: 0
    },
    onLoad: function onLoad() {
        var that = this;
        wx.getSystemInfo({
            success: function success(res) {
                that.setData({
                    sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
                    sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
                });
            }
        });
    },
    tabClick: function tabClick(e) {
        this.setData({
            sliderOffset: e.currentTarget.offsetLeft,
            activeIndex: e.currentTarget.id
        });
    }
});
});require("page/weui/example/navbar/navbar.js")
var __wxRoute = "page/weui/example/navigation/navigation", __wxRouteBegin = true;
define("page/weui/example/navigation/navigation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'navigation',
            path: 'page/weui/example/navigation/navigation'
        };
    },

    data: {
        loading: false,
        color: '#000',
        background: '#f8f8f8',
        show: true,
        animated: false
    },
    toggleLoading: function toggleLoading() {
        this.setData({
            loading: !this.data.loading
        });
    },
    changeColor: function changeColor() {
        this.setData({
            color: '#07C160'
        });
    },
    changeBgColor: function changeBgColor() {
        this.setData({
            background: '#ededed'
        });
    },
    toggleShow: function toggleShow() {
        this.setData({
            show: !this.data.show
        });
    },
    toggleAnimated: function toggleAnimated() {
        this.setData({
            animated: !this.data.animated,
            show: !this.data.show
        });
    }
});
});require("page/weui/example/navigation/navigation.js")
var __wxRoute = "page/weui/example/tabbar/tabbar", __wxRouteBegin = true;
define("page/weui/example/tabbar/tabbar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'tabbar',
            path: 'page/weui/example/tabbar/tabbar'
        };
    },

    data: {
        list: [{
            text: '微信',
            iconPath: app.globalData.iconTabbar,
            selectedIconPath: app.globalData.iconTabbar,

            badge: '8'
        }, {
            text: '通讯录',
            iconPath: app.globalData.iconTabbar,
            selectedIconPath: app.globalData.iconTabbar
        }, {
            text: '发现',
            iconPath: app.globalData.iconTabbar,
            selectedIconPath: app.globalData.iconTabbar,
            dot: true
        }, {
            text: '我',
            iconPath: app.globalData.iconTabbar,
            selectedIconPath: app.globalData.iconTabbar
        }]
    },
    tabChange: function tabChange(e) {
        console.log('tab change', e);
    }
});
});require("page/weui/example/tabbar/tabbar.js")
var __wxRoute = "page/weui/example/icons/icons", __wxRouteBegin = true;
define("page/weui/example/icons/icons.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var colorLight = 'rgba(0, 0, 0, .9)';
var colorDark = 'rgba(255, 255, 255, .8)';

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'icons',
            path: 'page/weui/example/icons/icons'
        };
    },

    data: {
        iconList: [{
            icon: 'add-friends',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'add',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'add2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'album',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'arrow',
            color: colorLight,
            size: 12,
            name: ''
        }, {
            icon: 'at',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'back',
            color: colorLight,
            size: 12,
            name: ''
        }, {
            icon: 'back2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'bellring-off',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'bellring-on',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'camera',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'cellphone',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'clip',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'close',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'close2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'comment',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'contacts',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'copy',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'delete-on',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'delete',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'discover',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'display',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'done',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'done2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'download',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'email',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'error',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'eyes-off',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'eyes-on',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'folder',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'group-detail',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'help',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'home',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'imac',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'info',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'keyboard',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'like',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'link',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'location',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'lock',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'max-window',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'me',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'mike',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'mike2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'mobile-contacts',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'more',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'more2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'mosaic',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'music-off',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'music',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'note',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'pad',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'pause',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'pencil',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'photo-wall',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'play',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'play2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'previous',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'previous2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'qr-code',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'refresh',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'report-problem',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'search',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'sending',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'setting',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'share',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'shop',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'star',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'sticker',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'tag',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'text',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'time',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'transfer-text',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'transfer2',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'translate',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'tv',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'video-call',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'voice',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'volume-down',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'volume-off',
            color: colorLight,
            size: 25,
            name: ''
        }, {
            icon: 'volume-up',
            color: colorLight,
            size: 25,
            name: ''
        }]
    },
    onLoad: function onLoad() {
        this.setIconColor(this.data.theme);
        var app = getApp();
        app.watchThemeChange && app.watchThemeChange(this.setIconColor);
    },
    setIconColor: function setIconColor(theme) {
        var color = theme === 'dark' ? colorDark : colorLight;

        this.setData({
            iconList: this.data.iconList.map(function (icon) {
                icon.color = color;
                return icon;
            })
        });
    }
});
});require("page/weui/example/icons/icons.js")
var __wxRoute = "page/weui/example/form-page/form-page", __wxRouteBegin = true;
define("page/weui/example/form-page/form-page.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'form-age',
      path: 'page/weui/example/form-age/form-age'
    };
  },

  data: {},
  methods: {}
});
});require("page/weui/example/form-page/form-page.js")
var __wxRoute = "page/weui/example/half-screen-dialog/half-screen-dialog", __wxRouteBegin = true;
define("page/weui/example/half-screen-dialog/half-screen-dialog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'half-screen-dialog',
            path: 'page/weui/example/half-screen-dialog/half-screen-dialog'
        };
    },

    data: {
        typeF: false,
        typeS: false,
        typeT: false,
        buttons: [{
            type: 'default',
            className: '',
            text: '辅助操作',
            value: 0
        }, {
            type: 'primary',
            className: '',
            text: '主操作',
            value: 1
        }]
    },
    openTypeF: function openTypeF() {
        this.setData({
            typeF: true
        });
    },
    openTypeS: function openTypeS() {
        this.setData({
            typeS: true
        });
    },
    openTypeT: function openTypeT() {
        this.setData({
            typeT: true
        });
    },
    buttontap: function buttontap(e) {
        console.log(e.detail);
    }
});
});require("page/weui/example/half-screen-dialog/half-screen-dialog.js")
var __wxRoute = "page/weui/example/actionsheet/actionsheet", __wxRouteBegin = true;
define("page/weui/example/actionsheet/actionsheet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'actionsheet',
            path: 'page/weui/example/actionsheet/actionsheet'
        };
    },

    open: function open() {
        wx.showActionSheet({
            itemList: ['A', 'B', 'C'],
            success: function success(res) {
                if (!res.cancel) {
                    console.log(res.tapIndex);
                }
            }
        });
    },
    data: {
        showDialog: false,
        groups: [{ text: '示例菜单', value: 1 }, { text: '示例菜单', value: 2 }, { text: '负向菜单', type: 'warn', value: 3 }]
    },
    openDialog: function openDialog() {
        this.setData({
            showDialog: true
        });
    },
    closeDialog: function closeDialog() {
        this.setData({
            showDialog: false
        });
    },
    btnClick: function btnClick(e) {
        console.log(e);
        this.closeDialog();
    }
});
});require("page/weui/example/actionsheet/actionsheet.js")
var __wxRoute = "page/weui/example/toptips/toptips", __wxRouteBegin = true;
define("page/weui/example/toptips/toptips.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'toptips',
      path: 'page/weui/example/toptips/toptips'
    };
  },

  data: {
    value: '',
    showTopTips: false,
    message: '请输入文本',
    type: 'info'
  },
  bindInputValue: function bindInputValue(e) {
    this.setData({
      value: e.detail.value
    });
  },
  bindConfirmTap: function bindConfirmTap() {
    if (this.data.value) {
      this.setData({
        showTopTips: true,
        message: this.data.value,
        type: 'success'
      });
    } else {
      this.setData({
        showTopTips: true,
        type: 'error'
      });
    }
  }
});
});require("page/weui/example/toptips/toptips.js")
var __wxRoute = "page/weui/example/searchbar/searchbar", __wxRouteBegin = true;
define("page/weui/example/searchbar/searchbar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'searchbar',
            path: 'page/weui/example/searchbar/searchbar'
        };
    },

    data: {
        inputShowed: false,
        inputVal: "",
        i: 0
    },
    onLoad: function onLoad() {
        this.setData({
            search: this.search.bind(this)
        });
    },

    search: function search(value) {
        var _this = this;

        return new Promise(function (resolve, reject) {
            if (_this.data.i % 2 === 0) {
                setTimeout(function () {
                    resolve([{ text: '搜索结果', value: 1 }, { text: '搜索结果2', value: 2 }]);
                }, 200);
            } else {
                setTimeout(function () {
                    resolve([]);
                }, 200);
            }
            _this.setData({
                i: _this.data.i + 1
            });
        });
    },
    selectResult: function selectResult(e) {
        console.log('select result', e.detail);
    }
});
});require("page/weui/example/searchbar/searchbar.js")
var __wxRoute = "page/weui/example/emoji/emoji", __wxRouteBegin = true;
define("page/weui/example/emoji/emoji.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

var _util = require('../../../../util/util');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'emoji',
      path: 'page/weui/example/emoji/emoji'
    };
  },

  data: {
    lineHeight: 24,
    functionShow: false,
    emojiShow: false,
    comment: '',
    focus: false,
    cursor: 0,
    _keyboardShow: false,
    emojiSource: 'https://res.wx.qq.com/op_res/eROMsLpnNC10dC40vzF8qviz63ic7ATlbGg20lr5pYykOwHRbLZFUhgg23RtVorX',
    // parsedComment: []
    historyList: [],
    layoutHeight: '0px',
    safeHeight: 0,
    keyboardHeight: 0,
    isIOS: false,
    canIUse: true
  },

  onLoad: function onLoad() {
    var system = wx.getSystemInfoSync();
    var isIOS = system.platform === 'ios';

    this.safeHeight = system.screenHeight - system.safeArea.bottom;
    var layoutHeight = wx.getSystemInfoSync().windowHeight - this.safeHeight / 2;
    this.setData({
      isIOS: isIOS,
      safeHeight: this.safeHeight,
      layoutHeight: layoutHeight

    });
    var emojiInstance = this.selectComponent('.mp-emoji');
    this.emojiNames = emojiInstance.getEmojiNames();
    this.parseEmoji = emojiInstance.parseEmoji;
  },
  onReady: function onReady() {
    // 解决基础库小于 2.9.2 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    if ((0, _util.compareVersion)(SDKVersion, '2.9.1') < 0) {
      this.setData({
        canIUse: false
      });
    }
  },
  onkeyboardHeightChange: function onkeyboardHeightChange(e) {
    var height = e.detail.height;

    if (height === 0) {
      this.data._keyboardShow = false;

      this.setData({
        safeHeight: this.safeHeight,
        keyboardHeight: height
      });
    } else {
      this.data._keyboardShow = true;
      this.setData({
        safeHeight: 0,
        functionShow: false,
        emojiShow: false,
        keyboardHeight: height
      });
    }
  },
  hideAllPanel: function hideAllPanel() {
    this.setData({
      functionShow: false,
      emojiShow: false
    });
  },
  showEmoji: function showEmoji() {
    this.setData({
      functionShow: false,
      emojiShow: this.data._keyboardShow || !this.data.emojiShow
    });
  },
  showFunction: function showFunction() {
    this.setData({
      functionShow: this.data._keyboardShow || !this.data.functionShow,
      emojiShow: false
    });
  },
  chooseImage: function chooseImage() {},
  onFocus: function onFocus() {
    this.data._keyboardShow = true;

    this.hideAllPanel();
  },
  onBlur: function onBlur(e) {
    this.data._keyboardShow = false;
    this.data.cursor = e.detail.cursor || 0;
  },
  onInput: function onInput(e) {
    var value = e.detail.value;
    this.data.comment = value;
  },
  onConfirm: function onConfirm() {
    this.onsend();
  },
  insertEmoji: function insertEmoji(evt) {
    var emotionName = evt.detail.emotionName;
    var _data = this.data,
        cursor = _data.cursor,
        comment = _data.comment;

    var newComment = comment.slice(0, cursor) + emotionName + comment.slice(cursor);
    this.setData({
      comment: newComment,
      cursor: cursor + emotionName.length
    });
  },
  onsend: function onsend() {
    var comment = this.data.comment;
    var parsedComment = {
      emoji: this.parseEmoji(this.data.comment),
      id: 'emoji_' + this.data.historyList.length
    };
    this.setData({
      historyList: [].concat(_toConsumableArray(this.data.historyList), [parsedComment]),
      comment: '',
      emojiShow: false
    });
  },
  deleteEmoji: function deleteEmoji() {
    var pos = this.data.cursor;
    var comment = this.data.comment;
    var result = '';
    var cursor = 0;

    var emojiLen = 6;
    var startPos = pos - emojiLen;
    if (startPos < 0) {
      startPos = 0;
      emojiLen = pos;
    }
    var str = comment.slice(startPos, pos);
    var matchs = str.match(/\[([\u4e00-\u9fa5\w]+)\]$/g);
    // 删除表情
    if (matchs) {
      var rawName = matchs[0];
      var left = emojiLen - rawName.length;
      if (this.emojiNames.indexOf(rawName) >= 0) {
        var replace = str.replace(rawName, '');
        result = comment.slice(0, startPos) + replace + comment.slice(pos);
        cursor = startPos + left;
      }
      // 删除字符
    } else {
      var endPos = pos - 1;
      if (endPos < 0) endPos = 0;
      var prefix = comment.slice(0, endPos);
      var suffix = comment.slice(pos);
      result = prefix + suffix;
      cursor = endPos;
    }
    this.setData({
      comment: result,
      cursor: cursor
    });
  }
});
});require("page/weui/example/emoji/emoji.js")
var __wxRoute = "page/weui/example/video-swiper/video-swiper", __wxRouteBegin = true;
define("page/weui/example/video-swiper/video-swiper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var urls = ['https://res.wx.qq.com/wxaliveplayer/htdocs/video14e1eea.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video24e1eeb.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video34e1eeb.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video44e1eeb.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video54e1eeb.mov'];


(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'video-swiper',
      path: 'page/weui/example/video-swiper/video-swiper'
    };
  },

  data: {
    videoList: []
  },
  onLoad: function onLoad() {

    var videoList = urls.map(function (item, index) {
      return {
        id: index,
        url: item,
        objectFit: 'contain'
      };
    });
    this.setData({
      videoList: videoList
    });
  },
  onReady: function onReady() {},
  onShow: function onShow() {},
  onHide: function onHide() {},
  onUnload: function onUnload() {},
  onPlay: function onPlay(e) {},
  onPause: function onPause(e) {
    //  console.log('pause', e.detail.activeId)
  },
  onEnded: function onEnded(e) {},
  onError: function onError(e) {},
  onWaiting: function onWaiting(e) {},
  onTimeUpdate: function onTimeUpdate(e) {},
  onProgress: function onProgress(e) {},
  onLoadedMetaData: function onLoadedMetaData(e) {
    console.log('LoadedMetaData', e);
  }
});
});require("page/weui/example/video-swiper/video-swiper.js")
var __wxRoute = "page/weui/example/index-list/index-list", __wxRouteBegin = true;
define("page/weui/example/index-list/index-list.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'index-list',
      path: 'page/weui/example/index-list/index-list'
    };
  },
  onLoad: function onLoad(options) {
    this.getCitys();
  },
  getCitys: function getCitys() {
    var db = wx.cloud.database({
      env: 'release-b86096'
    });
    var mapCity = db.collection('mapCity');
    var _this = this;

    mapCity.doc('6af880a55eb9574b008b78aa53a48405').get({
      success: function success(re) {
        console.log(re);
        var cities = re.data.cities;
        // 按拼音排序
        cities.sort(function (c1, c2) {
          var pinyin1 = c1.pinyin.join('');
          var pinyin2 = c2.pinyin.join('');
          return pinyin1.localeCompare(pinyin2);
        });
        // 添加首字母
        var map = new Map();
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = cities[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var city = _step.value;

            var alpha = city.pinyin[0].charAt(0).toUpperCase();
            if (!map.has(alpha)) map.set(alpha, []);
            map.get(alpha).push({ name: city.fullname });
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }

        var keys = [];
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
          for (var _iterator2 = map.keys()[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var key = _step2.value;

            keys.push(key);
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }

        keys.sort();

        var list = [];
        var _iteratorNormalCompletion3 = true;
        var _didIteratorError3 = false;
        var _iteratorError3 = undefined;

        try {
          for (var _iterator3 = keys[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var _key = _step3.value;

            list.push({
              alpha: _key,
              subItems: map.get(_key)
            });
          }
        } catch (err) {
          _didIteratorError3 = true;
          _iteratorError3 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion3 && _iterator3.return) {
              _iterator3.return();
            }
          } finally {
            if (_didIteratorError3) {
              throw _iteratorError3;
            }
          }
        }

        _this.setData({ list: list });
      }
    });
  }
});
});require("page/weui/example/index-list/index-list.js")
var __wxRoute = "page/weui/example/recycle-view/recycle-view", __wxRouteBegin = true;
define("page/weui/example/recycle-view/recycle-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var createRecycleContext = require('miniprogram-recycle-view');

// fakeList

var imgUrlList = ['http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSEV5QjxLDJaL6ibHLSZ02TIcve0ocPXrdTVqGGbqAmh5Mw9V7504dlEiatSvnyibibHCrVQO2GEYsJicPA/0?wx_fmt=jpeg', 'http://mmbiz.qpic.cn/sz_mmbiz_png/GEWVeJPFkSHALb0g5rCc4Jf5IqDfdwhWJ43I1IvriaV5uFr9fLAuv3uxHR7DQstbIxhNXFoQEcxGzWwzQUDBd6Q/0?wx_fmt=png', 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSGqys4ibO2a8L9nnIgH0ibjNXfbicNbZQQYfxxUpmicQglAEYQ2btVXjOhY9gRtSTCxKvAlKFek7sRUFA/0?wx_fmt=jpeg', 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSH2Eic4Lt0HkZeEN08pWXTticVRgyNGgBVHMJwMtRhmB0hE4m4alSuwsBk3uBBOhdCr91bZlSFbYhFg/0?wx_fmt=jpeg', 'http://mmbiz.qpic.cn/mmbiz_jpg/TcDuyasB5T3Eg34AYwjMw7xbEK2n01ekiaicPiaMInEMTkOQtuv1yke5KziaYF4MLia4IAbxlm0m5NxkibicFg4IZ92EA/0?wx_fmt=jpeg'];

var newList = new Array(300).fill(0);
var count = 0;
for (var i = 0; i < newList.length; i++) {
  newList[i] = {
    idx: i,
    title: i + '\u3001\u6587\u672C',
    image_url: imgUrlList[count++ % 5]
  };
}

var rpx2px = function rpx2px(rpx) {
  return rpx / 750 * wx.getSystemInfoSync().windowWidth;
};
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'recycle-view',
      path: 'page/weui/example/recycle-view/recycle-view'
    };
  },

  data: {},
  onLoad: function onLoad(options) {},
  onReady: function onReady() {
    var ctx = createRecycleContext({
      id: 'recycleId',
      dataKey: 'recycleList',
      page: this,
      itemSize: {
        height: rpx2px(300),
        width: rpx2px(750)
      }
    });
    ctx.append(newList);
  }
});
});require("page/weui/example/recycle-view/recycle-view.js")
var __wxRoute = "page/weui/example/sticky/sticky", __wxRouteBegin = true;
define("page/weui/example/sticky/sticky.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'sticky',
      path: 'page/weui/example/sticky/sticky'
    };
  },

  data: {},

  onLoad: function onLoad() {},
  onReady: function onReady() {
    this.setData({
      container: function container() {
        return wx.createSelectorQuery().select('#container');
      }
    });
  },
  onScroll: function onScroll(e) {
    console.log('onScroll', e);
  }
});
});require("page/weui/example/sticky/sticky.js")
var __wxRoute = "page/weui/example/tabs/tabs", __wxRouteBegin = true;
define("page/weui/example/tabs/tabs.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'tabs',
      path: 'page/weui/example/tabs/tabs'
    };
  },

  data: {
    tabs: [],
    activeTab: 0
  },

  onLoad: function onLoad() {
    var tabs = [{
      title: '技术开发',
      title2: '小程序开发进阶',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSEV5QjxLDJaL6ibHLSZ02TIcve0ocPXrdTVqGGbqAmh5Mw9V7504dlEiatSvnyibibHCrVQO2GEYsJicPA/0?wx_fmt=jpeg',
      desc: '本视频系列课程，由腾讯课堂NEXT学院与微信团队联合出品，通过实战案例，深入浅出地进行讲解。'
    }, {
      title: '产品解析',
      title2: '微信小程序直播',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_png/GEWVeJPFkSHALb0g5rCc4Jf5IqDfdwhWJ43I1IvriaV5uFr9fLAuv3uxHR7DQstbIxhNXFoQEcxGzWwzQUDBd6Q/0?wx_fmt=png',
      desc: '微信小程序直播系列课程持续更新中，帮助大家更好地理解、应用微信小程序直播功能。'
    }, {
      title: '运营规范',
      title2: '常见问题和解决方案',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSGqys4ibO2a8L9nnIgH0ibjNXfbicNbZQQYfxxUpmicQglAEYQ2btVXjOhY9gRtSTCxKvAlKFek7sRUFA/0?wx_fmt=jpeg',
      desc: '提高审核质量'
    }, {
      title: '营销经验',
      title2: '流量主小程序',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSH2Eic4Lt0HkZeEN08pWXTticVRgyNGgBVHMJwMtRhmB0hE4m4alSuwsBk3uBBOhdCr91bZlSFbYhFg/0?wx_fmt=jpeg',
      desc: '本课程共四节，将分阶段为开发者展示如何开通流量主功能、如何接入广告组件、不同类型小程序接入的建议，以及如何通过工具调优小程序变现效率。'
    }, {
      title: '高校大赛',
      title2: '2020中国高校计算机大赛',
      img: 'http://mmbiz.qpic.cn/mmbiz_jpg/TcDuyasB5T3Eg34AYwjMw7xbEK2n01ekiaicPiaMInEMTkOQtuv1yke5KziaYF4MLia4IAbxlm0m5NxkibicFg4IZ92EA/0?wx_fmt=jpeg',
      desc: '微信小程序应用开发赛'
    }];
    this.setData({ tabs: tabs });
  },
  onTabClick: function onTabClick(e) {
    var index = e.detail.index;
    this.setData({
      activeTab: index
    });
  },
  onChange: function onChange(e) {
    var index = e.detail.index;
    this.setData({
      activeTab: index
    });
  },
  handleClick: function handleClick(e) {
    wx.navigateTo({
      url: './webview'
    });
  }
});
});require("page/weui/example/tabs/tabs.js")
var __wxRoute = "page/weui/example/vtabs/vtabs", __wxRouteBegin = true;
define("page/weui/example/vtabs/vtabs.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'vtabs',
      path: 'page/weui/example/vtabs/vtabs'
    };
  },

  data: {
    vtabs: [],
    activeTab: 0
  },

  onLoad: function onLoad() {
    var tabs = [{
      title: '技术开发',
      title2: '小程序开发进阶',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSEV5QjxLDJaL6ibHLSZ02TIcve0ocPXrdTVqGGbqAmh5Mw9V7504dlEiatSvnyibibHCrVQO2GEYsJicPA/0?wx_fmt=jpeg',
      desc: '本视频系列课程，由腾讯课堂NEXT学院与微信团队联合出品，通过实战案例，深入浅出地进行讲解。'
    }, {
      title: '产品解析',
      title2: '微信小程序直播',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_png/GEWVeJPFkSHALb0g5rCc4Jf5IqDfdwhWJ43I1IvriaV5uFr9fLAuv3uxHR7DQstbIxhNXFoQEcxGzWwzQUDBd6Q/0?wx_fmt=png',
      desc: '微信小程序直播系列课程持续更新中，帮助大家更好地理解、应用微信小程序直播功能。'
    }, {
      title: '运营规范',
      title2: '常见问题和解决方案',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSGqys4ibO2a8L9nnIgH0ibjNXfbicNbZQQYfxxUpmicQglAEYQ2btVXjOhY9gRtSTCxKvAlKFek7sRUFA/0?wx_fmt=jpeg',
      desc: '提高审核质量'
    }, {
      title: '营销经验',
      title2: '流量主小程序',
      img: 'http://mmbiz.qpic.cn/sz_mmbiz_jpg/GEWVeJPFkSH2Eic4Lt0HkZeEN08pWXTticVRgyNGgBVHMJwMtRhmB0hE4m4alSuwsBk3uBBOhdCr91bZlSFbYhFg/0?wx_fmt=jpeg',
      desc: '本课程共四节，将分阶段为开发者展示如何开通流量主功能、如何接入广告组件、不同类型小程序接入的建议。'
    }, {
      title: '高校大赛',
      title2: '2020中国高校计算机大赛',
      img: 'http://mmbiz.qpic.cn/mmbiz_jpg/TcDuyasB5T3Eg34AYwjMw7xbEK2n01ekiaicPiaMInEMTkOQtuv1yke5KziaYF4MLia4IAbxlm0m5NxkibicFg4IZ92EA/0?wx_fmt=jpeg',
      desc: '微信小程序应用开发赛'
    }];
    this.setData({ vtabs: tabs });
  },
  onTabClick: function onTabClick(e) {
    var index = e.detail.index;
    console.log('tabClick', index);
  },
  onChange: function onChange(e) {
    var index = e.detail.index;
    console.log('change', index);
  },
  handleClick: function handleClick() {
    wx.navigateTo({
      url: '../tabs/webview'
    });
  }
});
});require("page/weui/example/vtabs/vtabs.js")
var __wxRoute = "page/weui/example/select-text/select-text", __wxRouteBegin = true;
define("page/weui/example/select-text/select-text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'select-text',
      path: 'page/weui/example/select-text/select-text'
    };
  },

  data: {
    arr: [{
      value: '长按，上侧复制',
      placement: 'top'
    }, {
      value: '长按，右侧复制',
      placement: 'right'
    }, {
      value: '长按，左侧复制',
      placement: 'left'
    }, {
      value: '长按，下侧复制',
      placement: 'bottom'
    }]
  },

  onLoad: function onLoad() {},
  onCopy: function onCopy(e) {
    console.log('onCopy', e);
  },
  handleTouchStart: function handleTouchStart(e) {
    console.log('@@ touchstart', e);
  },
  handleTap: function handleTap(e) {
    console.log('@@ tap', e);
    this.setData({
      evt: e
    });
  }
});
});require("page/weui/example/select-text/select-text.js")
var __wxRoute = "page/weui/example/barrage/barrage", __wxRouteBegin = true;
define("page/weui/example/barrage/barrage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _require = require('./utils'),
    mockData = _require.mockData;

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'barrage',
      path: 'page/weui/example/barrage/barrage'
    };
  },

  data: {
    src: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
    toggle: true,
    barrageValue: '',
    showBarrage: false
  },
  onReady: function onReady() {
    this.addBarrage();
  },
  addBarrage: function addBarrage() {
    var barrageComp = this.selectComponent('.barrage');
    this.barrage = barrageComp.getBarrageInstance({
      font: 'bold 16px sans-serif', // 字体
      duration: 15, // 弹幕时间 （移动 2000px 所需时长）
      lineHeight: 2, // 弹幕行高
      mode: 'overlap', // 弹幕重叠 overlap 不重叠 separate
      padding: [10, 10, 10, 10], // 弹幕区四周
      range: [0, 1],
      tunnelShow: false
    });
    // this.barrage.open()
    // const data = mockData(100)
    // this.barrage.addData(data)
    // this.timer = setInterval(() => {
    //   const data = mockData(100);
    //   this.barrage.addData(data);
    // }, 2000)
  },
  fullscreenchange: function fullscreenchange() {
    var _this = this;

    this.setData({
      toggle: false
    });
    setTimeout(function () {
      if (_this.barrage) _this.barrage.close();
      _this.setData({ toggle: true });
      _this.addBarrage();
    }, 1000);
  },
  handleOpenClick: function handleOpenClick() {
    var _this2 = this;

    this.setData({
      showBarrage: true
    });
    this.barrage.open();
    var data = mockData(3);
    this.barrage.addData(data);
    this.timer = setInterval(function () {
      var data = mockData(5);
      _this2.barrage.addData(data);
    }, 2000);
  },
  handleCloseClick: function handleCloseClick() {
    this.barrage.close();
    this.setData({
      showBarrage: false
    });
  },
  handleInput: function handleInput(e) {
    this.setData({
      barrageValue: e.detail.value
    });
  },
  handleAddClick: function handleAddClick() {
    var data = mockData(1, [this.data.barrageValue]);
    this.barrage.addData(data);
    this.setData({
      barrageValue: ''
    });
  },
  handleTunnelShowClick: function handleTunnelShowClick() {
    this.barrage.showTunnel();
  },
  handleTunnelHideClick: function handleTunnelHideClick() {
    this.barrage.hideTunnel();
  }
});
});require("page/weui/example/barrage/barrage.js")
var __wxRoute = "page/weui/example/wxml-to-canvas/wxml-to-canvas", __wxRouteBegin = true;
define("page/weui/example/wxml-to-canvas/wxml-to-canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _require = require('./demo.js'),
    wxml = _require.wxml,
    style = _require.style;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'wxml-to-canvas',
      path: 'page/weui/example/wxml-to-canvas/wxml-to-canvas'
    };
  },

  data: {
    src: '',
    wxmlTemplate: wxml('your_img_url'),
    showCanvas: false
  },
  onLoad: function onLoad() {
    var _this = this;

    this.widget = this.selectComponent('.widget');
    wx.cloud.getTempFileURL({
      fileList: ['cloud://release-b86096.7265-release-b86096-1258211818/开放社区.jpeg'],
      success: function success(res) {

        var url = res.fileList[0].tempFileURL;
        console.log(url);
        _this.url = url;
      },
      fail: console.error
    });
  },
  renderToCanvas: function renderToCanvas() {
    var _this2 = this;

    console.log(wxml(this.url));
    var p1 = this.widget.renderToCanvas({ wxml: wxml(this.url), style: style });
    p1.then(function (re) {
      console.log('container', re.layoutBox);
      _this2.container = re;
    });
  },
  extraImage: function extraImage() {
    var _this3 = this;

    var p2 = this.widget.canvasToTempFilePath();
    p2.then(function (res) {
      _this3.setData({
        src: res.tempFilePath,
        width: _this3.container.layoutBox.width,
        height: _this3.container.layoutBox.height
      });
    });
  }
});
});require("page/weui/example/wxml-to-canvas/wxml-to-canvas.js")
var __wxRoute = "page/weui/example/telescopic/telescopic", __wxRouteBegin = true;
define("page/weui/example/telescopic/telescopic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {},
  onLoad: function onLoad() {
    // wx.showModal({
    //   content: '暂不支持该功能，可在windows版微信（2.9.5及以上版本）中拖动窗口大小查看效果',
    //   showCancel: false,
    //   confirmText: '我知道了'
    // })
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '左右伸缩',
      path: 'page/weui/example/telescopic/telescopic'
    };
  }
});
});require("page/weui/example/telescopic/telescopic.js")
var __wxRoute = "page/weui/example/linebreak/linebreak", __wxRouteBegin = true;
define("page/weui/example/linebreak/linebreak.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {},
  onLoad: function onLoad() {},
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '换行排列',
      path: 'page/weui/example/linebreak/linebreak'
    };
  }
});
});require("page/weui/example/linebreak/linebreak.js")
var __wxRoute = "page/weui/example/sidenavigation/sidenavigation", __wxRouteBegin = true;
define("page/weui/example/sidenavigation/sidenavigation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {
    show: false,
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  show: function show() {
    this.setData({ show: true });
  },
  hide: function hide() {
    this.setData({ show: false });
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '侧边导航栏',
      path: 'page/weui/example/sidenavigation/sidenavigation'
    };
  }
});
});require("page/weui/example/sidenavigation/sidenavigation.js")
var __wxRoute = "page/weui/example/pagination/pagination", __wxRouteBegin = true;
define("page/weui/example/pagination/pagination.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {},
  onLoad: function onLoad() {},
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '分页展现',
      path: 'page/weui/example/pagination/pagination'
    };
  }
});
});require("page/weui/example/pagination/pagination.js")
var __wxRoute = "page/weui/example/freelayout/freelayout", __wxRouteBegin = true;
define("page/weui/example/freelayout/freelayout.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '自由布局',
      path: 'page/weui/example/freelayout/freelayout'
    };
  }
});
});require("page/weui/example/freelayout/freelayout.js")
var __wxRoute = "page/weui/example/layeredpresentation/layeredpresentation", __wxRouteBegin = true;
define("page/weui/example/layeredpresentation/layeredpresentation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Page({
  data: {
    hide1: false,
    hide2: false,
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  onClick: function onClick(e) {
    this.setData(_defineProperty({}, e.target.dataset.set, true));
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '分层展现',
      path: 'page/weui/example/layeredpresentation/layeredpresentation'
    };
  }
});
});require("page/weui/example/layeredpresentation/layeredpresentation.js")
var __wxRoute = "page/weui/example/horizontalexpansion/horizontalexpansion", __wxRouteBegin = true;
define("page/weui/example/horizontalexpansion/horizontalexpansion.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '横向拓展',
      path: 'page/weui/example/horizontalexpansion/horizontalexpansion'
    };
  }
});
});require("page/weui/example/horizontalexpansion/horizontalexpansion.js")
var __wxRoute = "page/component/pages/canvas-2d/canvas-2d", __wxRouteBegin = true;
define("page/component/pages/canvas-2d/canvas-2d.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _util = require('../../../../util/util');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'canvas',
      path: 'page/component/pages/canvas-2d/canvas-2d'
    };
  },

  data: {
    canIUse: true
  },
  onReady: function onReady() {

    // 解决基础库小于 2.7.0 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    console.log(SDKVersion);
    if ((0, _util.compareVersion)(SDKVersion, '2.7.0') < 0) {
      console.log('123');
      this.setData({
        canIUse: false
      });
    } else {
      // canvas2D
      this.position2D = {
        x: 150,
        y: 150,
        vx: 2,
        vy: 2
      };
      this.x = -100;
      wx.createSelectorQuery().select('#canvas2D').fields({
        node: true,
        size: true
      }).exec(this.init.bind(this));
    }
  },
  init: function init(res) {
    var _this = this;

    var width = res[0].width;
    var height = res[0].height;

    var canvas = res[0].node;
    // 不支持2d
    if (!canvas) {
      this.setData({
        canIUse: false
      });
      return;
    }
    var ctx = canvas.getContext('2d');

    var dpr = wx.getSystemInfoSync().pixelRatio;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    var renderLoop = function renderLoop() {
      _this.render(canvas, ctx);
      canvas.requestAnimationFrame(renderLoop);
    };
    canvas.requestAnimationFrame(renderLoop);

    var img = canvas.createImage();
    img.onload = function () {
      _this._img = img;
    };
    img.src = './car.png';
  },
  render: function render(canvas, ctx) {
    ctx.clearRect(0, 0, 305, 305);
    this.drawBall2D(ctx);
    this.drawCar(ctx);
  },
  drawBall2D: function drawBall2D(ctx) {
    var p = this.position2D;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    function ball(x, y) {
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#1aad19';
      ctx.strokeStyle = 'rgba(1,1,1,0)';
      ctx.fill();
      ctx.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);
  },
  drawCar: function drawCar(ctx) {
    if (!this._img) return;
    if (this.x > 350) {
      this.x = -100;
    }
    ctx.drawImage(this._img, this.x++, 150 - 25, 100, 50);
    ctx.restore();
  },
  onUnload: function onUnload() {
    // clearInterval(this.interval)
  }
});
});require("page/component/pages/canvas-2d/canvas-2d.js")
var __wxRoute = "page/component/pages/webgl/webgl", __wxRouteBegin = true;
define("page/component/pages/webgl/webgl.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _util = require('../../../../util/util');

//WebGL
var vs = '\n  precision mediump float;\n\n  attribute vec2 vertPosition;\n  attribute vec3 vertColor;\n  varying vec3 fragColor;\n\n  void main() {\n    gl_Position = vec4(vertPosition, 0.0, 1.0);\n    fragColor = vertColor;\n  }\n';

var fs = '\n  precision mediump float;\n\n  varying vec3 fragColor;\n  void main() {\n    gl_FragColor = vec4(fragColor, 1.0);\n  }\n';

var triangleVertices = [0.0, 0.5, 1.0, 1.0, 0.0, -0.5, -0.5, 0.7, 0.0, 1.0, 0.5, -0.5, 0.1, 1.0, 0.6];

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'canvas',
      path: 'page/component/pages/webgl/webgl'
    };
  },

  data: {
    canIUse: true
  },
  onReady: function onReady() {
    var _this = this;

    // 解决基础库小于 2.7.0 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    if ((0, _util.compareVersion)(SDKVersion, '2.7.0') < 0) {
      console.log('123');
      this.setData({
        canIUse: false
      });
    } else {
      // WebGL
      wx.createSelectorQuery().select('#canvasWebGL').node().exec(function (res) {
        var canvas = res[0].node;
        _this.renderWebGL(canvas);
      });
    }
  },
  renderWebGL: function renderWebGL(canvas) {
    // 不支持webgl
    if (!canvas) {
      this.setData({
        canIUse: false
      });
      return;
    }
    var gl = canvas.getContext('webgl');
    if (!gl) {
      console.error('gl init failed', gl);
      return;
    }
    gl.viewport(0, 0, 305, 305);
    var vertShader = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertShader, vs);
    gl.compileShader(vertShader);

    var fragShader = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragShader, fs);
    gl.compileShader(fragShader);

    var prog = gl.createProgram();
    gl.attachShader(prog, vertShader);
    gl.attachShader(prog, fragShader);
    gl.deleteShader(vertShader);
    gl.deleteShader(fragShader);
    gl.linkProgram(prog);
    gl.useProgram(prog);

    var draw = function draw() {
      var triangleVertexBufferObject = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexBufferObject);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(triangleVertices), gl.STATIC_DRAW);

      var positionAttribLocation = gl.getAttribLocation(prog, 'vertPosition');
      var colorAttribLocation = gl.getAttribLocation(prog, 'vertColor');
      gl.vertexAttribPointer(positionAttribLocation, 2, gl.FLOAT, gl.FALSE, 5 * Float32Array.BYTES_PER_ELEMENT, 0);
      gl.vertexAttribPointer(colorAttribLocation, 3, gl.FLOAT, gl.FALSE, 5 * Float32Array.BYTES_PER_ELEMENT, 2 * Float32Array.BYTES_PER_ELEMENT);

      gl.enableVertexAttribArray(positionAttribLocation);
      gl.enableVertexAttribArray(colorAttribLocation);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      canvas.requestAnimationFrame(draw);
    };

    canvas.requestAnimationFrame(draw);
  }
});
});require("page/component/pages/webgl/webgl.js")